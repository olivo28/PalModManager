#pragma once
#include "CoreMinimal.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=AudioExtensions -ObjectName=SoundfieldEndpointSettingsBase -FallbackName=SoundfieldEndpointSettingsBase
#include "DualShockSoundfieldEndpointSettings.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class UDualShockSoundfieldEndpointSettings : public USoundfieldEndpointSettingsBase {
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadWrite, EditAnywhere, meta=(AllowPrivateAccess=true))
    int32 ControllerIndex;
    
    UDualShockSoundfieldEndpointSettings();

};


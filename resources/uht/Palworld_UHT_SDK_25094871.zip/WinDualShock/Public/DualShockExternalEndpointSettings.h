#pragma once
#include "CoreMinimal.h"
//CROSS-MODULE INCLUDE V2: -ModuleName=AudioExtensions -ObjectName=AudioEndpointSettingsBase -FallbackName=AudioEndpointSettingsBase
#include "DualShockExternalEndpointSettings.generated.h"

UCLASS(Blueprintable, EditInlineNew)
class UDualShockExternalEndpointSettings : public UAudioEndpointSettingsBase {
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadWrite, EditAnywhere, meta=(AllowPrivateAccess=true))
    int32 ControllerIndex;
    
    UDualShockExternalEndpointSettings();

};


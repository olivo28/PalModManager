#pragma once

#include <cstring>
#include <cstdint>
#include <unordered_map>
#include <malloc.h>
#include <Unreal/UObjectGlobals.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    using namespace RC::Unreal;

    #ifndef RC_UE4SS_SDK_EXPORTS
    #ifndef RC_UE4SS_SDK_BUILD_STATIC
    #ifndef RC_UE4SS_SDK_API
    #define RC_UE4SS_SDK_API __declspec(dllimport)
    #endif
    #else
    #ifndef RC_UE4SS_SDK_API
    #define RC_UE4SS_SDK_API
    #endif
    #endif
    #else
    #ifndef RC_UE4SS_SDK_API
    #define RC_UE4SS_SDK_API __declspec(dllexport)
    #endif
    #endif

    #define UE_MAKE_STRING(S) L##S

    #define UE_BEGIN_FUNCTION_BODY_INTERNAL(FunctionPath, ParmsSize) \
    if (!TheFunction) \
    { \
        throw std::runtime_error{"Unable to find '" FunctionPath "'"}; \
    } \
    auto ParamData = static_cast<uint8_t*>(_malloca(ParmsSize)); \
    memset(ParamData, 0, ParmsSize);

    #define UE_BEGIN_SCRIPT_FUNCTION_BODY(FunctionPath, ParmsSize) \
    auto TheFunction = RC::Unreal::UObjectGlobals::FindObject<RC::Unreal::UFunction>(nullptr, L##FunctionPath); \
    UE_BEGIN_FUNCTION_BODY_INTERNAL(FunctionPath, ParmsSize)

    #define UE_BEGIN_NATIVE_FUNCTION_BODY(FunctionPath, ParmsSize) \
    static auto TheFunction = RC::Unreal::UObjectGlobals::FindObject<RC::Unreal::UFunction>(nullptr, L##FunctionPath); \
    UE_BEGIN_FUNCTION_BODY_INTERNAL(FunctionPath, ParmsSize)

    #define UE_SET_STATIC_SELF(ObjectPath) \
    static auto StaticSelf = RC::Unreal::UObjectGlobals::FindObject<RC::Unreal::UObject>(nullptr, L##ObjectPath);

    #define UE_COPY_PROPERTY_CUSTOM(CXXPropertyName, TypeName, PropertyValueOffset) \
    *std::bit_cast<TypeName*>(&ParamData[PropertyValueOffset]) = *std::bit_cast<TypeName*>(&CXXPropertyName);

    #define UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TypeName, CXXValue, StructStartOffset, PropertyValueOffset) \
    *std::bit_cast<TypeName*>(&ParamData[StructStartOffset + PropertyValueOffset]) = static_cast<TypeName>(CXXValue);

    #define UE_COPY_OUT_PROPERTY_CUSTOM(CXXPropertyName, TypeName, PropertyValueOffset) \
    CXXPropertyName = *std::bit_cast<TypeName*>(&ParamData[PropertyValueOffset]);

    #define UE_CALL_FUNCTION() \
    ProcessEvent(TheFunction, ParamData);

    #define UE_CALL_STATIC_FUNCTION() \
    StaticSelf->ProcessEvent(TheFunction, ParamData);

    #define UE_RETURN_PROPERTY_CUSTOM(TypeName, PropertyValueOffset) \
    return *std::bit_cast<TypeName*>(&ParamData[PropertyValueOffset]);

    #define UE_RETURN_VECTOR_CUSTOM(PropertyValueOffset) \
    return *std::bit_cast<FVector*>(&ParamData[PropertyValueOffset]); \

    #define UE_RETURN_STRING_CUSTOM(PropertyValueOffset) \
    return std::bit_cast<RC::Unreal::FString*>(&ParamData[PropertyValueOffset])->GetCharArray(); \

    #define UE_COPY_VECTOR(FromName, StructStartOffset) \
    UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, FromName.X, StructStartOffset, 0x0) \
    UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, FromName.Y, StructStartOffset, 0x8) \
    UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, FromName.Z, StructStartOffset, 0x10) \

    #define UE_WITH_OUTER(Outer, ...) Outer __VA_OPT__(<__VA_ARGS__>)

}

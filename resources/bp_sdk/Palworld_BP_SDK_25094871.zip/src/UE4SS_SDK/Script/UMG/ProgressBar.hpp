#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Slate/EProgressBarFillStyle.hpp>
#include <UE4SS_SDK/Script/Slate/EProgressBarFillType.hpp>
#include <UE4SS_SDK/Script/SlateCore/ProgressBarStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x440 (unaligned: 0x440, alignment: 0x10)
    class RC_UE4SS_SDK_API UProgressBar : public WSDK::UWidget
    {
    public:
        // Properties.
        FProgressBarStyle WidgetStyle{}; // 0x150
        float Percent{}; // 0x3E0
        TEnumAsByte<EProgressBarFillType::Type> BarFillType{}; // 0x3E4
        TEnumAsByte<EProgressBarFillStyle::Type> BarFillStyle{}; // 0x3E5
        bool bIsMarquee{}; // 0x3E6
        uint8 padding_1[0x1]{}; // 0x3E7
        FVector2D BorderPadding{}; // 0x3E8
        FScriptDelegate PercentDelegate{}; // 0x3F8
        FLinearColor FillColorAndOpacity{}; // 0x408
        FScriptDelegate FillColorAndOpacityDelegate{}; // 0x418
        uint8 padding_2[0x18]{}; // 0x428

        // Functions.
        void SetPercent(float InPercent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ProgressBar:SetPercent", 4)
            UE_COPY_PROPERTY_CUSTOM(InPercent, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsMarquee(bool InbIsMarquee)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ProgressBar:SetIsMarquee", 1)
            UE_COPY_PROPERTY_CUSTOM(InbIsMarquee, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFillColorAndOpacity(FLinearColor InColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ProgressBar:SetFillColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColor.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColor.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColor.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColor.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
    };


}

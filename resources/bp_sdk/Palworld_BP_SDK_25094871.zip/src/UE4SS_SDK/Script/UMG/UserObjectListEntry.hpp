#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/UserListEntry.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API IUserObjectListEntry : public WSDK::IUserListEntry
    {
    public:
        // Properties.

        // Functions.
        void OnListItemObjectSet(UObject* ListItemObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserObjectListEntry:OnListItemObjectSet", 8)
            UE_COPY_PROPERTY_CUSTOM(ListItemObject, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

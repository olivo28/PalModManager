#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    namespace EVirtualKeyboardType
    {
        enum Type
        {
            Default,
            Number,
            Web,
            Email,
            Password,
            AlphaNumeric,
        };
    }
}

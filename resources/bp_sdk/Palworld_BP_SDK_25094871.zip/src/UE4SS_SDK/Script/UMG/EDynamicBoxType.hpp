#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EDynamicBoxType : uint8
    {
        Horizontal,
        Vertical,
        Wrap,
        VerticalWrap,
        Radial,
        Overlay,
    };
}

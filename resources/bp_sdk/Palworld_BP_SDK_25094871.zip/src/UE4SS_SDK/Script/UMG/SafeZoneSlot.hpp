#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API USafeZoneSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        bool bIsTitleSafe{}; // 0x38
        uint8 padding_1[0x3]{}; // 0x39
        FMargin SafeAreaScale{}; // 0x3C
        TEnumAsByte<EHorizontalAlignment> HAlign{}; // 0x4C
        TEnumAsByte<EVerticalAlignment> VAlign{}; // 0x4D
        uint8 padding_2[0x2]{}; // 0x4E
        FMargin Padding{}; // 0x50

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/ETextJustify.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextCommit.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/SpinBoxStyle.hpp>
#include <UE4SS_SDK/Script/UMG/EVirtualKeyboardType.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x870 (unaligned: 0x870, alignment: 0x10)
    class RC_UE4SS_SDK_API USpinBox : public WSDK::UWidget
    {
    public:
        // Properties.
        float Value{}; // 0x150
        FScriptDelegate ValueDelegate{}; // 0x154
        uint8 padding_1[0xC]{}; // 0x164
        FSpinBoxStyle WidgetStyle{}; // 0x170
        int32 MinFractionalDigits{}; // 0x770
        int32 MaxFractionalDigits{}; // 0x774
        bool bAlwaysUsesDeltaSnap{}; // 0x778
        bool bEnableSlider{}; // 0x779
        uint8 padding_2[0x2]{}; // 0x77A
        float Delta{}; // 0x77C
        float SliderExponent{}; // 0x780
        uint8 padding_3[0x4]{}; // 0x784
        FSlateFontInfo Font{}; // 0x788
        TEnumAsByte<ETextJustify::Type> Justification{}; // 0x7E8
        uint8 padding_4[0x3]{}; // 0x7E9
        float MinDesiredWidth{}; // 0x7EC
        TEnumAsByte<EVirtualKeyboardType::Type> KeyboardType{}; // 0x7F0
        bool ClearKeyboardFocusOnCommit{}; // 0x7F1
        bool SelectAllTextOnCommit{}; // 0x7F2
        uint8 padding_5[0x1]{}; // 0x7F3
        FSlateColor ForegroundColor{}; // 0x7F4
        FMulticastScriptDelegate OnValueChanged{}; // 0x808
        FMulticastScriptDelegate OnValueCommitted{}; // 0x818
        FMulticastScriptDelegate OnBeginSliderMovement{}; // 0x828
        FMulticastScriptDelegate OnEndSliderMovement{}; // 0x838
        uint8 bOverride_MinValue : 1{}; // 0x848 (0x1)
        uint8 bOverride_MaxValue : 1{}; // 0x848 (0x2)
        uint8 bOverride_MinSliderValue : 1{}; // 0x848 (0x4)
        uint8 bOverride_MaxSliderValue : 1{}; // 0x848 (0x8)
        uint8 padding_6 : 1{}; // 0x848 (0x10)
        uint8 padding_7 : 1{}; // 0x848 (0x20)
        uint8 padding_8 : 1{}; // 0x848 (0x40)
        uint8 padding_9 : 1{}; // 0x848 (0x80)
        uint8 padding_10[0x3]{}; // 0x849
        float MinValue{}; // 0x84C
        float MaxValue{}; // 0x850
        float MinSliderValue{}; // 0x854
        float MaxSliderValue{}; // 0x858
        uint8 padding_11[0x14]{}; // 0x85C

        // Functions.
        void SetValue(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetValue", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinValue(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMinValue", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinSliderValue(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMinSliderValue", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinFractionalDigits(int32 NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMinFractionalDigits", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxValue(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMaxValue", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxSliderValue(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMaxSliderValue", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxFractionalDigits(int32 NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetMaxFractionalDigits", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetForegroundColor(FSlateColor InForegroundColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetForegroundColor", 20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FLinearColor, InForegroundColor.SpecifiedColor, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ESlateColorStylingMode, InForegroundColor.ColorUseRule, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetDelta(float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetDelta", 4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAlwaysUsesDeltaSnap(bool bNewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:SetAlwaysUsesDeltaSnap", 1)
            UE_COPY_PROPERTY_CUSTOM(bNewValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, TEnumAsByte<ETextCommit::Type> CommitMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:OnSpinBoxValueCommittedEvent__DelegateSignature", 5)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(CommitMethod, TEnumAsByte<ETextCommit::Type>, 0x4)
            UE_CALL_FUNCTION()
        }
        void OnSpinBoxValueChangedEvent__DelegateSignature(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:OnSpinBoxValueChangedEvent__DelegateSignature", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnSpinBoxBeginSliderMovement__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:OnSpinBoxBeginSliderMovement__DelegateSignature", 0)
            UE_CALL_FUNCTION()
        }
        float GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetMinValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMinValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetMinSliderValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMinSliderValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        int32 GetMinFractionalDigits()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMinFractionalDigits", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        float GetMaxValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMaxValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetMaxSliderValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMaxSliderValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        int32 GetMaxFractionalDigits()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetMaxFractionalDigits", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        float GetDelta()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetDelta", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        bool GetAlwaysUsesDeltaSnap()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:GetAlwaysUsesDeltaSnap", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        void ClearMinValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:ClearMinValue", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMinSliderValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:ClearMinSliderValue", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMaxValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:ClearMaxValue", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMaxSliderValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SpinBox:ClearMaxSliderValue", 0)
            UE_CALL_FUNCTION()
        }
    };


}

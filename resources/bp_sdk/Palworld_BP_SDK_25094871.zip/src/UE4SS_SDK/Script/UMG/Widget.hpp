#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/EMouseCursor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/ECheckBoxState.hpp>
#include <UE4SS_SDK/Script/SlateCore/EFlowDirectionPreference.hpp>
#include <UE4SS_SDK/Script/SlateCore/EUINavigation.hpp>
#include <UE4SS_SDK/Script/SlateCore/EUINavigationRule.hpp>
#include <UE4SS_SDK/Script/SlateCore/EWidgetClipping.hpp>
#include <UE4SS_SDK/Script/SlateCore/Geometry.hpp>
#include <UE4SS_SDK/Script/SlateCore/PointerEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateVisibility.hpp>
#include <UE4SS_SDK/Script/UMG/EventReply.hpp>
#include <UE4SS_SDK/Script/UMG/FieldNotificationId.hpp>
#include <UE4SS_SDK/Script/UMG/Visual.hpp>
#include <UE4SS_SDK/Script/UMG/WidgetTransform.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class APlayerController;
    class UGameInstance;
    class ULocalPlayer;
    class UObject;
    class UPanelSlot;
    class UPanelWidget;
    class UPropertyBinding;
    class USlateAccessibleWidgetData;
    class UWidget;
    class UWidgetNavigation;

    // Super Size: 0x28
    // Size: 0x150 (unaligned: 0x150, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidget : public WSDK::UVisual
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x28
        UPanelSlot* Slot{}; // 0x30
        FScriptDelegate bIsEnabledDelegate{}; // 0x38
        FText ToolTipText{}; // 0x48
        FScriptDelegate ToolTipTextDelegate{}; // 0x60
        UWidget* ToolTipWidget{}; // 0x70
        FScriptDelegate ToolTipWidgetDelegate{}; // 0x78
        FScriptDelegate VisibilityDelegate{}; // 0x88
        FWidgetTransform RenderTransform{}; // 0x98
        FVector2D RenderTransformPivot{}; // 0xD0
        EFlowDirectionPreference FlowDirectionPreference{}; // 0xE0
        uint8 bIsVariable : 1{}; // 0xE1 (0x1)
        uint8 bCreatedByConstructionScript : 1{}; // 0xE1 (0x2)
        uint8 bIsEnabled : 1{}; // 0xE1 (0x4)
        uint8 bOverride_Cursor : 1{}; // 0xE1 (0x8)
        uint8 bIsVolatile : 1{}; // 0xE1 (0x10)
        uint8 padding_2 : 1{}; // 0xE1 (0x20)
        uint8 padding_3 : 1{}; // 0xE1 (0x40)
        uint8 padding_4 : 1{}; // 0xE1 (0x80)
        TEnumAsByte<EMouseCursor::Type> Cursor{}; // 0xE2
        EWidgetClipping Clipping{}; // 0xE3
        ESlateVisibility Visibility{}; // 0xE4
        uint8 padding_5[0x3]{}; // 0xE5
        float RenderOpacity{}; // 0xE8
        uint8 padding_6[0x4]{}; // 0xEC
        USlateAccessibleWidgetData* AccessibleWidgetData{}; // 0xF0
        UWidgetNavigation* Navigation{}; // 0xF8
        uint8 padding_7[0x20]{}; // 0x100
        TArray<UPropertyBinding*> NativeBindings{}; // 0x120
        uint8 padding_8[0x20]{}; // 0x130

        // Functions.
        void SetVisibility(ESlateVisibility InVisibility)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetVisibility", 1)
            UE_COPY_PROPERTY_CUSTOM(InVisibility, ESlateVisibility, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetUserFocus(APlayerController* PlayerController)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetUserFocus", 8)
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetToolTipText(FText& InToolTipText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetToolTipText", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InToolTipText, FText, 0x0)
        }
        void SetToolTip(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetToolTip", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRenderTranslation(FVector2D Translation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderTranslation", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Translation.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Translation.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetRenderTransformPivot(FVector2D Pivot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderTransformPivot", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Pivot.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Pivot.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetRenderTransformAngle(float Angle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderTransformAngle", 4)
            UE_COPY_PROPERTY_CUSTOM(Angle, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRenderTransform(FWidgetTransform InTransform)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderTransform", 56)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InTransform.Translation, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InTransform.Scale, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InTransform.Shear, 0x0, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InTransform.Angle, 0x0, 0x30)
            UE_CALL_FUNCTION()
        }
        void SetRenderShear(FVector2D Shear)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderShear", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Shear.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Shear.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetRenderScale(FVector2D Scale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderScale", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Scale.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Scale.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetRenderOpacity(float InOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetRenderOpacity", 4)
            UE_COPY_PROPERTY_CUSTOM(InOpacity, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetNavigationRuleExplicit(EUINavigation Direction, UWidget* InWidget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetNavigationRuleExplicit", 16)
            UE_COPY_PROPERTY_CUSTOM(Direction, EUINavigation, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InWidget, UWidget*, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetNavigationRuleCustomBoundary(EUINavigation Direction, FScriptDelegate InCustomDelegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetNavigationRuleCustomBoundary", 20)
            UE_COPY_PROPERTY_CUSTOM(Direction, EUINavigation, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InCustomDelegate, FScriptDelegate, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetNavigationRuleCustom(EUINavigation Direction, FScriptDelegate InCustomDelegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetNavigationRuleCustom", 20)
            UE_COPY_PROPERTY_CUSTOM(Direction, EUINavigation, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InCustomDelegate, FScriptDelegate, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetNavigationRuleBase(EUINavigation Direction, EUINavigationRule Rule)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetNavigationRuleBase", 2)
            UE_COPY_PROPERTY_CUSTOM(Direction, EUINavigation, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Rule, EUINavigationRule, 0x1)
            UE_CALL_FUNCTION()
        }
        void SetNavigationRule(EUINavigation Direction, EUINavigationRule Rule, FName WidgetToFocus)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetNavigationRule", 12)
            UE_COPY_PROPERTY_CUSTOM(Direction, EUINavigation, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Rule, EUINavigationRule, 0x1)
            UE_COPY_PROPERTY_CUSTOM(WidgetToFocus, FName, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetKeyboardFocus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetKeyboardFocus", 0)
            UE_CALL_FUNCTION()
        }
        void SetIsEnabled(bool bInIsEnabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetIsEnabled", 1)
            UE_COPY_PROPERTY_CUSTOM(bInIsEnabled, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFocus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetFocus", 0)
            UE_CALL_FUNCTION()
        }
        void SetCursor(TEnumAsByte<EMouseCursor::Type> InCursor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetCursor", 1)
            UE_COPY_PROPERTY_CUSTOM(InCursor, TEnumAsByte<EMouseCursor::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetClipping(EWidgetClipping InClipping)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetClipping", 1)
            UE_COPY_PROPERTY_CUSTOM(InClipping, EWidgetClipping, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAllNavigationRules(EUINavigationRule Rule, FName WidgetToFocus)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:SetAllNavigationRules", 12)
            UE_COPY_PROPERTY_CUSTOM(Rule, EUINavigationRule, 0x0)
            UE_COPY_PROPERTY_CUSTOM(WidgetToFocus, FName, 0x4)
            UE_CALL_FUNCTION()
        }
        void ResetCursor()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:ResetCursor", 0)
            UE_CALL_FUNCTION()
        }
        void RemoveFromParent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:RemoveFromParent", 0)
            UE_CALL_FUNCTION()
        }
        FEventReply OnReply__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:OnReply__DelegateSignature", 184)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x0)
        }
        FEventReply OnPointerEvent__DelegateSignature(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:OnPointerEvent__DelegateSignature", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        void K2_RemoveFieldValueChangedDelegate(FFieldNotificationId FieldId, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:K2_RemoveFieldValueChangedDelegate", 24)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, FieldId.FieldName, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void K2_BroadcastFieldValueChanged(FFieldNotificationId FieldId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:K2_BroadcastFieldValueChanged", 8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, FieldId.FieldName, 0x0, 0x0)
            UE_CALL_FUNCTION()
        }
        void K2_AddFieldValueChangedDelegate(FFieldNotificationId FieldId, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:K2_AddFieldValueChangedDelegate", 24)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, FieldId.FieldName, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        bool IsVisible()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:IsVisible", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsRendered()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:IsRendered", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsInViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:IsInViewport", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsHovered()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:IsHovered", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        void InvalidateLayoutAndVolatility()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:InvalidateLayoutAndVolatility", 0)
            UE_CALL_FUNCTION()
        }
        bool HasUserFocusedDescendants(APlayerController* PlayerController)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasUserFocusedDescendants", 9)
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasUserFocus(APlayerController* PlayerController)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasUserFocus", 9)
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasMouseCaptureByUser(int32 UserIndex, int32 PointerIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasMouseCaptureByUser", 9)
            UE_COPY_PROPERTY_CUSTOM(UserIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(PointerIndex, int32, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasMouseCapture()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasMouseCapture", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool HasKeyboardFocus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasKeyboardFocus", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool HasFocusedDescendants()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasFocusedDescendants", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool HasAnyUserFocus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:HasAnyUserFocus", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        UWidget* GetWidget__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetWidget__DelegateSignature", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x0)
        }
        ESlateVisibility GetVisibility()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetVisibility", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ESlateVisibility, 0x0)
        }
        FGeometry GetTickSpaceGeometry()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetTickSpaceGeometry", 64)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGeometry, 0x0)
        }
        FText GetText__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetText__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        ESlateVisibility GetSlateVisibility__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetSlateVisibility__DelegateSignature", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ESlateVisibility, 0x0)
        }
        FSlateColor GetSlateColor__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetSlateColor__DelegateSignature", 20)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateColor, 0x0)
        }
        FSlateBrush GetSlateBrush__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetSlateBrush__DelegateSignature", 208)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateBrush, 0x0)
        }
        float GetRenderTransformAngle()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetRenderTransformAngle", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetRenderOpacity()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetRenderOpacity", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        UPanelWidget* GetParent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetParent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UPanelWidget*, 0x0)
        }
        FGeometry GetPaintSpaceGeometry()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetPaintSpaceGeometry", 64)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGeometry, 0x0)
        }
        APlayerController* GetOwningPlayer()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetOwningPlayer", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(APlayerController*, 0x0)
        }
        ULocalPlayer* GetOwningLocalPlayer()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetOwningLocalPlayer", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ULocalPlayer*, 0x0)
        }
        TEnumAsByte<EMouseCursor::Type> GetMouseCursor__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetMouseCursor__DelegateSignature", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TEnumAsByte<EMouseCursor::Type>, 0x0)
        }
        FLinearColor GetLinearColor__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetLinearColor__DelegateSignature", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FLinearColor, 0x0)
        }
        bool GetIsEnabled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetIsEnabled", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        int32 GetInt32__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetInt32__DelegateSignature", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        UGameInstance* GetGameInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetGameInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UGameInstance*, 0x0)
        }
        float GetFloat__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetFloat__DelegateSignature", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        FVector2D GetDesiredSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetDesiredSize", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        EWidgetClipping GetClipping()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetClipping", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(EWidgetClipping, 0x0)
        }
        ECheckBoxState GetCheckBoxState__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetCheckBoxState__DelegateSignature", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ECheckBoxState, 0x0)
        }
        FGeometry GetCachedGeometry()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetCachedGeometry", 64)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGeometry, 0x0)
        }
        bool GetBool__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetBool__DelegateSignature", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FText GetAccessibleText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetAccessibleText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FText GetAccessibleSummaryText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GetAccessibleSummaryText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        UWidget* GenerateWidgetForString__DelegateSignature(FString& Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GenerateWidgetForString__DelegateSignature", 24)
            UE_COPY_PROPERTY_CUSTOM(Item, FString, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x10)
        }
        UWidget* GenerateWidgetForObject__DelegateSignature(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:GenerateWidgetForObject__DelegateSignature", 16)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x8)
        }
        void ForceVolatile(bool bForce)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:ForceVolatile", 1)
            UE_COPY_PROPERTY_CUSTOM(bForce, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void ForceLayoutPrepass()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Widget:ForceLayoutPrepass", 0)
            UE_CALL_FUNCTION()
        }
    };


}

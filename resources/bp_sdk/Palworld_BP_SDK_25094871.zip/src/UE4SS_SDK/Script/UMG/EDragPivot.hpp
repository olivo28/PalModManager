#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EDragPivot : uint8
    {
        MouseDown,
        TopLeft,
        TopCenter,
        TopRight,
        CenterLeft,
        CenterCenter,
        CenterRight,
        BottomLeft,
        BottomCenter,
        BottomRight,
    };
}

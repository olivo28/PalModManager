#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardDismissAction.hpp>
#include <UE4SS_SDK/Script/Slate/VirtualKeyboardOptions.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextCommit.hpp>
#include <UE4SS_SDK/Script/SlateCore/EditableTextBoxStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/TextBlockStyle.hpp>
#include <UE4SS_SDK/Script/UMG/TextLayoutWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x170
    // Size: 0x1080 (unaligned: 0x1080, alignment: 0x10)
    class RC_UE4SS_SDK_API UMultiLineEditableTextBox : public WSDK::UTextLayoutWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x170
        FText HintText{}; // 0x188
        FScriptDelegate HintTextDelegate{}; // 0x1A0
        FEditableTextBoxStyle WidgetStyle{}; // 0x1B0
        bool bIsReadOnly{}; // 0x1040
        bool AllowContextMenu{}; // 0x1041
        FVirtualKeyboardOptions VirtualKeyboardOptions{}; // 0x1042
        EVirtualKeyboardDismissAction VirtualKeyboardDismissAction{}; // 0x1043
        uint8 padding_1[0x4]{}; // 0x1044
        FMulticastScriptDelegate OnTextChanged{}; // 0x1048
        FMulticastScriptDelegate OnTextCommitted{}; // 0x1058
        uint8 padding_2[0x18]{}; // 0x1068

        // Functions.
        void SetTextStyle(FTextBlockStyle& InTextStyle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetTextStyle", 848)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTextStyle, FTextBlockStyle, 0x0)
        }
        void SetText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsReadOnly(bool bReadOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetIsReadOnly", 1)
            UE_COPY_PROPERTY_CUSTOM(bReadOnly, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHintText(FText InHintText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetHintText", 24)
            UE_COPY_PROPERTY_CUSTOM(InHintText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetForegroundColor(FLinearColor Color)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetForegroundColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetError(FText InError)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:SetError", 24)
            UE_COPY_PROPERTY_CUSTOM(InError, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(FText& Text, TEnumAsByte<ETextCommit::Type> CommitMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature", 25)
            UE_COPY_PROPERTY_CUSTOM(CommitMethod, TEnumAsByte<ETextCommit::Type>, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(FText& Text)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:OnMultiLineEditableTextBoxChangedEvent__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FText GetHintText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableTextBox:GetHintText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
    };


}

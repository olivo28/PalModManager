#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/UMG/SlateMeshVertex.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMaterialInterface;

    // Super Size: 0x28
    // Size: 0x70 (unaligned: 0x70, alignment: 0x8)
    class RC_UE4SS_SDK_API USlateVectorArtData : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TArray<FSlateMeshVertex> VertexData{}; // 0x28
        TArray<uint32> IndexData{}; // 0x38
        UMaterialInterface* Material{}; // 0x48
        FVector2D ExtentMin{}; // 0x50
        FVector2D ExtentMax{}; // 0x60

        // Functions.
    };


}

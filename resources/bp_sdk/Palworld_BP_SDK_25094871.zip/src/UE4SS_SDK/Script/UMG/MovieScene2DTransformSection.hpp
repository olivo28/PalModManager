#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneFloatChannel.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSection.hpp>
#include <UE4SS_SDK/Script/UMG/MovieScene2DTransformMask.hpp>

namespace WSDK
{
    // Super Size: 0xF0
    // Size: 0x870 (unaligned: 0x870, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieScene2DTransformSection : public WSDK::UMovieSceneSection
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0xF0
        FMovieScene2DTransformMask TransformMask{}; // 0xF8
        uint8 padding_2[0x4]{}; // 0xFC
        FMovieSceneFloatChannel Translation[2]{}; // 0x100
        FMovieSceneFloatChannel Rotation{}; // 0x320
        FMovieSceneFloatChannel Scale[2]{}; // 0x430
        FMovieSceneFloatChannel Shear[2]{}; // 0x650

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/Visual.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UPanelWidget;
    class UWidget;

    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UPanelSlot : public WSDK::UVisual
    {
    public:
        // Properties.
        UPanelWidget* Parent{}; // 0x28
        UWidget* Content{}; // 0x30

        // Functions.
    };


}

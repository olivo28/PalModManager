#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetDesignFlags
    {
        None,
        Designing,
        ShowOutline,
        ExecutePreConstruct = 0x4,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/PointerEvent.hpp>
#include <UE4SS_SDK/Script/UMG/EDragPivot.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UObject;
    class UWidget;

    // Super Size: 0x28
    // Size: 0x90 (unaligned: 0x90, alignment: 0x8)
    class RC_UE4SS_SDK_API UDragDropOperation : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FString Tag{}; // 0x28
        UObject* Payload{}; // 0x38
        UWidget* DefaultDragVisual{}; // 0x40
        EDragPivot Pivot{}; // 0x48
        uint8 padding_1[0x7]{}; // 0x49
        FVector2D Offset{}; // 0x50
        FMulticastScriptDelegate OnDrop{}; // 0x60
        FMulticastScriptDelegate OnDragCancelled{}; // 0x70
        FMulticastScriptDelegate OnDragged{}; // 0x80

        // Functions.
        void Drop(FPointerEvent& PointerEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DragDropOperation:Drop", 152)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x0)
        }
        void Dragged(FPointerEvent& PointerEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DragDropOperation:Dragged", 152)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x0)
        }
        void DragCancelled(FPointerEvent& PointerEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DragDropOperation:DragCancelled", 152)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x0)
        }
    };


}

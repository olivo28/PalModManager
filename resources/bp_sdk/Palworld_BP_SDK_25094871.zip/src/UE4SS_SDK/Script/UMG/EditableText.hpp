#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/ETextJustify.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardDismissAction.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardTrigger.hpp>
#include <UE4SS_SDK/Script/Slate/VirtualKeyboardOptions.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextCommit.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextOverflowPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/EditableTextStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/UMG/EVirtualKeyboardType.hpp>
#include <UE4SS_SDK/Script/UMG/ShapedTextOptions.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UMaterialInterface;

    // Super Size: 0x150
    // Size: 0x4E0 (unaligned: 0x4E0, alignment: 0x10)
    class RC_UE4SS_SDK_API UEditableText : public WSDK::UWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x150
        FScriptDelegate TextDelegate{}; // 0x168
        FText HintText{}; // 0x178
        FScriptDelegate HintTextDelegate{}; // 0x190
        FEditableTextStyle WidgetStyle{}; // 0x1A0
        bool IsReadOnly{}; // 0x490
        bool IsPassword{}; // 0x491
        uint8 padding_1[0x2]{}; // 0x492
        float MinimumDesiredWidth{}; // 0x494
        bool IsCaretMovedWhenGainFocus{}; // 0x498
        bool SelectAllTextWhenFocused{}; // 0x499
        bool RevertTextOnEscape{}; // 0x49A
        bool ClearKeyboardFocusOnCommit{}; // 0x49B
        bool SelectAllTextOnCommit{}; // 0x49C
        bool AllowContextMenu{}; // 0x49D
        TEnumAsByte<EVirtualKeyboardType::Type> KeyboardType{}; // 0x49E
        FVirtualKeyboardOptions VirtualKeyboardOptions{}; // 0x49F
        EVirtualKeyboardTrigger VirtualKeyboardTrigger{}; // 0x4A0
        EVirtualKeyboardDismissAction VirtualKeyboardDismissAction{}; // 0x4A1
        TEnumAsByte<ETextJustify::Type> Justification{}; // 0x4A2
        ETextOverflowPolicy OverflowPolicy{}; // 0x4A3
        FShapedTextOptions ShapedTextOptions{}; // 0x4A4
        uint8 padding_2[0x1]{}; // 0x4A7
        FMulticastScriptDelegate OnTextChanged{}; // 0x4A8
        FMulticastScriptDelegate OnTextCommitted{}; // 0x4B8
        uint8 padding_3[0x18]{}; // 0x4C8

        // Functions.
        void SetTextOverflowPolicy(ETextOverflowPolicy InOverflowPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetTextOverflowPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InOverflowPolicy, ETextOverflowPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinimumDesiredWidth(float InMinDesiredWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetMinimumDesiredWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetJustification(TEnumAsByte<ETextJustify::Type> InJustification)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetJustification", 1)
            UE_COPY_PROPERTY_CUSTOM(InJustification, TEnumAsByte<ETextJustify::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsReadOnly(bool InbIsReadyOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetIsReadOnly", 1)
            UE_COPY_PROPERTY_CUSTOM(InbIsReadyOnly, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsPassword(bool InbIsPassword)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetIsPassword", 1)
            UE_COPY_PROPERTY_CUSTOM(InbIsPassword, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHintText(FText InHintText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetHintText", 24)
            UE_COPY_PROPERTY_CUSTOM(InHintText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontOutlineMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetFontOutlineMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetFontMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFont(FSlateFontInfo InFontInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:SetFont", 96)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontObject, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontMaterial, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FFontOutlineSettings, InFontInfo.OutlineSettings, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, InFontInfo.TypefaceFontName, 0x0, 0x48)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.Size, 0x0, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.LetterSpacing, 0x0, 0x54)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InFontInfo.SkewAmount, 0x0, 0x58)
            UE_CALL_FUNCTION()
        }
        void OnEditableTextCommittedEvent__DelegateSignature(FText& Text, TEnumAsByte<ETextCommit::Type> CommitMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:OnEditableTextCommittedEvent__DelegateSignature", 25)
            UE_COPY_PROPERTY_CUSTOM(CommitMethod, TEnumAsByte<ETextCommit::Type>, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        void OnEditableTextChangedEvent__DelegateSignature(FText& Text)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:OnEditableTextChangedEvent__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        TEnumAsByte<ETextJustify::Type> GetJustification()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:GetJustification", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TEnumAsByte<ETextJustify::Type>, 0x0)
        }
        FText GetHintText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:GetHintText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FSlateFontInfo GetFont()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableText:GetFont", 96)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateFontInfo, 0x0)
        }
    };


}

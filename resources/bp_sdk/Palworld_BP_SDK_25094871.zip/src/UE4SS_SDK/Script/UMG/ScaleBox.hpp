#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/EStretch.hpp>
#include <UE4SS_SDK/Script/Slate/EStretchDirection.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x188 (unaligned: 0x188, alignment: 0x8)
    class RC_UE4SS_SDK_API UScaleBox : public WSDK::UContentWidget
    {
    public:
        // Properties.
        TEnumAsByte<EStretch::Type> Stretch{}; // 0x168
        TEnumAsByte<EStretchDirection::Type> StretchDirection{}; // 0x169
        uint8 padding_1[0x2]{}; // 0x16A
        float UserSpecifiedScale{}; // 0x16C
        bool IgnoreInheritedScale{}; // 0x170
        uint8 padding_2[0x17]{}; // 0x171

        // Functions.
        void SetUserSpecifiedScale(float InUserSpecifiedScale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScaleBox:SetUserSpecifiedScale", 4)
            UE_COPY_PROPERTY_CUSTOM(InUserSpecifiedScale, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStretchDirection(TEnumAsByte<EStretchDirection::Type> InStretchDirection)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScaleBox:SetStretchDirection", 1)
            UE_COPY_PROPERTY_CUSTOM(InStretchDirection, TEnumAsByte<EStretchDirection::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStretch(TEnumAsByte<EStretch::Type> InStretch)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScaleBox:SetStretch", 1)
            UE_COPY_PROPERTY_CUSTOM(InStretch, TEnumAsByte<EStretch::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScaleBox:SetIgnoreInheritedScale", 1)
            UE_COPY_PROPERTY_CUSTOM(bInIgnoreInheritedScale, bool, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

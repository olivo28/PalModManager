#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x240 (unaligned: 0x240, alignment: 0x10)
    class RC_UE4SS_SDK_API UThrobber : public WSDK::UWidget
    {
    public:
        // Properties.
        int32 NumberOfPieces{}; // 0x150
        bool bAnimateHorizontally{}; // 0x154
        bool bAnimateVertically{}; // 0x155
        bool bAnimateOpacity{}; // 0x156
        uint8 padding_1[0x9]{}; // 0x157
        FSlateBrush Image{}; // 0x160
        uint8 padding_2[0x10]{}; // 0x230

        // Functions.
        void SetNumberOfPieces(int32 InNumberOfPieces)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Throbber:SetNumberOfPieces", 4)
            UE_COPY_PROPERTY_CUSTOM(InNumberOfPieces, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAnimateVertically(bool bInAnimateVertically)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Throbber:SetAnimateVertically", 1)
            UE_COPY_PROPERTY_CUSTOM(bInAnimateVertically, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAnimateOpacity(bool bInAnimateOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Throbber:SetAnimateOpacity", 1)
            UE_COPY_PROPERTY_CUSTOM(bInAnimateOpacity, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAnimateHorizontally(bool bInAnimateHorizontally)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Throbber:SetAnimateHorizontally", 1)
            UE_COPY_PROPERTY_CUSTOM(bInAnimateHorizontally, bool, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ComboBoxStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/ESelectInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/TableRowStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x150
    // Size: 0x15B0 (unaligned: 0x15B0, alignment: 0x10)
    class RC_UE4SS_SDK_API UComboBoxKey : public WSDK::UWidget
    {
    public:
        // Properties.
        TArray<FName> Options{}; // 0x150
        FName SelectedOption{}; // 0x160
        uint8 padding_1[0x8]{}; // 0x168
        FComboBoxStyle WidgetStyle{}; // 0x170
        FTableRowStyle ItemStyle{}; // 0x7D0
        FSlateColor ForegroundColor{}; // 0x1520
        FMargin ContentPadding{}; // 0x1534
        float MaxListHeight{}; // 0x1544
        bool bHasDownArrow{}; // 0x1548
        bool bEnableGamepadNavigationMode{}; // 0x1549
        bool bIsFocusable{}; // 0x154A
        uint8 padding_2[0x1]{}; // 0x154B
        FScriptDelegate OnGenerateContentWidget{}; // 0x154C
        FScriptDelegate OnGenerateItemWidget{}; // 0x155C
        uint8 padding_3[0x4]{}; // 0x156C
        FMulticastScriptDelegate OnSelectionChanged{}; // 0x1570
        FMulticastScriptDelegate OnOpening{}; // 0x1580
        uint8 padding_4[0x20]{}; // 0x1590

        // Functions.
        void SetSelectedOption(FName Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:SetSelectedOption", 8)
            UE_COPY_PROPERTY_CUSTOM(Option, FName, 0x0)
            UE_CALL_FUNCTION()
        }
        bool RemoveOption(FName Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:RemoveOption", 9)
            UE_COPY_PROPERTY_CUSTOM(Option, FName, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        void OnSelectionChangedEvent__DelegateSignature(FName SelectedItem, TEnumAsByte<ESelectInfo::Type> SelectionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:OnSelectionChangedEvent__DelegateSignature", 9)
            UE_COPY_PROPERTY_CUSTOM(SelectedItem, FName, 0x0)
            UE_COPY_PROPERTY_CUSTOM(SelectionType, TEnumAsByte<ESelectInfo::Type>, 0x8)
            UE_CALL_FUNCTION()
        }
        void OnOpeningEvent__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:OnOpeningEvent__DelegateSignature", 0)
            UE_CALL_FUNCTION()
        }
        bool IsOpen()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:IsOpen", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FName GetSelectedOption()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:GetSelectedOption", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FName, 0x0)
        }
        UWidget* GenerateWidgetEvent__DelegateSignature(FName Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:GenerateWidgetEvent__DelegateSignature", 16)
            UE_COPY_PROPERTY_CUSTOM(Item, FName, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x8)
        }
        void ClearSelection()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:ClearSelection", 0)
            UE_CALL_FUNCTION()
        }
        void ClearOptions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:ClearOptions", 0)
            UE_CALL_FUNCTION()
        }
        void AddOption(FName Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxKey:AddOption", 8)
            UE_COPY_PROPERTY_CUSTOM(Option, FName, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

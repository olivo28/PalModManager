#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardDismissAction.hpp>
#include <UE4SS_SDK/Script/Slate/VirtualKeyboardOptions.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextCommit.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/TextBlockStyle.hpp>
#include <UE4SS_SDK/Script/UMG/TextLayoutWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UMaterialInterface;

    // Super Size: 0x170
    // Size: 0x540 (unaligned: 0x540, alignment: 0x10)
    class RC_UE4SS_SDK_API UMultiLineEditableText : public WSDK::UTextLayoutWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x170
        FText HintText{}; // 0x188
        FScriptDelegate HintTextDelegate{}; // 0x1A0
        FTextBlockStyle WidgetStyle{}; // 0x1B0
        bool bIsReadOnly{}; // 0x500
        bool SelectAllTextWhenFocused{}; // 0x501
        bool ClearTextSelectionOnFocusLoss{}; // 0x502
        bool RevertTextOnEscape{}; // 0x503
        bool ClearKeyboardFocusOnCommit{}; // 0x504
        bool AllowContextMenu{}; // 0x505
        FVirtualKeyboardOptions VirtualKeyboardOptions{}; // 0x506
        EVirtualKeyboardDismissAction VirtualKeyboardDismissAction{}; // 0x507
        FMulticastScriptDelegate OnTextChanged{}; // 0x508
        FMulticastScriptDelegate OnTextCommitted{}; // 0x518
        uint8 padding_1[0x18]{}; // 0x528

        // Functions.
        void SetWidgetStyle(FTextBlockStyle& InWidgetStyle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetWidgetStyle", 848)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InWidgetStyle, FTextBlockStyle, 0x0)
        }
        void SetText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsReadOnly(bool bReadOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetIsReadOnly", 1)
            UE_COPY_PROPERTY_CUSTOM(bReadOnly, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHintText(FText InHintText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetHintText", 24)
            UE_COPY_PROPERTY_CUSTOM(InHintText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontOutlineMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetFontOutlineMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetFontMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFont(FSlateFontInfo InFontInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:SetFont", 96)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontObject, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontMaterial, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FFontOutlineSettings, InFontInfo.OutlineSettings, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, InFontInfo.TypefaceFontName, 0x0, 0x48)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.Size, 0x0, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.LetterSpacing, 0x0, 0x54)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InFontInfo.SkewAmount, 0x0, 0x58)
            UE_CALL_FUNCTION()
        }
        void OnMultiLineEditableTextCommittedEvent__DelegateSignature(FText& Text, TEnumAsByte<ETextCommit::Type> CommitMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:OnMultiLineEditableTextCommittedEvent__DelegateSignature", 25)
            UE_COPY_PROPERTY_CUSTOM(CommitMethod, TEnumAsByte<ETextCommit::Type>, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        void OnMultiLineEditableTextChangedEvent__DelegateSignature(FText& Text)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:OnMultiLineEditableTextChangedEvent__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FText GetHintText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:GetHintText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FSlateFontInfo GetFont()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MultiLineEditableText:GetFont", 96)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateFontInfo, 0x0)
        }
    };


}

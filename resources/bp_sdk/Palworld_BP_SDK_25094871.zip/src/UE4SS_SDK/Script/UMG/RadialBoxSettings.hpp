#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FRadialBoxSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FRadialBoxSettings& operator=(const FRadialBoxSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float StartingAngle{}; // 0x0
        bool bDistributeItemsEvenly{}; // 0x4
        uint8 padding_1[0x3]{}; // 0x5
        float AngleBetweenItems{}; // 0x8
        float SectorCentralAngle{}; // 0xC

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateAccessibleBehavior.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x80 (unaligned: 0x80, alignment: 0x8)
    class RC_UE4SS_SDK_API USlateAccessibleWidgetData : public RC::Unreal::UObject
    {
    public:
        // Properties.
        bool bCanChildrenBeAccessible{}; // 0x28
        ESlateAccessibleBehavior AccessibleBehavior{}; // 0x29
        ESlateAccessibleBehavior AccessibleSummaryBehavior{}; // 0x2A
        uint8 padding_1[0x5]{}; // 0x2B
        FText AccessibleText{}; // 0x30
        FScriptDelegate AccessibleTextDelegate{}; // 0x48
        FText AccessibleSummaryText{}; // 0x58
        FScriptDelegate AccessibleSummaryTextDelegate{}; // 0x70

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x180 (unaligned: 0x180, alignment: 0x8)
    class RC_UE4SS_SDK_API USafeZone : public WSDK::UContentWidget
    {
    public:
        // Properties.
        bool PadLeft{}; // 0x168
        bool PadRight{}; // 0x169
        bool PadTop{}; // 0x16A
        bool PadBottom{}; // 0x16B
        uint8 padding_1[0x14]{}; // 0x16C

        // Functions.
        void SetSidesToPad(bool InPadLeft, bool InPadRight, bool InPadTop, bool InPadBottom)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SafeZone:SetSidesToPad", 4)
            UE_COPY_PROPERTY_CUSTOM(InPadLeft, bool, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InPadRight, bool, 0x1)
            UE_COPY_PROPERTY_CUSTOM(InPadTop, bool, 0x2)
            UE_COPY_PROPERTY_CUSTOM(InPadBottom, bool, 0x3)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/InputCore/Key.hpp>
#include <UE4SS_SDK/Script/Slate/InputChord.hpp>
#include <UE4SS_SDK/Script/SlateCore/ButtonStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/TextBlockStyle.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateVisibility.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x940 (unaligned: 0x940, alignment: 0x10)
    class RC_UE4SS_SDK_API UInputKeySelector : public WSDK::UWidget
    {
    public:
        // Properties.
        FButtonStyle WidgetStyle{}; // 0x150
        FTextBlockStyle TextStyle{}; // 0x540
        FInputChord SelectedKey{}; // 0x890
        FMargin Margin{}; // 0x8B0
        FText KeySelectionText{}; // 0x8C0
        FText NoKeySpecifiedText{}; // 0x8D8
        bool bAllowModifierKeys{}; // 0x8F0
        bool bAllowGamepadKeys{}; // 0x8F1
        uint8 padding_1[0x6]{}; // 0x8F2
        TArray<FKey> EscapeKeys{}; // 0x8F8
        FMulticastScriptDelegate OnKeySelected{}; // 0x908
        FMulticastScriptDelegate OnIsSelectingKeyChanged{}; // 0x918
        uint8 padding_2[0x18]{}; // 0x928

        // Functions.
        void SetTextBlockVisibility(ESlateVisibility InVisibility)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetTextBlockVisibility", 1)
            UE_COPY_PROPERTY_CUSTOM(InVisibility, ESlateVisibility, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSelectedKey(FInputChord& InSelectedKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetSelectedKey", 32)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectedKey, FInputChord, 0x0)
        }
        void SetNoKeySpecifiedText(FText InNoKeySpecifiedText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetNoKeySpecifiedText", 24)
            UE_COPY_PROPERTY_CUSTOM(InNoKeySpecifiedText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetKeySelectionText(FText InKeySelectionText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetKeySelectionText", 24)
            UE_COPY_PROPERTY_CUSTOM(InKeySelectionText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetEscapeKeys(TArray<FKey>& InKeys)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetEscapeKeys", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InKeys, TArray<FKey>, 0x0)
        }
        void SetAllowModifierKeys(bool bInAllowModifierKeys)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetAllowModifierKeys", 1)
            UE_COPY_PROPERTY_CUSTOM(bInAllowModifierKeys, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAllowGamepadKeys(bool bInAllowGamepadKeys)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:SetAllowGamepadKeys", 1)
            UE_COPY_PROPERTY_CUSTOM(bInAllowGamepadKeys, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnKeySelected__DelegateSignature(FInputChord SelectedKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:OnKeySelected__DelegateSignature", 32)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FKey, SelectedKey.Key, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, SelectedKey.bShift, 0x0, 0x18)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, SelectedKey.bCtrl, 0x0, 0x18)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, SelectedKey.bAlt, 0x0, 0x18)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, SelectedKey.bCmd, 0x0, 0x18)
            UE_CALL_FUNCTION()
        }
        void OnIsSelectingKeyChanged__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:OnIsSelectingKeyChanged__DelegateSignature", 0)
            UE_CALL_FUNCTION()
        }
        bool GetIsSelectingKey()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InputKeySelector:GetIsSelectingKey", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

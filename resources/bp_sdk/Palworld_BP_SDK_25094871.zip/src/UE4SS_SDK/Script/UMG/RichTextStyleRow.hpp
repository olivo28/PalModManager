#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TableRowBase.hpp>
#include <UE4SS_SDK/Script/SlateCore/TextBlockStyle.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x360 (unaligned: 0x360, alignment: 0x10)
    struct RC_UE4SS_SDK_API FRichTextStyleRow : public WSDK::FTableRowBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x360;
        }

        FRichTextStyleRow& operator=(const FRichTextStyleRow& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FTextBlockStyle TextStyle{}; // 0x10

        // Functions.
    };


}

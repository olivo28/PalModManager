#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/ETextJustify.hpp>
#include <UE4SS_SDK/Script/Slate/ETextWrappingPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/ShapedTextOptions.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x170 (unaligned: 0x170, alignment: 0x8)
    class RC_UE4SS_SDK_API UTextLayoutWidget : public WSDK::UWidget
    {
    public:
        // Properties.
        FShapedTextOptions ShapedTextOptions{}; // 0x150
        TEnumAsByte<ETextJustify::Type> Justification{}; // 0x153
        ETextWrappingPolicy WrappingPolicy{}; // 0x154
        uint8 AutoWrapText : 1{}; // 0x155 (0x1)
        uint8 padding_1 : 1{}; // 0x155 (0x2)
        uint8 padding_2 : 1{}; // 0x155 (0x4)
        uint8 padding_3 : 1{}; // 0x155 (0x8)
        uint8 padding_4 : 1{}; // 0x155 (0x10)
        uint8 padding_5 : 1{}; // 0x155 (0x20)
        uint8 padding_6 : 1{}; // 0x155 (0x40)
        uint8 padding_7 : 1{}; // 0x155 (0x80)
        uint8 padding_8[0x2]{}; // 0x156
        float WrapTextAt{}; // 0x158
        FMargin Margin{}; // 0x15C
        float LineHeightPercentage{}; // 0x16C

        // Functions.
        void SetJustification(TEnumAsByte<ETextJustify::Type> InJustification)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextLayoutWidget:SetJustification", 1)
            UE_COPY_PROPERTY_CUSTOM(InJustification, TEnumAsByte<ETextJustify::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

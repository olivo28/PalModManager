#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Rotator.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AActor;
    class UWorld;

    // Super Size: 0x168
    // Size: 0x1B8 (unaligned: 0x1B8, alignment: 0x8)
    class RC_UE4SS_SDK_API UViewport : public WSDK::UContentWidget
    {
    public:
        // Properties.
        FLinearColor BackgroundColor{}; // 0x168
        uint8 padding_1[0x40]{}; // 0x178

        // Functions.
        AActor* Spawn(TSubclassOf<AActor> actorClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:Spawn", 16)
            UE_COPY_PROPERTY_CUSTOM(actorClass, TSubclassOf<AActor>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(AActor*, 0x8)
        }
        void SetViewRotation(FRotator Rotation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:SetViewRotation", 24)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Rotation.Pitch, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Rotation.Yaw, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Rotation.Roll, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetViewLocation(FVector Location)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:SetViewLocation", 24)
            UE_COPY_VECTOR(Location, 0x0)
            UE_CALL_FUNCTION()
        }
        FRotator GetViewRotation()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:GetViewRotation", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FRotator, 0x0)
        }
        UWorld* GetViewportWorld()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:GetViewportWorld", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWorld*, 0x0)
        }
        FVector GetViewLocation()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Viewport:GetViewLocation", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector, 0x0)
        }
    };


}

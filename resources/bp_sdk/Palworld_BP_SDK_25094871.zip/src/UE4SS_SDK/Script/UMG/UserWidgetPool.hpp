#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UUserWidget;

    // Super Size: 0x0
    // Size: 0x88 (unaligned: 0x88, alignment: 0x8)
    struct RC_UE4SS_SDK_API FUserWidgetPool
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x88;
        }

        FUserWidgetPool& operator=(const FUserWidgetPool& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TArray<UUserWidget*> ActiveWidgets{}; // 0x0
        TArray<UUserWidget*> InactiveWidgets{}; // 0x10
        uint8 padding_1[0x68]{}; // 0x20

        // Functions.
    };


}

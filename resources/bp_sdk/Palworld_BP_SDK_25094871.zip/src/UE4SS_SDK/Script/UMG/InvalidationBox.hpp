#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x180 (unaligned: 0x180, alignment: 0x8)
    class RC_UE4SS_SDK_API UInvalidationBox : public WSDK::UContentWidget
    {
    public:
        // Properties.
        bool bCanCache{}; // 0x168
        bool CacheRelativeTransforms{}; // 0x169
        uint8 padding_1[0x16]{}; // 0x16A

        // Functions.
        void SetCanCache(bool CanCache)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InvalidationBox:SetCanCache", 1)
            UE_COPY_PROPERTY_CUSTOM(CanCache, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void InvalidateCache()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InvalidationBox:InvalidateCache", 0)
            UE_CALL_FUNCTION()
        }
        bool GetCanCache()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.InvalidationBox:GetCanCache", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <UE4SS_SDK/Script/UMG/SlateChildSize.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UStackBoxSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        FMargin Padding{}; // 0x38
        FSlateChildSize Size{}; // 0x48
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x50
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x51
        uint8 padding_1[0xE]{}; // 0x52

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetAnimationEvent : uint8
    {
        Started,
        Finished,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Slate/Anchors.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/AnchorData.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x88 (unaligned: 0x88, alignment: 0x8)
    class RC_UE4SS_SDK_API UCanvasPanelSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        FAnchorData LayoutData{}; // 0x38
        bool bAutoSize{}; // 0x78
        uint8 padding_1[0x3]{}; // 0x79
        int32 ZOrder{}; // 0x7C
        uint8 padding_2[0x8]{}; // 0x80

        // Functions.
        void SetZOrder(int32 InZOrder)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetZOrder", 4)
            UE_COPY_PROPERTY_CUSTOM(InZOrder, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSize(FVector2D InSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetSize", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InSize.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InSize.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetPosition(FVector2D InPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetPosition", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InPosition.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InPosition.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetOffsets(FMargin InOffset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetOffsets", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InOffset.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InOffset.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InOffset.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InOffset.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetMinimum(FVector2D InMinimumAnchors)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetMinimum", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InMinimumAnchors.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InMinimumAnchors.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetMaximum(FVector2D InMaximumAnchors)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetMaximum", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InMaximumAnchors.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InMaximumAnchors.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetLayout(FAnchorData& InLayoutData)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetLayout", 64)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InLayoutData, FAnchorData, 0x0)
        }
        void SetAutoSize(bool InbAutoSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetAutoSize", 1)
            UE_COPY_PROPERTY_CUSTOM(InbAutoSize, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAnchors(FAnchors InAnchors)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetAnchors", 32)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InAnchors.Minimum, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InAnchors.Maximum, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetAlignment(FVector2D InAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:SetAlignment", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InAlignment.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InAlignment.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        int32 GetZOrder()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetZOrder", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        FVector2D GetSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetSize", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        FVector2D GetPosition()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetPosition", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        FMargin GetOffsets()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetOffsets", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FMargin, 0x0)
        }
        FAnchorData GetLayout()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetLayout", 64)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FAnchorData, 0x0)
        }
        bool GetAutoSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetAutoSize", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FAnchors GetAnchors()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetAnchors", 32)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FAnchors, 0x0)
        }
        FVector2D GetAlignment()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CanvasPanelSlot:GetAlignment", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/ButtonStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonClickMethod.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonPressMethod.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonTouchMethod.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x5F0 (unaligned: 0x5F0, alignment: 0x10)
    class RC_UE4SS_SDK_API UButton : public WSDK::UContentWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x168
        FButtonStyle WidgetStyle{}; // 0x170
        FLinearColor ColorAndOpacity{}; // 0x560
        FLinearColor BackgroundColor{}; // 0x570
        TEnumAsByte<EButtonClickMethod::Type> ClickMethod{}; // 0x580
        TEnumAsByte<EButtonTouchMethod::Type> TouchMethod{}; // 0x581
        TEnumAsByte<EButtonPressMethod::Type> PressMethod{}; // 0x582
        bool IsFocusable{}; // 0x583
        uint8 padding_2[0x4]{}; // 0x584
        FMulticastScriptDelegate OnClicked{}; // 0x588
        FMulticastScriptDelegate OnPressed{}; // 0x598
        FMulticastScriptDelegate OnReleased{}; // 0x5A8
        FMulticastScriptDelegate OnHovered{}; // 0x5B8
        FMulticastScriptDelegate OnUnhovered{}; // 0x5C8
        uint8 padding_3[0x18]{}; // 0x5D8

        // Functions.
        void SetTouchMethod(TEnumAsByte<EButtonTouchMethod::Type> InTouchMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetTouchMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InTouchMethod, TEnumAsByte<EButtonTouchMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStyle(FButtonStyle& InStyle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetStyle", 1008)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InStyle, FButtonStyle, 0x0)
        }
        void SetPressMethod(TEnumAsByte<EButtonPressMethod::Type> InPressMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetPressMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InPressMethod, TEnumAsByte<EButtonPressMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetColorAndOpacity(FLinearColor InColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetClickMethod(TEnumAsByte<EButtonClickMethod::Type> InClickMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetClickMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InClickMethod, TEnumAsByte<EButtonClickMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBackgroundColor(FLinearColor InBackgroundColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:SetBackgroundColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBackgroundColor.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBackgroundColor.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBackgroundColor.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBackgroundColor.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        bool IsPressed()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Button:IsPressed", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

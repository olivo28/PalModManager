#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector4.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x290 (unaligned: 0x290, alignment: 0x10)
    class RC_UE4SS_SDK_API UBackgroundBlur : public WSDK::UContentWidget
    {
    public:
        // Properties.
        FMargin Padding{}; // 0x168
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x178
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x179
        bool bApplyAlphaToBlur{}; // 0x17A
        uint8 padding_1[0x1]{}; // 0x17B
        float BlurStrength{}; // 0x17C
        bool bOverrideAutoRadiusCalculation{}; // 0x180
        uint8 padding_2[0x3]{}; // 0x181
        int32 BlurRadius{}; // 0x184
        uint8 padding_3[0x8]{}; // 0x188
        FVector4 CornerRadius{}; // 0x190
        FSlateBrush LowQualityFallbackBrush{}; // 0x1B0
        uint8 padding_4[0x10]{}; // 0x280

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetLowQualityFallbackBrush(FSlateBrush& InBrush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetLowQualityFallbackBrush", 208)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InBrush, FSlateBrush, 0x0)
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetCornerRadius(FVector4 InCornerRadius)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetCornerRadius", 32)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InCornerRadius.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InCornerRadius.Y, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InCornerRadius.Z, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InCornerRadius.W, 0x0, 0x18)
            UE_CALL_FUNCTION()
        }
        void SetBlurStrength(float InStrength)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetBlurStrength", 4)
            UE_COPY_PROPERTY_CUSTOM(InStrength, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBlurRadius(int32 InBlurRadius)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetBlurRadius", 4)
            UE_COPY_PROPERTY_CUSTOM(InBlurRadius, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BackgroundBlur:SetApplyAlphaToBlur", 1)
            UE_COPY_PROPERTY_CUSTOM(bInApplyAlphaToBlur, bool, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x178 (unaligned: 0x178, alignment: 0x8)
    class RC_UE4SS_SDK_API UNamedSlot : public WSDK::UContentWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0x168

        // Functions.
    };


}

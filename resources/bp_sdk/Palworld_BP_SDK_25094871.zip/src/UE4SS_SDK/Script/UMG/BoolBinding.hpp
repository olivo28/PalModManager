#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PropertyBinding.hpp>

namespace WSDK
{
    // Super Size: 0x60
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UBoolBinding : public WSDK::UPropertyBinding
    {
    public:
        // Properties.

        // Functions.
        bool GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.BoolBinding:GetValue", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

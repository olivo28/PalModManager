#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateSizeRule.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSlateChildSize
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FSlateChildSize& operator=(const FSlateChildSize& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Value{}; // 0x0
        TEnumAsByte<ESlateSizeRule::Type> SizeRule{}; // 0x4
        uint8 padding_1[0x3]{}; // 0x5

        // Functions.
    };


}

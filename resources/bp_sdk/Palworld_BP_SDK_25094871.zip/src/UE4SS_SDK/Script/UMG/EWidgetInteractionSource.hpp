#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetInteractionSource : uint8
    {
        World,
        Mouse,
        CenterScreen,
        Custom,
    };
}

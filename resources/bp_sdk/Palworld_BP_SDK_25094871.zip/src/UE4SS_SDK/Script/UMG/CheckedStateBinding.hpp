#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ECheckBoxState.hpp>
#include <UE4SS_SDK/Script/UMG/PropertyBinding.hpp>

namespace WSDK
{
    // Super Size: 0x60
    // Size: 0x68 (unaligned: 0x68, alignment: 0x8)
    class RC_UE4SS_SDK_API UCheckedStateBinding : public WSDK::UPropertyBinding
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x60

        // Functions.
        ECheckBoxState GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckedStateBinding:GetValue", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ECheckBoxState, 0x0)
        }
    };


}

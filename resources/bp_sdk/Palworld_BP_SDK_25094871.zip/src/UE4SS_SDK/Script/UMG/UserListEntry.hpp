#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API IUserListEntry : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        void BP_OnItemSelectionChanged(bool bIsSelected)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntry:BP_OnItemSelectionChanged", 1)
            UE_COPY_PROPERTY_CUSTOM(bIsSelected, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void BP_OnItemExpansionChanged(bool bIsExpanded)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntry:BP_OnItemExpansionChanged", 1)
            UE_COPY_PROPERTY_CUSTOM(bIsExpanded, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void BP_OnEntryReleased()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntry:BP_OnEntryReleased", 0)
            UE_CALL_FUNCTION()
        }
    };


}

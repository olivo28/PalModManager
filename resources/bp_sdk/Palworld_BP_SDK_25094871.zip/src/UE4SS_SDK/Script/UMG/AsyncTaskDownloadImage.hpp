#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintAsyncActionBase.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    class UAsyncTaskDownloadImage;

    // Super Size: 0x30
    // Size: 0x50 (unaligned: 0x50, alignment: 0x8)
    class RC_UE4SS_SDK_API UAsyncTaskDownloadImage : public WSDK::UBlueprintAsyncActionBase
    {
    public:
        // Properties.
        FMulticastScriptDelegate OnSuccess{}; // 0x30
        FMulticastScriptDelegate OnFail{}; // 0x40

        // Functions.
        static UAsyncTaskDownloadImage* DownloadImage(FString& URL)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.AsyncTaskDownloadImage:DownloadImage", 24)
            UE_SET_STATIC_SELF("/Script/UMG.Default__AsyncTaskDownloadImage")
            UE_COPY_PROPERTY_CUSTOM(URL, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UAsyncTaskDownloadImage*, 0x10)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/RichTextBlockDecorator.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UDataTable;

    // Super Size: 0x28
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    class RC_UE4SS_SDK_API URichTextBlockImageDecorator : public WSDK::URichTextBlockDecorator
    {
    public:
        // Properties.
        UDataTable* ImageSet{}; // 0x28

        // Functions.
    };


}

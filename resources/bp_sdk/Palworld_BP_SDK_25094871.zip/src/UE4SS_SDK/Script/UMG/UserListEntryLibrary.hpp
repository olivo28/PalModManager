#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    class IUserListEntry;
    class UListViewBase;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UUserListEntryLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static bool IsListItemSelected(TScriptInterface<IUserListEntry> UserListEntry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntryLibrary:IsListItemSelected", 17)
            UE_SET_STATIC_SELF("/Script/UMG.Default__UserListEntryLibrary")
            UE_COPY_PROPERTY_CUSTOM(UserListEntry, TScriptInterface<IUserListEntry>, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static bool IsListItemExpanded(TScriptInterface<IUserListEntry> UserListEntry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntryLibrary:IsListItemExpanded", 17)
            UE_SET_STATIC_SELF("/Script/UMG.Default__UserListEntryLibrary")
            UE_COPY_PROPERTY_CUSTOM(UserListEntry, TScriptInterface<IUserListEntry>, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static UListViewBase* GetOwningListView(TScriptInterface<IUserListEntry> UserListEntry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserListEntryLibrary:GetOwningListView", 24)
            UE_SET_STATIC_SELF("/Script/UMG.Default__UserListEntryLibrary")
            UE_COPY_PROPERTY_CUSTOM(UserListEntry, TScriptInterface<IUserListEntry>, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UListViewBase*, 0x10)
        }
    };


}

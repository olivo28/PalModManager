#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/UMG/EDynamicBoxType.hpp>
#include <UE4SS_SDK/Script/UMG/RadialBoxSettings.hpp>
#include <UE4SS_SDK/Script/UMG/SlateChildSize.hpp>
#include <UE4SS_SDK/Script/UMG/UserWidgetPool.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UUserWidget;

    // Super Size: 0x150
    // Size: 0x230 (unaligned: 0x230, alignment: 0x8)
    class RC_UE4SS_SDK_API UDynamicEntryBoxBase : public WSDK::UWidget
    {
    public:
        // Properties.
        EDynamicBoxType EntryBoxType{}; // 0x150
        uint8 padding_1[0x7]{}; // 0x151
        FVector2D EntrySpacing{}; // 0x158
        TArray<FVector2D> SpacingPattern{}; // 0x168
        FSlateChildSize EntrySizeRule{}; // 0x178
        TEnumAsByte<EHorizontalAlignment> EntryHorizontalAlignment{}; // 0x180
        TEnumAsByte<EVerticalAlignment> EntryVerticalAlignment{}; // 0x181
        uint8 padding_2[0x2]{}; // 0x182
        int32 MaxElementSize{}; // 0x184
        FRadialBoxSettings RadialBoxSettings{}; // 0x188
        uint8 padding_3[0x10]{}; // 0x198
        FUserWidgetPool EntryWidgetPool{}; // 0x1A8

        // Functions.
        void SetRadialSettings(FRadialBoxSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBoxBase:SetRadialSettings", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FRadialBoxSettings, 0x0)
        }
        void SetEntrySpacing(FVector2D& InEntrySpacing)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBoxBase:SetEntrySpacing", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InEntrySpacing, FVector2D, 0x0)
        }
        int32 GetNumEntries()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBoxBase:GetNumEntries", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        TArray<UUserWidget*> GetAllEntries()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBoxBase:GetAllEntries", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UUserWidget*>, 0x0)
        }
    };


}

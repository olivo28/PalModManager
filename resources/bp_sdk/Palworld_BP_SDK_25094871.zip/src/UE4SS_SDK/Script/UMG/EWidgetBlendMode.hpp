#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetBlendMode : uint8
    {
        Opaque,
        Masked,
        Transparent,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/EMouseCursor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector4.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/Engine/EMouseLockMode.hpp>
#include <UE4SS_SDK/Script/Engine/EWindowTitleBarMode.hpp>
#include <UE4SS_SDK/Script/InputCore/Key.hpp>
#include <UE4SS_SDK/Script/SlateCore/AnalogInputEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/CharacterEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/EColorVisionDeficiency.hpp>
#include <UE4SS_SDK/Script/SlateCore/InputEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/KeyEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/NavigationEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/PointerEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/UMG/EventReply.hpp>
#include <UE4SS_SDK/Script/UMG/PaintContext.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class APlayerController;
    class UDragDropOperation;
    class UFont;
    class UInterface;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class UObject;
    class USlateBrushAsset;
    class UTexture2D;
    class UUserWidget;
    class UWidget;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetBlueprintLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FEventReply UnlockMouse(FEventReply& Reply)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:UnlockMouse", 368)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xB8)
        }
        static FEventReply Unhandled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:Unhandled", 184)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x0)
        }
        static void SetWindowTitleBarState(UWidget* TitleBarContent, EWindowTitleBarMode Mode, bool bTitleBarDragEnabled, bool bWindowButtonsVisible, bool bTitleBarVisible)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarState", 12)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(TitleBarContent, UWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Mode, EWindowTitleBarMode, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bTitleBarDragEnabled, bool, 0x9)
            UE_COPY_PROPERTY_CUSTOM(bWindowButtonsVisible, bool, 0xA)
            UE_COPY_PROPERTY_CUSTOM(bTitleBarVisible, bool, 0xB)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetWindowTitleBarOnCloseClickedDelegate(FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarOnCloseClickedDelegate", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetWindowTitleBarCloseButtonActive(bool bActive)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetWindowTitleBarCloseButtonActive", 1)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(bActive, bool, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static FEventReply SetUserFocus(FEventReply& Reply, UWidget* FocusWidget, bool bInAllUsers)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetUserFocus", 384)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(FocusWidget, UWidget*, 0xB8)
            UE_COPY_PROPERTY_CUSTOM(bInAllUsers, bool, 0xC0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC8)
        }
        static FEventReply SetMousePosition(FEventReply& Reply, FVector2D NewMousePosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetMousePosition", 384)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, NewMousePosition.X, 0xB8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, NewMousePosition.Y, 0xB8, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC8)
        }
        static void SetInputMode_UIOnlyEx(APlayerController* PlayerController, UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode, bool bFlushInput)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_UIOnlyEx", 18)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InWidgetToFocus, UWidget*, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InMouseLockMode, EMouseLockMode, 0x10)
            UE_COPY_PROPERTY_CUSTOM(bFlushInput, bool, 0x11)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetInputMode_GameOnly(APlayerController* PlayerController, bool bFlushInput)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_GameOnly", 9)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bFlushInput, bool, 0x8)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetInputMode_GameAndUIEx(APlayerController* PlayerController, UWidget* InWidgetToFocus, EMouseLockMode InMouseLockMode, bool bHideCursorDuringCapture, bool bFlushInput)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetInputMode_GameAndUIEx", 19)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InWidgetToFocus, UWidget*, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InMouseLockMode, EMouseLockMode, 0x10)
            UE_COPY_PROPERTY_CUSTOM(bHideCursorDuringCapture, bool, 0x11)
            UE_COPY_PROPERTY_CUSTOM(bFlushInput, bool, 0x12)
            UE_CALL_STATIC_FUNCTION()
        }
        static bool SetHardwareCursor(UObject* WorldContextObject, TEnumAsByte<EMouseCursor::Type> CursorShape, FName CursorName, FVector2D HotSpot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetHardwareCursor", 41)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(CursorShape, TEnumAsByte<EMouseCursor::Type>, 0x8)
            UE_COPY_PROPERTY_CUSTOM(CursorName, FName, 0xC)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, HotSpot.X, 0x18, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, HotSpot.Y, 0x18, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x28)
        }
        static void SetFocusToGameViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetFocusToGameViewport", 0)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetColorVisionDeficiencyType(EColorVisionDeficiency Type, float Severity, bool CorrectDeficiency, bool ShowCorrectionWithDeficiency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetColorVisionDeficiencyType", 10)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Type, EColorVisionDeficiency, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Severity, float, 0x4)
            UE_COPY_PROPERTY_CUSTOM(CorrectDeficiency, bool, 0x8)
            UE_COPY_PROPERTY_CUSTOM(ShowCorrectionWithDeficiency, bool, 0x9)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetBrushResourceToTexture(FSlateBrush& Brush, UTexture2D* Texture)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetBrushResourceToTexture", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Texture, UTexture2D*, 0xD0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
        }
        static void SetBrushResourceToMaterial(FSlateBrush& Brush, UMaterialInterface* Material)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:SetBrushResourceToMaterial", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Material, UMaterialInterface*, 0xD0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
        }
        static void RestorePreviousWindowTitleBarState()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:RestorePreviousWindowTitleBarState", 0)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static FEventReply ReleaseMouseCapture(FEventReply& Reply)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:ReleaseMouseCapture", 368)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xB8)
        }
        static FEventReply ReleaseJoystickCapture(FEventReply& Reply, bool bInAllJoysticks)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:ReleaseJoystickCapture", 376)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(bInAllJoysticks, bool, 0xB8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC0)
        }
        void OnGameWindowCloseButtonClickedDelegate__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:OnGameWindowCloseButtonClickedDelegate__DelegateSignature", 0)
            UE_CALL_FUNCTION()
        }
        static FSlateBrush NoResourceBrush()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:NoResourceBrush", 208)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateBrush, 0x0)
        }
        static FSlateBrush MakeBrushFromTexture(UTexture2D* Texture, int32 Width, int32 Height)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromTexture", 224)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Texture, UTexture2D*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Width, int32, 0x8)
            UE_COPY_PROPERTY_CUSTOM(Height, int32, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateBrush, 0x10)
        }
        static FSlateBrush MakeBrushFromMaterial(UMaterialInterface* Material, int32 Width, int32 Height)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromMaterial", 224)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(Material, UMaterialInterface*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Width, int32, 0x8)
            UE_COPY_PROPERTY_CUSTOM(Height, int32, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateBrush, 0x10)
        }
        static FSlateBrush MakeBrushFromAsset(USlateBrushAsset* BrushAsset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:MakeBrushFromAsset", 224)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(BrushAsset, USlateBrushAsset*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateBrush, 0x10)
        }
        static FEventReply LockMouse(FEventReply& Reply, UWidget* CapturingWidget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:LockMouse", 376)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(CapturingWidget, UWidget*, 0xB8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC0)
        }
        static bool IsDragDropping()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:IsDragDropping", 1)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        static FEventReply Handled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:Handled", 184)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x0)
        }
        static void GetSafeZonePadding(UObject* WorldContextObject, FVector4& SafePadding, FVector2D& SafePaddingScale, FVector4& SpillOverPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetSafeZonePadding", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(SafePadding, FVector4, 0x10)
            UE_COPY_OUT_PROPERTY_CUSTOM(SafePaddingScale, FVector2D, 0x30)
            UE_COPY_OUT_PROPERTY_CUSTOM(SpillOverPadding, FVector4, 0x40)
        }
        static FKeyEvent GetKeyEventFromAnalogInputEvent(FAnalogInputEvent& Event)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetKeyEventFromAnalogInputEvent", 136)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Event, FAnalogInputEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FKeyEvent, 0x48)
        }
        static FInputEvent GetInputEventFromPointerEvent(FPointerEvent& Event)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromPointerEvent", 184)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Event, FPointerEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FInputEvent, 0x98)
        }
        static FInputEvent GetInputEventFromNavigationEvent(FNavigationEvent& Event)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromNavigationEvent", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Event, FNavigationEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FInputEvent, 0x28)
        }
        static FInputEvent GetInputEventFromKeyEvent(FKeyEvent& Event)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromKeyEvent", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Event, FKeyEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FInputEvent, 0x40)
        }
        static FInputEvent GetInputEventFromCharacterEvent(FCharacterEvent& Event)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetInputEventFromCharacterEvent", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Event, FCharacterEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FInputEvent, 0x28)
        }
        static UMaterialInstanceDynamic* GetDynamicMaterial(FSlateBrush& Brush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetDynamicMaterial", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0xD0)
        }
        static UDragDropOperation* GetDragDroppingContent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetDragDroppingContent", 8)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UDragDropOperation*, 0x0)
        }
        static UTexture2D* GetBrushResourceAsTexture2D(FSlateBrush& Brush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetBrushResourceAsTexture2D", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UTexture2D*, 0xD0)
        }
        static UMaterialInterface* GetBrushResourceAsMaterial(FSlateBrush& Brush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetBrushResourceAsMaterial", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInterface*, 0xD0)
        }
        static UObject* GetBrushResource(FSlateBrush& Brush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetBrushResource", 216)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Brush, FSlateBrush, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0xD0)
        }
        static void GetAllWidgetsWithInterface(UObject* WorldContextObject, TArray<UUserWidget*>& FoundWidgets, TSubclassOf<UInterface> Interface, bool TopLevelOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetAllWidgetsWithInterface", 33)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Interface, TSubclassOf<UInterface>, 0x18)
            UE_COPY_PROPERTY_CUSTOM(TopLevelOnly, bool, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(FoundWidgets, TArray<UUserWidget*>, 0x8)
        }
        static void GetAllWidgetsOfClass(UObject* WorldContextObject, TArray<UUserWidget*>& FoundWidgets, TSubclassOf<UUserWidget> WidgetClass, bool TopLevelOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:GetAllWidgetsOfClass", 33)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(WidgetClass, TSubclassOf<UUserWidget>, 0x18)
            UE_COPY_PROPERTY_CUSTOM(TopLevelOnly, bool, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(FoundWidgets, TArray<UUserWidget*>, 0x8)
        }
        static FEventReply EndDragDrop(FEventReply& Reply)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:EndDragDrop", 368)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xB8)
        }
        static void DrawTextFormatted(FPaintContext& Context, FText& Text, FVector2D Position, UFont* Font, int32 FontSize, FName FontTypeFace, FLinearColor Tint)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawTextFormatted", 124)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.X, 0x48, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.Y, 0x48, 0x8)
            UE_COPY_PROPERTY_CUSTOM(Font, UFont*, 0x58)
            UE_COPY_PROPERTY_CUSTOM(FontSize, int32, 0x60)
            UE_COPY_PROPERTY_CUSTOM(FontTypeFace, FName, 0x64)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x6C, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x6C, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x6C, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x6C, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x30)
        }
        static void DrawText(FPaintContext& Context, FString& InString, FVector2D Position, FLinearColor Tint)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawText", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(InString, FString, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.Y, 0x40, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x50, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x50, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x50, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x50, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
        }
        static void DrawSpline(FPaintContext& Context, FVector2D Start, FVector2D StartDir, FVector2D End, FVector2D EndDir, FLinearColor Tint, float Thickness)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawSpline", 132)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Start.X, 0x30, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Start.Y, 0x30, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, StartDir.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, StartDir.Y, 0x40, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, End.X, 0x50, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, End.Y, 0x50, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, EndDir.X, 0x60, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, EndDir.Y, 0x60, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x70, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x70, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x70, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x70, 0xC)
            UE_COPY_PROPERTY_CUSTOM(Thickness, float, 0x80)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
        }
        static void DrawLines(FPaintContext& Context, TArray<FVector2D>& Points, FLinearColor Tint, bool bAntiAlias, float Thickness)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawLines", 88)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x40, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x40, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x40, 0xC)
            UE_COPY_PROPERTY_CUSTOM(bAntiAlias, bool, 0x50)
            UE_COPY_PROPERTY_CUSTOM(Thickness, float, 0x54)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(Points, TArray<FVector2D>, 0x30)
        }
        static void DrawLine(FPaintContext& Context, FVector2D PositionA, FVector2D PositionB, FLinearColor Tint, bool bAntiAlias, float Thickness)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawLine", 104)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PositionA.X, 0x30, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PositionA.Y, 0x30, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PositionB.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PositionB.Y, 0x40, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x50, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x50, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x50, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x50, 0xC)
            UE_COPY_PROPERTY_CUSTOM(bAntiAlias, bool, 0x60)
            UE_COPY_PROPERTY_CUSTOM(Thickness, float, 0x64)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
        }
        static void DrawBox(FPaintContext& Context, FVector2D Position, FVector2D Size, USlateBrushAsset* Brush, FLinearColor Tint)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DrawBox", 104)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.X, 0x30, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.Y, 0x30, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.Y, 0x40, 0x8)
            UE_COPY_PROPERTY_CUSTOM(Brush, USlateBrushAsset*, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.R, 0x58, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.G, 0x58, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.B, 0x58, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Tint.A, 0x58, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
        }
        static void DismissAllMenus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DismissAllMenus", 0)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static FEventReply DetectDragIfPressed(FPointerEvent& PointerEvent, UWidget* WidgetDetectingDrag, FKey DragKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DetectDragIfPressed", 368)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WidgetDetectingDrag, UWidget*, 0x98)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, DragKey.KeyName, 0xA0, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xB8)
        }
        static FEventReply DetectDrag(FEventReply& Reply, UWidget* WidgetDetectingDrag, FKey DragKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:DetectDrag", 400)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WidgetDetectingDrag, UWidget*, 0xB8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, DragKey.KeyName, 0xC0, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        static UDragDropOperation* CreateDragDropOperation(TSubclassOf<UDragDropOperation> OperationClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:CreateDragDropOperation", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(OperationClass, TSubclassOf<UDragDropOperation>, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UDragDropOperation*, 0x8)
        }
        static UUserWidget* Create(UObject* WorldContextObject, TSubclassOf<UUserWidget> WidgetType, APlayerController* OwningPlayer)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:Create", 32)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(WidgetType, TSubclassOf<UUserWidget>, 0x8)
            UE_COPY_PROPERTY_CUSTOM(OwningPlayer, APlayerController*, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x18)
        }
        static FEventReply ClearUserFocus(FEventReply& Reply, bool bInAllUsers)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:ClearUserFocus", 376)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(bInAllUsers, bool, 0xB8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC0)
        }
        static FEventReply CaptureMouse(FEventReply& Reply, UWidget* CapturingWidget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:CaptureMouse", 376)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(CapturingWidget, UWidget*, 0xB8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC0)
        }
        static FEventReply CaptureJoystick(FEventReply& Reply, UWidget* CapturingWidget, bool bInAllJoysticks)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:CaptureJoystick", 384)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(CapturingWidget, UWidget*, 0xB8)
            UE_COPY_PROPERTY_CUSTOM(bInAllJoysticks, bool, 0xC0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Reply, FEventReply, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC8)
        }
        static void CancelDragDrop()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetBlueprintLibrary:CancelDragDrop", 0)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>

namespace WSDK
{
    class UUniformGridSlot;
    class UWidget;

    // Super Size: 0x168
    // Size: 0x190 (unaligned: 0x190, alignment: 0x8)
    class RC_UE4SS_SDK_API UUniformGridPanel : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        FMargin SlotPadding{}; // 0x168
        float MinDesiredSlotWidth{}; // 0x178
        float MinDesiredSlotHeight{}; // 0x17C
        uint8 padding_1[0x10]{}; // 0x180

        // Functions.
        void SetSlotPadding(FMargin InSlotPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridPanel:SetSlotPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InSlotPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InSlotPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InSlotPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InSlotPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetMinDesiredSlotWidth(float InMinDesiredSlotWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridPanel:SetMinDesiredSlotWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredSlotWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinDesiredSlotHeight(float InMinDesiredSlotHeight)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridPanel:SetMinDesiredSlotHeight", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredSlotHeight, float, 0x0)
            UE_CALL_FUNCTION()
        }
        UUniformGridSlot* AddChildToUniformGrid(UWidget* Content, int32 InRow, int32 InColumn)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridPanel:AddChildToUniformGrid", 24)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InRow, int32, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InColumn, int32, 0xC)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUniformGridSlot*, 0x10)
        }
    };


}

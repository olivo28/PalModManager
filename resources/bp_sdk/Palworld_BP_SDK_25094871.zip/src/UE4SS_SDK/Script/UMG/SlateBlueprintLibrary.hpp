#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/SlateCore/Geometry.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API USlateBlueprintLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FVector2D TransformVectorLocalToAbsolute(FGeometry& Geometry, FVector2D LocalVector)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:TransformVectorLocalToAbsolute", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalVector.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalVector.Y, 0x40, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x50)
        }
        static FVector2D TransformVectorAbsoluteToLocal(FGeometry& Geometry, FVector2D AbsoluteVector)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:TransformVectorAbsoluteToLocal", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteVector.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteVector.Y, 0x40, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x50)
        }
        static float TransformScalarLocalToAbsolute(FGeometry& Geometry, float LocalScalar)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:TransformScalarLocalToAbsolute", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(LocalScalar, float, 0x40)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(float, 0x44)
        }
        static float TransformScalarAbsoluteToLocal(FGeometry& Geometry, float AbsoluteScalar)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:TransformScalarAbsoluteToLocal", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(AbsoluteScalar, float, 0x40)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(float, 0x44)
        }
        static void ScreenToWidgetLocal(UObject* WorldContextObject, FGeometry& Geometry, FVector2D ScreenPosition, FVector2D& LocalCoordinate, bool bIncludeWindowPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:ScreenToWidgetLocal", 105)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.X, 0x48, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.Y, 0x48, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bIncludeWindowPosition, bool, 0x68)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x8)
            UE_COPY_OUT_PROPERTY_CUSTOM(LocalCoordinate, FVector2D, 0x58)
        }
        static void ScreenToWidgetAbsolute(UObject* WorldContextObject, FVector2D ScreenPosition, FVector2D& AbsoluteCoordinate, bool bIncludeWindowPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:ScreenToWidgetAbsolute", 41)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.Y, 0x8, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bIncludeWindowPosition, bool, 0x28)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(AbsoluteCoordinate, FVector2D, 0x18)
        }
        static void ScreenToViewport(UObject* WorldContextObject, FVector2D ScreenPosition, FVector2D& ViewportPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:ScreenToViewport", 40)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, ScreenPosition.Y, 0x8, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ViewportPosition, FVector2D, 0x18)
        }
        static void LocalToViewport(UObject* WorldContextObject, FGeometry& Geometry, FVector2D LocalCoordinate, FVector2D& PixelPosition, FVector2D& ViewportPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:LocalToViewport", 120)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalCoordinate.X, 0x48, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalCoordinate.Y, 0x48, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x8)
            UE_COPY_OUT_PROPERTY_CUSTOM(PixelPosition, FVector2D, 0x58)
            UE_COPY_OUT_PROPERTY_CUSTOM(ViewportPosition, FVector2D, 0x68)
        }
        static FVector2D LocalToAbsolute(FGeometry& Geometry, FVector2D LocalCoordinate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:LocalToAbsolute", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalCoordinate.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, LocalCoordinate.Y, 0x40, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x50)
        }
        static bool IsUnderLocation(FGeometry& Geometry, FVector2D& AbsoluteCoordinate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:IsUnderLocation", 81)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(AbsoluteCoordinate, FVector2D, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x50)
        }
        static FVector2D GetLocalTopLeft(FGeometry& Geometry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:GetLocalTopLeft", 80)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x40)
        }
        static FVector2D GetLocalSize(FGeometry& Geometry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:GetLocalSize", 80)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x40)
        }
        static FVector2D GetAbsoluteSize(FGeometry& Geometry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:GetAbsoluteSize", 80)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x40)
        }
        static bool EqualEqual_SlateBrush(FSlateBrush& A, FSlateBrush& B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:EqualEqual_SlateBrush", 417)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(A, FSlateBrush, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(B, FSlateBrush, 0xD0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1A0)
        }
        static void AbsoluteToViewport(UObject* WorldContextObject, FVector2D AbsoluteDesktopCoordinate, FVector2D& PixelPosition, FVector2D& ViewportPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:AbsoluteToViewport", 56)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteDesktopCoordinate.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteDesktopCoordinate.Y, 0x8, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PixelPosition, FVector2D, 0x18)
            UE_COPY_OUT_PROPERTY_CUSTOM(ViewportPosition, FVector2D, 0x28)
        }
        static FVector2D AbsoluteToLocal(FGeometry& Geometry, FVector2D AbsoluteCoordinate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SlateBlueprintLibrary:AbsoluteToLocal", 96)
            UE_SET_STATIC_SELF("/Script/UMG.Default__SlateBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteCoordinate.X, 0x40, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, AbsoluteCoordinate.Y, 0x40, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Geometry, FGeometry, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x50)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/SlateCore/SliderStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x700 (unaligned: 0x700, alignment: 0x10)
    class RC_UE4SS_SDK_API USlider : public WSDK::UWidget
    {
    public:
        // Properties.
        float Value{}; // 0x150
        FScriptDelegate ValueDelegate{}; // 0x154
        float MinValue{}; // 0x164
        float MaxValue{}; // 0x168
        uint8 padding_1[0x4]{}; // 0x16C
        FSliderStyle WidgetStyle{}; // 0x170
        TEnumAsByte<EOrientation> Orientation{}; // 0x670
        uint8 padding_2[0x3]{}; // 0x671
        FLinearColor SliderBarColor{}; // 0x674
        FLinearColor SliderHandleColor{}; // 0x684
        bool IndentHandle{}; // 0x694
        bool Locked{}; // 0x695
        bool MouseUsesStep{}; // 0x696
        bool RequiresControllerLock{}; // 0x697
        float StepSize{}; // 0x698
        bool IsFocusable{}; // 0x69C
        uint8 padding_3[0x3]{}; // 0x69D
        FMulticastScriptDelegate OnMouseCaptureBegin{}; // 0x6A0
        FMulticastScriptDelegate OnMouseCaptureEnd{}; // 0x6B0
        FMulticastScriptDelegate OnControllerCaptureBegin{}; // 0x6C0
        FMulticastScriptDelegate OnControllerCaptureEnd{}; // 0x6D0
        FMulticastScriptDelegate OnValueChanged{}; // 0x6E0
        uint8 padding_4[0x10]{}; // 0x6F0

        // Functions.
        void SetValue(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetValue", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStepSize(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetStepSize", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSliderHandleColor(FLinearColor InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetSliderHandleColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetSliderBarColor(FLinearColor InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetSliderBarColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetMinValue(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetMinValue", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxValue(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetMaxValue", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetLocked(bool InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetLocked", 1)
            UE_COPY_PROPERTY_CUSTOM(InValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIndentHandle(bool InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:SetIndentHandle", 1)
            UE_COPY_PROPERTY_CUSTOM(InValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        float GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:GetValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetNormalizedValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Slider:GetNormalizedValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

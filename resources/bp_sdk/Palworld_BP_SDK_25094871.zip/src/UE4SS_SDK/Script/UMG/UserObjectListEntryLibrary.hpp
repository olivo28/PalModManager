#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    class IUserObjectListEntry;
    class UObject;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UUserObjectListEntryLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static UObject* GetListItemObject(TScriptInterface<IUserObjectListEntry> UserObjectListEntry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserObjectListEntryLibrary:GetListItemObject", 24)
            UE_SET_STATIC_SELF("/Script/UMG.Default__UserObjectListEntryLibrary")
            UE_COPY_PROPERTY_CUSTOM(UserObjectListEntry, TScriptInterface<IUserObjectListEntry>, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x10)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMaterialInstanceDynamic;
    class UMaterialInterface;

    // Super Size: 0x168
    // Size: 0x198 (unaligned: 0x198, alignment: 0x8)
    class RC_UE4SS_SDK_API URetainerBox : public WSDK::UContentWidget
    {
    public:
        // Properties.
        bool bRetainRender{}; // 0x168
        bool RenderOnInvalidation{}; // 0x169
        bool RenderOnPhase{}; // 0x16A
        uint8 padding_1[0x1]{}; // 0x16B
        int32 Phase{}; // 0x16C
        int32 PhaseCount{}; // 0x170
        uint8 padding_2[0x4]{}; // 0x174
        UMaterialInterface* EffectMaterial{}; // 0x178
        FName TextureParameter{}; // 0x180
        uint8 padding_3[0x10]{}; // 0x188

        // Functions.
        void SetTextureParameter(FName TextureParameter)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:SetTextureParameter", 8)
            UE_COPY_PROPERTY_CUSTOM(TextureParameter, FName, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRetainRendering(bool bInRetainRendering)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:SetRetainRendering", 1)
            UE_COPY_PROPERTY_CUSTOM(bInRetainRendering, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRenderingPhase(int32 RenderPhase, int32 TotalPhases)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:SetRenderingPhase", 8)
            UE_COPY_PROPERTY_CUSTOM(RenderPhase, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(TotalPhases, int32, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetEffectMaterial(UMaterialInterface* EffectMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:SetEffectMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(EffectMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void RequestRender()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:RequestRender", 0)
            UE_CALL_FUNCTION()
        }
        UMaterialInstanceDynamic* GetEffectMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RetainerBox:GetEffectMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UPanelSlot;
    class UWidget;

    // Super Size: 0x150
    // Size: 0x168 (unaligned: 0x168, alignment: 0x8)
    class RC_UE4SS_SDK_API UPanelWidget : public WSDK::UWidget
    {
    public:
        // Properties.
        TArray<UPanelSlot*> Slots{}; // 0x150
        uint8 padding_1[0x8]{}; // 0x160

        // Functions.
        bool RemoveChildAt(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:RemoveChildAt", 5)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x4)
        }
        bool RemoveChild(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:RemoveChild", 9)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasChild(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:HasChild", 9)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasAnyChildren()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:HasAnyChildren", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        int32 GetChildrenCount()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:GetChildrenCount", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        int32 GetChildIndex(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:GetChildIndex", 12)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x8)
        }
        UWidget* GetChildAt(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:GetChildAt", 16)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x8)
        }
        TArray<UWidget*> GetAllChildren()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:GetAllChildren", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UWidget*>, 0x0)
        }
        void ClearChildren()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:ClearChildren", 0)
            UE_CALL_FUNCTION()
        }
        UPanelSlot* AddChild(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.PanelWidget:AddChild", 16)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UPanelSlot*, 0x8)
        }
    };


}

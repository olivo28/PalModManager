#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextOverflowPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextTransformPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/UMG/TextLayoutWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    class UMaterialInstanceDynamic;
    class UMaterialInterface;

    // Super Size: 0x170
    // Size: 0x340 (unaligned: 0x338, alignment: 0x10)
    #pragma pack(push, 0x1)
    class RC_UE4SS_SDK_API alignas(0x10) UTextBlock : public WSDK::UTextLayoutWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x170
        FScriptDelegate TextDelegate{}; // 0x188
        FSlateColor ColorAndOpacity{}; // 0x198
        FScriptDelegate ColorAndOpacityDelegate{}; // 0x1AC
        uint8 padding_1[0x4]{}; // 0x1BC
        FSlateFontInfo Font{}; // 0x1C0
        FSlateBrush StrikeBrush{}; // 0x220
        FVector2D ShadowOffset{}; // 0x2F0
        FLinearColor ShadowColorAndOpacity{}; // 0x300
        FScriptDelegate ShadowColorAndOpacityDelegate{}; // 0x310
        float MinDesiredWidth{}; // 0x320
        bool bWrapWithInvalidationPanel{}; // 0x324
        ETextTransformPolicy TextTransformPolicy{}; // 0x325
        ETextOverflowPolicy TextOverflowPolicy{}; // 0x326
        bool bSimpleTextMode{}; // 0x327
        uint8 padding_2[0x10]{}; // 0x328

        // Functions.
        void SetTextTransformPolicy(ETextTransformPolicy InTransformPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetTextTransformPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InTransformPolicy, ETextTransformPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTextOverflowPolicy(ETextOverflowPolicy InOverflowPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetTextOverflowPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InOverflowPolicy, ETextOverflowPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStrikeBrush(FSlateBrush InStrikeBrush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetStrikeBrush", 208)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, InStrikeBrush.bIsDynamicallyLoaded, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, InStrikeBrush.bHasUObject, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TEnumAsByte<ESlateBrushDrawType::Type>, InStrikeBrush.DrawAs, 0x0, 0x11)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TEnumAsByte<ESlateBrushTileType::Type>, InStrikeBrush.Tiling, 0x0, 0x12)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TEnumAsByte<ESlateBrushMirrorType::Type>, InStrikeBrush.Mirroring, 0x0, 0x13)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TEnumAsByte<ESlateBrushImageType::Type>, InStrikeBrush.ImageType, 0x0, 0x14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, InStrikeBrush.ImageSize, 0x0, 0x18)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, InStrikeBrush.Margin, 0x0, 0x28)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FSlateColor, InStrikeBrush.TintColor, 0x0, 0x38)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FSlateBrushOutlineSettings, InStrikeBrush.OutlineSettings, 0x0, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InStrikeBrush.ResourceObject, 0x0, 0x90)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, InStrikeBrush.ResourceName, 0x0, 0x98)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FBox2f, InStrikeBrush.UVRegion, 0x0, 0xA0)
            UE_CALL_FUNCTION()
        }
        void SetShadowOffset(FVector2D InShadowOffset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetShadowOffset", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InShadowOffset.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InShadowOffset.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetShadowColorAndOpacity(FLinearColor InShadowColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetShadowColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetOpacity(float InOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetOpacity", 4)
            UE_COPY_PROPERTY_CUSTOM(InOpacity, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinDesiredWidth(float InMinDesiredWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetMinDesiredWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontOutlineMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetFontOutlineMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFontMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetFontMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFont(FSlateFontInfo InFontInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetFont", 96)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontObject, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontMaterial, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FFontOutlineSettings, InFontInfo.OutlineSettings, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, InFontInfo.TypefaceFontName, 0x0, 0x48)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.Size, 0x0, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.LetterSpacing, 0x0, 0x54)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InFontInfo.SkewAmount, 0x0, 0x58)
            UE_CALL_FUNCTION()
        }
        void SetColorAndOpacity(FSlateColor InColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetColorAndOpacity", 20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FLinearColor, InColorAndOpacity.SpecifiedColor, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ESlateColorStylingMode, InColorAndOpacity.ColorUseRule, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetAutoWrapText(bool InAutoTextWrap)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:SetAutoWrapText", 1)
            UE_COPY_PROPERTY_CUSTOM(InAutoTextWrap, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        UMaterialInstanceDynamic* GetDynamicOutlineMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:GetDynamicOutlineMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        UMaterialInstanceDynamic* GetDynamicFontMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBlock:GetDynamicFontMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
    };
    #pragma pack(pop)


}

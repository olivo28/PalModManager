#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/Blueprint.hpp>

namespace WSDK
{
    // Super Size: 0xA8
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API UUserWidgetBlueprint : public WSDK::UBlueprint
    {
    public:
        // Properties.

        // Functions.
    };


}

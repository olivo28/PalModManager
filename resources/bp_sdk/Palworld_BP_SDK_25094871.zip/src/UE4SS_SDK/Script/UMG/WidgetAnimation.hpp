#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSequence.hpp>
#include <UE4SS_SDK/Script/UMG/WidgetAnimationBinding.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMovieScene;
    class UUserWidget;

    // Super Size: 0x68
    // Size: 0x98 (unaligned: 0x98, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetAnimation : public WSDK::UMovieSceneSequence
    {
    public:
        // Properties.
        UMovieScene* MovieScene{}; // 0x68
        TArray<FWidgetAnimationBinding> AnimationBindings{}; // 0x70
        bool bLegacyFinishOnStop{}; // 0x80
        uint8 padding_1[0x7]{}; // 0x81
        FString DisplayLabel{}; // 0x88

        // Functions.
        void UnbindFromAnimationStarted(UUserWidget* Widget, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:UnbindFromAnimationStarted", 24)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void UnbindFromAnimationFinished(UUserWidget* Widget, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:UnbindFromAnimationFinished", 24)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void UnbindAllFromAnimationStarted(UUserWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:UnbindAllFromAnimationStarted", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        void UnbindAllFromAnimationFinished(UUserWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:UnbindAllFromAnimationFinished", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        float GetStartTime()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:GetStartTime", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetEndTime()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:GetEndTime", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        void BindToAnimationStarted(UUserWidget* Widget, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:BindToAnimationStarted", 24)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void BindToAnimationFinished(UUserWidget* Widget, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimation:BindToAnimationFinished", 24)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
    };


}

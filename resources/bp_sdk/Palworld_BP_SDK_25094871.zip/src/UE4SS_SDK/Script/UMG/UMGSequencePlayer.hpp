#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneRootEvaluationTemplateInstance.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidgetAnimation;

    // Super Size: 0x28
    // Size: 0x330 (unaligned: 0x330, alignment: 0x8)
    class RC_UE4SS_SDK_API UUMGSequencePlayer : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x1F0]{}; // 0x28
        UWidgetAnimation* Animation{}; // 0x218
        uint8 padding_2[0x8]{}; // 0x220
        FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance{}; // 0x228
        uint8 padding_3[0x80]{}; // 0x2B0

        // Functions.
        void SetUserTag(FName InUserTag)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UMGSequencePlayer:SetUserTag", 8)
            UE_COPY_PROPERTY_CUSTOM(InUserTag, FName, 0x0)
            UE_CALL_FUNCTION()
        }
        FName GetUserTag()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UMGSequencePlayer:GetUserTag", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FName, 0x0)
        }
    };


}

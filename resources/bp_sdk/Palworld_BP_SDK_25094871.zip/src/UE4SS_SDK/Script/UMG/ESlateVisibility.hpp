#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESlateVisibility : uint8
    {
        Visible,
        Collapsed,
        Hidden,
        HitTestInvisible,
        SelfHitTestInvisible,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>

namespace WSDK
{
    class UHorizontalBoxSlot;
    class UWidget;

    // Super Size: 0x168
    // Size: 0x178 (unaligned: 0x178, alignment: 0x8)
    class RC_UE4SS_SDK_API UHorizontalBox : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0x168

        // Functions.
        UHorizontalBoxSlot* AddChildToHorizontalBox(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.HorizontalBox:AddChildToHorizontalBox", 16)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UHorizontalBoxSlot*, 0x8)
        }
    };


}

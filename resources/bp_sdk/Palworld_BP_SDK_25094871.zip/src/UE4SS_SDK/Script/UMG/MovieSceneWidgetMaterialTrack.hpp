#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieSceneTracks/MovieSceneMaterialTrack.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0xA8
    // Size: 0xD0 (unaligned: 0xD0, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieSceneWidgetMaterialTrack : public WSDK::UMovieSceneMaterialTrack
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0xA8
        TArray<FName> BrushPropertyNamePath{}; // 0xB8
        FName TrackName{}; // 0xC8

        // Functions.
    };


}

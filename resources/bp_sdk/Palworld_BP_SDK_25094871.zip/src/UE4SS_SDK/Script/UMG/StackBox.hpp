#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UStackBoxSlot;
    class UWidget;

    // Super Size: 0x168
    // Size: 0x180 (unaligned: 0x180, alignment: 0x8)
    class RC_UE4SS_SDK_API UStackBox : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        TEnumAsByte<EOrientation> Orientation{}; // 0x168
        uint8 padding_1[0x17]{}; // 0x169

        // Functions.
        UStackBoxSlot* AddChildToStackBox(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.StackBox:AddChildToStackBox", 16)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UStackBoxSlot*, 0x8)
        }
    };


}

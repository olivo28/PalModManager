#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Slate/EDescendantScrollDestination.hpp>
#include <UE4SS_SDK/Script/Slate/EScrollWhenFocusChanges.hpp>
#include <UE4SS_SDK/Script/SlateCore/EConsumeMouseWheel.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/ScrollBarStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/ScrollBoxStyle.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateVisibility.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x168
    // Size: 0xCA0 (unaligned: 0xCA0, alignment: 0x10)
    class RC_UE4SS_SDK_API UScrollBox : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x168
        FScrollBoxStyle WidgetStyle{}; // 0x170
        FScrollBarStyle WidgetBarStyle{}; // 0x4C0
        TEnumAsByte<EOrientation> Orientation{}; // 0xC30
        ESlateVisibility ScrollBarVisibility{}; // 0xC31
        EConsumeMouseWheel ConsumeMouseWheel{}; // 0xC32
        uint8 padding_2[0x5]{}; // 0xC33
        FVector2D ScrollbarThickness{}; // 0xC38
        FMargin ScrollbarPadding{}; // 0xC48
        bool AlwaysShowScrollbar{}; // 0xC58
        bool AlwaysShowScrollbarTrack{}; // 0xC59
        bool AllowOverscroll{}; // 0xC5A
        bool BackPadScrolling{}; // 0xC5B
        bool FrontPadScrolling{}; // 0xC5C
        bool bAnimateWheelScrolling{}; // 0xC5D
        EDescendantScrollDestination NavigationDestination{}; // 0xC5E
        uint8 padding_3[0x1]{}; // 0xC5F
        float NavigationScrollPadding{}; // 0xC60
        EScrollWhenFocusChanges ScrollWhenFocusChanges{}; // 0xC64
        bool bAllowRightClickDragScrolling{}; // 0xC65
        uint8 padding_4[0x2]{}; // 0xC66
        float WheelScrollMultiplier{}; // 0xC68
        uint8 padding_5[0x4]{}; // 0xC6C
        FMulticastScriptDelegate OnUserScrolled{}; // 0xC70
        uint8 padding_6[0x20]{}; // 0xC80

        // Functions.
        void SetWheelScrollMultiplier(float NewWheelScrollMultiplier)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetWheelScrollMultiplier", 4)
            UE_COPY_PROPERTY_CUSTOM(NewWheelScrollMultiplier, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollWhenFocusChanges(EScrollWhenFocusChanges NewScrollWhenFocusChanges)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetScrollWhenFocusChanges", 1)
            UE_COPY_PROPERTY_CUSTOM(NewScrollWhenFocusChanges, EScrollWhenFocusChanges, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollOffset(float NewScrollOffset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetScrollOffset", 4)
            UE_COPY_PROPERTY_CUSTOM(NewScrollOffset, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollBarVisibility(ESlateVisibility NewScrollBarVisibility)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetScrollBarVisibility", 1)
            UE_COPY_PROPERTY_CUSTOM(NewScrollBarVisibility, ESlateVisibility, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollbarThickness(FVector2D& NewScrollbarThickness)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetScrollbarThickness", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(NewScrollbarThickness, FVector2D, 0x0)
        }
        void SetScrollbarPadding(FMargin& NewScrollbarPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetScrollbarPadding", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(NewScrollbarPadding, FMargin, 0x0)
        }
        void SetOrientation(TEnumAsByte<EOrientation> NewOrientation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetOrientation", 1)
            UE_COPY_PROPERTY_CUSTOM(NewOrientation, TEnumAsByte<EOrientation>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetNavigationDestination(EDescendantScrollDestination NewNavigationDestination)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetNavigationDestination", 1)
            UE_COPY_PROPERTY_CUSTOM(NewNavigationDestination, EDescendantScrollDestination, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetConsumeMouseWheel(EConsumeMouseWheel NewConsumeMouseWheel)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetConsumeMouseWheel", 1)
            UE_COPY_PROPERTY_CUSTOM(NewConsumeMouseWheel, EConsumeMouseWheel, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAnimateWheelScrolling(bool bShouldAnimateWheelScrolling)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetAnimateWheelScrolling", 1)
            UE_COPY_PROPERTY_CUSTOM(bShouldAnimateWheelScrolling, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAlwaysShowScrollbar(bool NewAlwaysShowScrollbar)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetAlwaysShowScrollbar", 1)
            UE_COPY_PROPERTY_CUSTOM(NewAlwaysShowScrollbar, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAllowOverscroll(bool NewAllowOverscroll)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:SetAllowOverscroll", 1)
            UE_COPY_PROPERTY_CUSTOM(NewAllowOverscroll, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void ScrollWidgetIntoView(UWidget* WidgetToFind, bool AnimateScroll, EDescendantScrollDestination ScrollDestination, float Padding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:ScrollWidgetIntoView", 16)
            UE_COPY_PROPERTY_CUSTOM(WidgetToFind, UWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(AnimateScroll, bool, 0x8)
            UE_COPY_PROPERTY_CUSTOM(ScrollDestination, EDescendantScrollDestination, 0x9)
            UE_COPY_PROPERTY_CUSTOM(Padding, float, 0xC)
            UE_CALL_FUNCTION()
        }
        void ScrollToStart()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:ScrollToStart", 0)
            UE_CALL_FUNCTION()
        }
        void ScrollToEnd()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:ScrollToEnd", 0)
            UE_CALL_FUNCTION()
        }
        float GetViewOffsetFraction()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:GetViewOffsetFraction", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetViewFraction()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:GetViewFraction", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetScrollOffsetOfEnd()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:GetScrollOffsetOfEnd", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetScrollOffset()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:GetScrollOffset", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        void EndInertialScrolling()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBox:EndInertialScrolling", 0)
            UE_CALL_FUNCTION()
        }
    };


}

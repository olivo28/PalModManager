#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API UScrollBoxSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        FMargin Padding{}; // 0x38
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x48
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x49
        uint8 padding_1[0xE]{}; // 0x4A

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBoxSlot:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBoxSlot:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBoxSlot:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PropertyBinding.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x60
    // Size: 0x68 (unaligned: 0x68, alignment: 0x8)
    class RC_UE4SS_SDK_API UTextBinding : public WSDK::UPropertyBinding
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x60

        // Functions.
        FText GetTextValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBinding:GetTextValue", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FString GetStringValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TextBinding:GetStringValue", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x0)
        }
    };


}

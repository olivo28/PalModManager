#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class USlateBrushAsset;
    class UTexture2D;

    // Super Size: 0x168
    // Size: 0x310 (unaligned: 0x308, alignment: 0x10)
    #pragma pack(push, 0x1)
    class RC_UE4SS_SDK_API alignas(0x10) UBorder : public WSDK::UContentWidget
    {
    public:
        // Properties.
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x168
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x169
        uint8 bShowEffectWhenDisabled : 1{}; // 0x16A (0x1)
        uint8 padding_1 : 1{}; // 0x16A (0x2)
        uint8 padding_2 : 1{}; // 0x16A (0x4)
        uint8 padding_3 : 1{}; // 0x16A (0x8)
        uint8 padding_4 : 1{}; // 0x16A (0x10)
        uint8 padding_5 : 1{}; // 0x16A (0x20)
        uint8 padding_6 : 1{}; // 0x16A (0x40)
        uint8 padding_7 : 1{}; // 0x16A (0x80)
        uint8 padding_8[0x1]{}; // 0x16B
        FLinearColor ContentColorAndOpacity{}; // 0x16C
        FScriptDelegate ContentColorAndOpacityDelegate{}; // 0x17C
        FMargin Padding{}; // 0x18C
        uint8 padding_9[0x4]{}; // 0x19C
        FSlateBrush Background{}; // 0x1A0
        FScriptDelegate BackgroundDelegate{}; // 0x270
        FLinearColor BrushColor{}; // 0x280
        FScriptDelegate BrushColorDelegate{}; // 0x290
        FVector2D DesiredSizeScale{}; // 0x2A0
        bool bFlipForRightToLeftFlowDirection{}; // 0x2B0
        uint8 padding_10[0x3]{}; // 0x2B1
        FScriptDelegate OnMouseButtonDownEvent{}; // 0x2B4
        FScriptDelegate OnMouseButtonUpEvent{}; // 0x2C4
        FScriptDelegate OnMouseMoveEvent{}; // 0x2D4
        FScriptDelegate OnMouseDoubleClickEvent{}; // 0x2E4
        uint8 padding_11[0x14]{}; // 0x2F4

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetShowEffectWhenDisabled(bool bInShowEffectWhenDisabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetShowEffectWhenDisabled", 1)
            UE_COPY_PROPERTY_CUSTOM(bInShowEffectWhenDisabled, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDesiredSizeScale(FVector2D InScale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetDesiredSizeScale", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InScale.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InScale.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetContentColorAndOpacity(FLinearColor InContentColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetContentColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InContentColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InContentColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InContentColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InContentColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromTexture(UTexture2D* Texture)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetBrushFromTexture", 8)
            UE_COPY_PROPERTY_CUSTOM(Texture, UTexture2D*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromMaterial(UMaterialInterface* Material)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetBrushFromMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(Material, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromAsset(USlateBrushAsset* Asset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetBrushFromAsset", 8)
            UE_COPY_PROPERTY_CUSTOM(Asset, USlateBrushAsset*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushColor(FLinearColor InBrushColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetBrushColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBrushColor.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBrushColor.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBrushColor.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InBrushColor.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetBrush(FSlateBrush& InBrush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:SetBrush", 208)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InBrush, FSlateBrush, 0x0)
        }
        UMaterialInstanceDynamic* GetDynamicMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Border:GetDynamicMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
    };
    #pragma pack(pop)


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/IntPoint.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/MeshComponent.hpp>
#include <UE4SS_SDK/Script/UMG/ETickMode.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetBlendMode.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetGeometryMode.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetSpace.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetTimingPolicy.hpp>
#include <UE4SS_SDK/Script/UMG/EWindowVisibility.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UBodySetup;
    class ULocalPlayer;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class UTextureRenderTarget2D;
    class UUserWidget;

    // Super Size: 0x570
    // Size: 0x6B0 (unaligned: 0x6B0, alignment: 0x10)
    class RC_UE4SS_SDK_API UWidgetComponent : public WSDK::UMeshComponent
    {
    public:
        // Properties.
        EWidgetSpace space{}; // 0x570
        EWidgetTimingPolicy TimingPolicy{}; // 0x571
        uint8 padding_1[0x6]{}; // 0x572
        TSubclassOf<UUserWidget> WidgetClass{}; // 0x578
        FIntPoint DrawSize{}; // 0x580
        bool bManuallyRedraw{}; // 0x588
        bool bRedrawRequested{}; // 0x589
        uint8 padding_2[0x2]{}; // 0x58A
        float RedrawTime{}; // 0x58C
        uint8 padding_3[0x8]{}; // 0x590
        FIntPoint CurrentDrawSize{}; // 0x598
        bool bDrawAtDesiredSize{}; // 0x5A0
        uint8 padding_4[0x7]{}; // 0x5A1
        FVector2D Pivot{}; // 0x5A8
        bool bReceiveHardwareInput{}; // 0x5B8
        bool bWindowFocusable{}; // 0x5B9
        EWindowVisibility WindowVisibility{}; // 0x5BA
        bool bApplyGammaCorrection{}; // 0x5BB
        uint8 padding_5[0x4]{}; // 0x5BC
        ULocalPlayer* OwnerPlayer{}; // 0x5C0
        FLinearColor BackgroundColor{}; // 0x5C8
        FLinearColor TintColorAndOpacity{}; // 0x5D8
        float OpacityFromTexture{}; // 0x5E8
        EWidgetBlendMode BlendMode{}; // 0x5EC
        bool bIsTwoSided{}; // 0x5ED
        bool TickWhenOffscreen{}; // 0x5EE
        uint8 padding_6[0x1]{}; // 0x5EF
        UBodySetup* BodySetup{}; // 0x5F0
        UMaterialInterface* TranslucentMaterial{}; // 0x5F8
        UMaterialInterface* TranslucentMaterial_OneSided{}; // 0x600
        UMaterialInterface* OpaqueMaterial{}; // 0x608
        UMaterialInterface* OpaqueMaterial_OneSided{}; // 0x610
        UMaterialInterface* MaskedMaterial{}; // 0x618
        UMaterialInterface* MaskedMaterial_OneSided{}; // 0x620
        UTextureRenderTarget2D* RenderTarget{}; // 0x628
        UMaterialInstanceDynamic* MaterialInstance{}; // 0x630
        bool bAddedToScreen{}; // 0x638
        bool bEditTimeUsable{}; // 0x639
        uint8 padding_7[0x2]{}; // 0x63A
        FName SharedLayerName{}; // 0x63C
        int32 LayerZOrder{}; // 0x644
        EWidgetGeometryMode GeometryMode{}; // 0x648
        uint8 padding_8[0x3]{}; // 0x649
        float CylinderArcAngle{}; // 0x64C
        ETickMode TickMode{}; // 0x650
        uint8 padding_9[0x2F]{}; // 0x651
        UUserWidget* Widget{}; // 0x680
        uint8 padding_10[0x28]{}; // 0x688

        // Functions.
        void SetWindowVisibility(EWindowVisibility InVisibility)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetWindowVisibility", 1)
            UE_COPY_PROPERTY_CUSTOM(InVisibility, EWindowVisibility, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetWindowFocusable(bool bInWindowFocusable)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetWindowFocusable", 1)
            UE_COPY_PROPERTY_CUSTOM(bInWindowFocusable, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetWidgetSpace(EWidgetSpace NewSpace)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetWidgetSpace", 1)
            UE_COPY_PROPERTY_CUSTOM(NewSpace, EWidgetSpace, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetWidget(UUserWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetWidget", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTwoSided(bool bWantTwoSided)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetTwoSided", 1)
            UE_COPY_PROPERTY_CUSTOM(bWantTwoSided, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTintColorAndOpacity(FLinearColor NewTintColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetTintColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewTintColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewTintColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewTintColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewTintColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetTickWhenOffscreen(bool bWantTickWhenOffscreen)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetTickWhenOffscreen", 1)
            UE_COPY_PROPERTY_CUSTOM(bWantTickWhenOffscreen, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTickMode(ETickMode InTickMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetTickMode", 1)
            UE_COPY_PROPERTY_CUSTOM(InTickMode, ETickMode, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRedrawTime(float InRedrawTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetRedrawTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InRedrawTime, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPivot(FVector2D& InPivot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetPivot", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InPivot, FVector2D, 0x0)
        }
        void SetOwnerPlayer(ULocalPlayer* LocalPlayer)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetOwnerPlayer", 8)
            UE_COPY_PROPERTY_CUSTOM(LocalPlayer, ULocalPlayer*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetManuallyRedraw(bool bUseManualRedraw)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetManuallyRedraw", 1)
            UE_COPY_PROPERTY_CUSTOM(bUseManualRedraw, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetGeometryMode(EWidgetGeometryMode InGeometryMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetGeometryMode", 1)
            UE_COPY_PROPERTY_CUSTOM(InGeometryMode, EWidgetGeometryMode, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDrawSize(FVector2D Size)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetDrawSize", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetDrawAtDesiredSize(bool bInDrawAtDesiredSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetDrawAtDesiredSize", 1)
            UE_COPY_PROPERTY_CUSTOM(bInDrawAtDesiredSize, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetCylinderArcAngle(float InCylinderArcAngle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetCylinderArcAngle", 4)
            UE_COPY_PROPERTY_CUSTOM(InCylinderArcAngle, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBackgroundColor(FLinearColor NewBackgroundColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:SetBackgroundColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewBackgroundColor.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewBackgroundColor.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewBackgroundColor.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, NewBackgroundColor.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void RequestRenderUpdate()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:RequestRenderUpdate", 0)
            UE_CALL_FUNCTION()
        }
        void RequestRedraw()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:RequestRedraw", 0)
            UE_CALL_FUNCTION()
        }
        bool IsWidgetVisible()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:IsWidgetVisible", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        EWindowVisibility GetWindowVisiblility()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetWindowVisiblility", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(EWindowVisibility, 0x0)
        }
        bool GetWindowFocusable()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetWindowFocusable", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        EWidgetSpace GetWidgetSpace()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetWidgetSpace", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(EWidgetSpace, 0x0)
        }
        UUserWidget* GetWidget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetWidget", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x0)
        }
        UUserWidget* GetUserWidgetObject()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetUserWidgetObject", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x0)
        }
        bool GetTwoSided()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetTwoSided", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool GetTickWhenOffscreen()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetTickWhenOffscreen", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        UTextureRenderTarget2D* GetRenderTarget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetRenderTarget", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTextureRenderTarget2D*, 0x0)
        }
        float GetRedrawTime()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetRedrawTime", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        FVector2D GetPivot()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetPivot", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        ULocalPlayer* GetOwnerPlayer()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetOwnerPlayer", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ULocalPlayer*, 0x0)
        }
        UMaterialInstanceDynamic* GetMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        bool GetManuallyRedraw()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetManuallyRedraw", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        EWidgetGeometryMode GetGeometryMode()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetGeometryMode", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(EWidgetGeometryMode, 0x0)
        }
        FVector2D GetDrawSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetDrawSize", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        bool GetDrawAtDesiredSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetDrawAtDesiredSize", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        float GetCylinderArcAngle()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetCylinderArcAngle", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        FVector2D GetCurrentDrawSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetComponent:GetCurrentDrawSize", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
    };


}

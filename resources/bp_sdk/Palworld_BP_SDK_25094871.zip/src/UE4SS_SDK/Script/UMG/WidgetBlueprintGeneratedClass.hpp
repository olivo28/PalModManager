#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintGeneratedClass.hpp>
#include <UE4SS_SDK/Script/UMG/DelegateRuntimeBinding.hpp>
#include <UE4SS_SDK/Script/UMG/FieldNotificationId.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidgetAnimation;
    class UWidgetBlueprintGeneratedClassExtension;
    class UWidgetTree;

    // Super Size: 0x380
    // Size: 0x400 (unaligned: 0x400, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetBlueprintGeneratedClass : public WSDK::UBlueprintGeneratedClass
    {
    public:
        // Properties.
        UWidgetTree* WidgetTree{}; // 0x380
        TArray<UWidgetBlueprintGeneratedClassExtension*> Extensions{}; // 0x388
        TArray<FFieldNotificationId> FieldNotifyNames{}; // 0x398
        uint8 padding_1[0x4]{}; // 0x3A8
        uint8 bClassRequiresNativeTick : 1{}; // 0x3AC (0x1)
        uint8 padding_2 : 1{}; // 0x3AC (0x2)
        uint8 padding_3 : 1{}; // 0x3AC (0x4)
        uint8 padding_4 : 1{}; // 0x3AC (0x8)
        uint8 padding_5 : 1{}; // 0x3AC (0x10)
        uint8 padding_6 : 1{}; // 0x3AC (0x20)
        uint8 padding_7 : 1{}; // 0x3AC (0x40)
        uint8 padding_8 : 1{}; // 0x3AC (0x80)
        uint8 padding_9[0x3]{}; // 0x3AD
        TArray<FDelegateRuntimeBinding> Bindings{}; // 0x3B0
        TArray<UWidgetAnimation*> Animations{}; // 0x3C0
        TArray<FName> NamedSlots{}; // 0x3D0
        TArray<FName> AvailableNamedSlots{}; // 0x3E0
        TArray<FName> InstanceNamedSlots{}; // 0x3F0

        // Functions.
    };


}

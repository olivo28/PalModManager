#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UMG/EUMGSequencePlayMode.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UUMGSequencePlayer;
    class UUserWidget;
    class UWidgetAnimation;
    class UWidgetAnimationPlayCallbackProxy;

    // Super Size: 0x28
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetAnimationPlayCallbackProxy : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FMulticastScriptDelegate Finished{}; // 0x28
        uint8 padding_1[0x8]{}; // 0x38

        // Functions.
        static UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationTimeRangeProxyObject(UUMGSequencePlayer*& Result, UUserWidget* Widget, UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32 NumLoopsToPlay, TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode, float PlaybackSpeed)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimationPlayCallbackProxy:CreatePlayAnimationTimeRangeProxyObject", 56)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetAnimationPlayCallbackProxy")
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x10)
            UE_COPY_PROPERTY_CUSTOM(StartAtTime, float, 0x18)
            UE_COPY_PROPERTY_CUSTOM(EndAtTime, float, 0x1C)
            UE_COPY_PROPERTY_CUSTOM(NumLoopsToPlay, int32, 0x20)
            UE_COPY_PROPERTY_CUSTOM(PlayMode, TEnumAsByte<EUMGSequencePlayMode::Type>, 0x24)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x28)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Result, UUMGSequencePlayer*, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UWidgetAnimationPlayCallbackProxy*, 0x30)
        }
        static UWidgetAnimationPlayCallbackProxy* CreatePlayAnimationProxyObject(UUMGSequencePlayer*& Result, UUserWidget* Widget, UWidgetAnimation* InAnimation, float StartAtTime, int32 NumLoopsToPlay, TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode, float PlaybackSpeed)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetAnimationPlayCallbackProxy:CreatePlayAnimationProxyObject", 48)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetAnimationPlayCallbackProxy")
            UE_COPY_PROPERTY_CUSTOM(Widget, UUserWidget*, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x10)
            UE_COPY_PROPERTY_CUSTOM(StartAtTime, float, 0x18)
            UE_COPY_PROPERTY_CUSTOM(NumLoopsToPlay, int32, 0x1C)
            UE_COPY_PROPERTY_CUSTOM(PlayMode, TEnumAsByte<EUMGSequencePlayMode::Type>, 0x20)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Result, UUMGSequencePlayer*, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UWidgetAnimationPlayCallbackProxy*, 0x28)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    class UGridSlot;
    class UWidget;

    // Super Size: 0x168
    // Size: 0x198 (unaligned: 0x198, alignment: 0x8)
    class RC_UE4SS_SDK_API UGridPanel : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        TArray<float> ColumnFill{}; // 0x168
        TArray<float> RowFill{}; // 0x178
        uint8 padding_1[0x10]{}; // 0x188

        // Functions.
        void SetRowFill(int32 RowIndex, float Coefficient)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridPanel:SetRowFill", 8)
            UE_COPY_PROPERTY_CUSTOM(RowIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Coefficient, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetColumnFill(int32 ColumnIndex, float Coefficient)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridPanel:SetColumnFill", 8)
            UE_COPY_PROPERTY_CUSTOM(ColumnIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Coefficient, float, 0x4)
            UE_CALL_FUNCTION()
        }
        UGridSlot* AddChildToGrid(UWidget* Content, int32 InRow, int32 InColumn)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridPanel:AddChildToGrid", 24)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InRow, int32, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InColumn, int32, 0xC)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UGridSlot*, 0x10)
        }
    };


}

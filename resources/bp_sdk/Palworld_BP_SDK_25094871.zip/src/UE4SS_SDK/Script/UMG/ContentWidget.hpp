#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>

namespace WSDK
{
    class UPanelSlot;
    class UWidget;

    // Super Size: 0x168
    // Size: 0x168 (unaligned: 0x168, alignment: 0x8)
    class RC_UE4SS_SDK_API UContentWidget : public WSDK::UPanelWidget
    {
    public:
        // Properties.

        // Functions.
        UPanelSlot* SetContent(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ContentWidget:SetContent", 16)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UPanelSlot*, 0x8)
        }
        UPanelSlot* GetContentSlot()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ContentWidget:GetContentSlot", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UPanelSlot*, 0x0)
        }
        UWidget* GetContent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ContentWidget:GetContent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x0)
        }
    };


}

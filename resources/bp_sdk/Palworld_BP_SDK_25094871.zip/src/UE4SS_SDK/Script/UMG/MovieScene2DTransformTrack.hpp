#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieSceneTracks/MovieScenePropertyTrack.hpp>

namespace WSDK
{
    // Super Size: 0xC8
    // Size: 0xC8 (unaligned: 0xC8, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieScene2DTransformTrack : public WSDK::UMovieScenePropertyTrack
    {
    public:
        // Properties.

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x150
    // Size: 0x188 (unaligned: 0x188, alignment: 0x8)
    class RC_UE4SS_SDK_API UComboBox : public WSDK::UWidget
    {
    public:
        // Properties.
        TArray<UObject*> Items{}; // 0x150
        FScriptDelegate OnGenerateWidgetEvent{}; // 0x160
        bool bIsFocusable{}; // 0x170
        uint8 padding_1[0x17]{}; // 0x171

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/DynamicPropertyPath.hpp>
#include <UE4SS_SDK/Script/UMG/EBindingKind.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x50 (unaligned: 0x50, alignment: 0x8)
    struct RC_UE4SS_SDK_API FDelegateRuntimeBinding
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x50;
        }

        FDelegateRuntimeBinding& operator=(const FDelegateRuntimeBinding& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FString ObjectName{}; // 0x0
        FName PropertyName{}; // 0x10
        FName FunctionName{}; // 0x18
        FDynamicPropertyPath SourcePath{}; // 0x20
        EBindingKind Kind{}; // 0x48
        uint8 padding_1[0x7]{}; // 0x49

        // Functions.
    };


}

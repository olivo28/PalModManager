#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    namespace EUMGSequencePlayMode
    {
        enum Type
        {
            Forward,
            Reverse,
            PingPong,
        };
    }
}

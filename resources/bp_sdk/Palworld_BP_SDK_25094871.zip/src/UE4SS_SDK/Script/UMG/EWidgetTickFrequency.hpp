#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetTickFrequency : uint8
    {
        Never,
        Auto,
    };
}

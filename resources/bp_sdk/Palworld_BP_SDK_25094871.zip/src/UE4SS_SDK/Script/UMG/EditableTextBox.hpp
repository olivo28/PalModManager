#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/Slate/ETextJustify.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardDismissAction.hpp>
#include <UE4SS_SDK/Script/Slate/EVirtualKeyboardTrigger.hpp>
#include <UE4SS_SDK/Script/Slate/VirtualKeyboardOptions.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextCommit.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextOverflowPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/EditableTextBoxStyle.hpp>
#include <UE4SS_SDK/Script/UMG/EVirtualKeyboardType.hpp>
#include <UE4SS_SDK/Script/UMG/ShapedTextOptions.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x1080 (unaligned: 0x1080, alignment: 0x10)
    class RC_UE4SS_SDK_API UEditableTextBox : public WSDK::UWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x150
        FScriptDelegate TextDelegate{}; // 0x168
        uint8 padding_1[0x8]{}; // 0x178
        FEditableTextBoxStyle WidgetStyle{}; // 0x180
        FText HintText{}; // 0x1010
        FScriptDelegate HintTextDelegate{}; // 0x1028
        bool IsReadOnly{}; // 0x1038
        bool IsPassword{}; // 0x1039
        uint8 padding_2[0x2]{}; // 0x103A
        float MinimumDesiredWidth{}; // 0x103C
        bool IsCaretMovedWhenGainFocus{}; // 0x1040
        bool SelectAllTextWhenFocused{}; // 0x1041
        bool RevertTextOnEscape{}; // 0x1042
        bool ClearKeyboardFocusOnCommit{}; // 0x1043
        bool SelectAllTextOnCommit{}; // 0x1044
        bool AllowContextMenu{}; // 0x1045
        TEnumAsByte<EVirtualKeyboardType::Type> KeyboardType{}; // 0x1046
        FVirtualKeyboardOptions VirtualKeyboardOptions{}; // 0x1047
        EVirtualKeyboardTrigger VirtualKeyboardTrigger{}; // 0x1048
        EVirtualKeyboardDismissAction VirtualKeyboardDismissAction{}; // 0x1049
        TEnumAsByte<ETextJustify::Type> Justification{}; // 0x104A
        ETextOverflowPolicy OverflowPolicy{}; // 0x104B
        FShapedTextOptions ShapedTextOptions{}; // 0x104C
        uint8 padding_3[0x1]{}; // 0x104F
        FMulticastScriptDelegate OnTextChanged{}; // 0x1050
        FMulticastScriptDelegate OnTextCommitted{}; // 0x1060
        uint8 padding_4[0x10]{}; // 0x1070

        // Functions.
        void SetTextOverflowPolicy(ETextOverflowPolicy InOverflowPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetTextOverflowPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InOverflowPolicy, ETextOverflowPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetJustification(TEnumAsByte<ETextJustify::Type> InJustification)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetJustification", 1)
            UE_COPY_PROPERTY_CUSTOM(InJustification, TEnumAsByte<ETextJustify::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsReadOnly(bool bReadOnly)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetIsReadOnly", 1)
            UE_COPY_PROPERTY_CUSTOM(bReadOnly, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsPassword(bool bIsPassword)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetIsPassword", 1)
            UE_COPY_PROPERTY_CUSTOM(bIsPassword, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHintText(FText InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetHintText", 24)
            UE_COPY_PROPERTY_CUSTOM(InText, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetForegroundColor(FLinearColor Color)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetForegroundColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Color.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetError(FText InError)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:SetError", 24)
            UE_COPY_PROPERTY_CUSTOM(InError, FText, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnEditableTextBoxCommittedEvent__DelegateSignature(FText& Text, TEnumAsByte<ETextCommit::Type> CommitMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:OnEditableTextBoxCommittedEvent__DelegateSignature", 25)
            UE_COPY_PROPERTY_CUSTOM(CommitMethod, TEnumAsByte<ETextCommit::Type>, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        void OnEditableTextBoxChangedEvent__DelegateSignature(FText& Text)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:OnEditableTextBoxChangedEvent__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        bool HasError()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:HasError", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        void ClearError()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.EditableTextBox:ClearError", 0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    namespace ESlateSizeRule
    {
        enum Type
        {
            Automatic,
            Fill,
        };
    }
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UMG/DynamicPropertyPath.hpp>
#include <Unreal/FWeakObjectPtr.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x28
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UPropertyBinding : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TWeakObjectPtr<UObject> SourceObject{}; // 0x28
        FDynamicPropertyPath SourcePath{}; // 0x30
        FName DestinationProperty{}; // 0x58

        // Functions.
    };


}

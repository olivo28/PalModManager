#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x28
    // Size: 0x88 (unaligned: 0x88, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetTree : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x28
        UWidget* RootWidget{}; // 0x30
        TMap<FName, UWidget*> NamedSlotBindings{}; // 0x38

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/ScrollBarStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x900 (unaligned: 0x900, alignment: 0x10)
    class RC_UE4SS_SDK_API UScrollBar : public WSDK::UWidget
    {
    public:
        // Properties.
        FScrollBarStyle WidgetStyle{}; // 0x150
        bool bAlwaysShowScrollbar{}; // 0x8C0
        bool bAlwaysShowScrollbarTrack{}; // 0x8C1
        TEnumAsByte<EOrientation> Orientation{}; // 0x8C2
        uint8 padding_1[0x5]{}; // 0x8C3
        FVector2D Thickness{}; // 0x8C8
        FMargin Padding{}; // 0x8D8
        uint8 padding_2[0x18]{}; // 0x8E8

        // Functions.
        void SetState(float InOffsetFraction, float InThumbSizeFraction)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ScrollBar:SetState", 8)
            UE_COPY_PROPERTY_CUSTOM(InOffsetFraction, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InThumbSizeFraction, float, 0x4)
            UE_CALL_FUNCTION()
        }
    };


}

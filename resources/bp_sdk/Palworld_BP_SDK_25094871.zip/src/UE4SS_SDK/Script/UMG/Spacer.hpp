#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x170 (unaligned: 0x170, alignment: 0x8)
    class RC_UE4SS_SDK_API USpacer : public WSDK::UWidget
    {
    public:
        // Properties.
        FVector2D Size{}; // 0x150
        uint8 padding_1[0x10]{}; // 0x160

        // Functions.
        void SetSize(FVector2D InSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Spacer:SetSize", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InSize.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InSize.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
    };


}

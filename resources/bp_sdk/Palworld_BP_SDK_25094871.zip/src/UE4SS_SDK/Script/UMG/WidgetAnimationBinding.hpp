#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x24 (unaligned: 0x24, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWidgetAnimationBinding
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x24;
        }

        FWidgetAnimationBinding& operator=(const FWidgetAnimationBinding& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FName WidgetName{}; // 0x0
        FName SlotWidgetName{}; // 0x8
        FGuid AnimationGuid{}; // 0x10
        bool bIsRootWidget{}; // 0x20
        uint8 padding_1[0x3]{}; // 0x21

        // Functions.
    };


}

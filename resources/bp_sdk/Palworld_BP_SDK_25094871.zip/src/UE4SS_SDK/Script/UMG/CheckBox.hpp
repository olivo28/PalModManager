#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/CheckBoxStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonClickMethod.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonPressMethod.hpp>
#include <UE4SS_SDK/Script/SlateCore/EButtonTouchMethod.hpp>
#include <UE4SS_SDK/Script/SlateCore/ECheckBoxState.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0xC80 (unaligned: 0xC80, alignment: 0x10)
    class RC_UE4SS_SDK_API UCheckBox : public WSDK::UContentWidget
    {
    public:
        // Properties.
        ECheckBoxState CheckedState{}; // 0x168
        uint8 padding_1[0x3]{}; // 0x169
        FScriptDelegate CheckedStateDelegate{}; // 0x16C
        uint8 padding_2[0x4]{}; // 0x17C
        FCheckBoxStyle WidgetStyle{}; // 0x180
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0xC50
        TEnumAsByte<EButtonClickMethod::Type> ClickMethod{}; // 0xC51
        TEnumAsByte<EButtonTouchMethod::Type> TouchMethod{}; // 0xC52
        TEnumAsByte<EButtonPressMethod::Type> PressMethod{}; // 0xC53
        bool IsFocusable{}; // 0xC54
        uint8 padding_3[0x3]{}; // 0xC55
        FMulticastScriptDelegate OnCheckStateChanged{}; // 0xC58
        uint8 padding_4[0x18]{}; // 0xC68

        // Functions.
        void SetTouchMethod(TEnumAsByte<EButtonTouchMethod::Type> InTouchMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:SetTouchMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InTouchMethod, TEnumAsByte<EButtonTouchMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPressMethod(TEnumAsByte<EButtonPressMethod::Type> InPressMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:SetPressMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InPressMethod, TEnumAsByte<EButtonPressMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsChecked(bool InIsChecked)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:SetIsChecked", 1)
            UE_COPY_PROPERTY_CUSTOM(InIsChecked, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetClickMethod(TEnumAsByte<EButtonClickMethod::Type> InClickMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:SetClickMethod", 1)
            UE_COPY_PROPERTY_CUSTOM(InClickMethod, TEnumAsByte<EButtonClickMethod::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetCheckedState(ECheckBoxState InCheckedState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:SetCheckedState", 1)
            UE_COPY_PROPERTY_CUSTOM(InCheckedState, ECheckBoxState, 0x0)
            UE_CALL_FUNCTION()
        }
        bool IsPressed()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:IsPressed", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsChecked()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:IsChecked", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        ECheckBoxState GetCheckedState()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CheckBox:GetCheckedState", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ECheckBoxState, 0x0)
        }
    };


}

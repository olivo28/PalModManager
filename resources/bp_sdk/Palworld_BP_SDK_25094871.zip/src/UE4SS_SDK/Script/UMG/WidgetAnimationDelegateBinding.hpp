#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/DynamicBlueprintBinding.hpp>
#include <UE4SS_SDK/Script/UMG/BlueprintWidgetAnimationDelegateBinding.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetAnimationDelegateBinding : public WSDK::UDynamicBlueprintBinding
    {
    public:
        // Properties.
        TArray<FBlueprintWidgetAnimationDelegateBinding> WidgetAnimationDelegateBindings{}; // 0x28

        // Functions.
    };


}

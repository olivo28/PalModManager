#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/UMG/PropertyBinding.hpp>

namespace WSDK
{
    // Super Size: 0x60
    // Size: 0x68 (unaligned: 0x68, alignment: 0x8)
    class RC_UE4SS_SDK_API UColorBinding : public WSDK::UPropertyBinding
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x60

        // Functions.
        FSlateColor GetSlateValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ColorBinding:GetSlateValue", 20)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FSlateColor, 0x0)
        }
        FLinearColor GetLinearValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ColorBinding:GetLinearValue", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FLinearColor, 0x0)
        }
    };


}

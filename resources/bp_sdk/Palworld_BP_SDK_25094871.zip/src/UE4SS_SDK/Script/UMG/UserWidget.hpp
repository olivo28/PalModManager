#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/EInputEvent.hpp>
#include <UE4SS_SDK/Script/Slate/Anchors.hpp>
#include <UE4SS_SDK/Script/SlateCore/AnalogInputEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/CharacterEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/FocusEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/Geometry.hpp>
#include <UE4SS_SDK/Script/SlateCore/KeyEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/MotionEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/PointerEvent.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/UMG/AnimationEventBinding.hpp>
#include <UE4SS_SDK/Script/UMG/EUMGSequencePlayMode.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetAnimationEvent.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetTickFrequency.hpp>
#include <UE4SS_SDK/Script/UMG/EventReply.hpp>
#include <UE4SS_SDK/Script/UMG/NamedSlotBinding.hpp>
#include <UE4SS_SDK/Script/UMG/PaintContext.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class APawn;
    class APlayerCameraManager;
    class APlayerController;
    class UDragDropOperation;
    class UInputComponent;
    class USoundBase;
    class UUMGSequencePlayer;
    class UUMGSequenceTickManager;
    class UUserWidgetExtension;
    class UWidgetAnimation;
    class UWidgetTree;

    // Super Size: 0x150
    // Size: 0x278 (unaligned: 0x278, alignment: 0x8)
    class RC_UE4SS_SDK_API UUserWidget : public WSDK::UWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x150
        FLinearColor ColorAndOpacity{}; // 0x158
        FScriptDelegate ColorAndOpacityDelegate{}; // 0x168
        FSlateColor ForegroundColor{}; // 0x178
        FScriptDelegate ForegroundColorDelegate{}; // 0x18C
        uint8 padding_2[0x4]{}; // 0x19C
        FMulticastScriptDelegate OnVisibilityChanged{}; // 0x1A0
        uint8 padding_3[0x18]{}; // 0x1B0
        FMargin Padding{}; // 0x1C8
        TArray<UUMGSequencePlayer*> ActiveSequencePlayers{}; // 0x1D8
        UUMGSequenceTickManager* AnimationTickManager{}; // 0x1E8
        TArray<UUMGSequencePlayer*> StoppedSequencePlayers{}; // 0x1F0
        TArray<FNamedSlotBinding> NamedSlotBindings{}; // 0x200
        TArray<UUserWidgetExtension*> Extensions{}; // 0x210
        UWidgetTree* WidgetTree{}; // 0x220
        int32 Priority{}; // 0x228
        uint8 bIsFocusable : 1{}; // 0x22C (0x1)
        uint8 bStopAction : 1{}; // 0x22C (0x2)
        uint8 bHasScriptImplementedTick : 1{}; // 0x22C (0x4)
        uint8 bHasScriptImplementedPaint : 1{}; // 0x22C (0x8)
        uint8 padding_4 : 1{}; // 0x22C (0x10)
        uint8 padding_5 : 1{}; // 0x22C (0x20)
        uint8 padding_6 : 1{}; // 0x22C (0x40)
        uint8 padding_7 : 1{}; // 0x22C (0x80)
        uint8 padding_8[0x13]{}; // 0x22D
        EWidgetTickFrequency TickFrequency{}; // 0x240
        uint8 padding_9[0x7]{}; // 0x241
        UInputComponent* InputComponent{}; // 0x248
        TArray<FAnimationEventBinding> AnimationCallbacks{}; // 0x250
        uint8 padding_10[0x18]{}; // 0x260

        // Functions.
        void UnregisterInputComponent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:UnregisterInputComponent", 0)
            UE_CALL_FUNCTION()
        }
        void UnbindFromAnimationStarted(UWidgetAnimation* Animation, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:UnbindFromAnimationStarted", 24)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void UnbindFromAnimationFinished(UWidgetAnimation* Animation, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:UnbindFromAnimationFinished", 24)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void UnbindAllFromAnimationStarted(UWidgetAnimation* Animation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:UnbindAllFromAnimationStarted", 8)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        void UnbindAllFromAnimationFinished(UWidgetAnimation* Animation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:UnbindAllFromAnimationFinished", 8)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        void Tick(FGeometry MyGeometry, float InDeltaTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:Tick", 68)
            UE_COPY_PROPERTY_CUSTOM(InDeltaTime, float, 0x40)
            UE_CALL_FUNCTION()
        }
        void StopListeningForInputAction(FName ActionName, TEnumAsByte<EInputEvent> EventType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:StopListeningForInputAction", 9)
            UE_COPY_PROPERTY_CUSTOM(ActionName, FName, 0x0)
            UE_COPY_PROPERTY_CUSTOM(EventType, TEnumAsByte<EInputEvent>, 0x8)
            UE_CALL_FUNCTION()
        }
        void StopListeningForAllInputActions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:StopListeningForAllInputActions", 0)
            UE_CALL_FUNCTION()
        }
        void StopAnimationsAndLatentActions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:StopAnimationsAndLatentActions", 0)
            UE_CALL_FUNCTION()
        }
        void StopAnimation(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:StopAnimation", 8)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        void StopAllAnimations()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:StopAllAnimations", 0)
            UE_CALL_FUNCTION()
        }
        void SetPositionInViewport(FVector2D Position, bool bRemoveDPIScale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetPositionInViewport", 17)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.Y, 0x0, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bRemoveDPIScale, bool, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetPlaybackSpeed(UWidgetAnimation* InAnimation, float PlaybackSpeed)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetPlaybackSpeed", 12)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetOwningPlayer(APlayerController* LocalPlayerController)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetOwningPlayer", 8)
            UE_COPY_PROPERTY_CUSTOM(LocalPlayerController, APlayerController*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetNumLoopsToPlay(UWidgetAnimation* InAnimation, int32 NumLoopsToPlay)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetNumLoopsToPlay", 12)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(NumLoopsToPlay, int32, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetInputActionPriority(int32 NewPriority)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetInputActionPriority", 4)
            UE_COPY_PROPERTY_CUSTOM(NewPriority, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetInputActionBlocking(bool bShouldBlock)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetInputActionBlocking", 1)
            UE_COPY_PROPERTY_CUSTOM(bShouldBlock, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetForegroundColor(FSlateColor InForegroundColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetForegroundColor", 20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FLinearColor, InForegroundColor.SpecifiedColor, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ESlateColorStylingMode, InForegroundColor.ColorUseRule, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetDesiredSizeInViewport(FVector2D Size)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetDesiredSizeInViewport", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetColorAndOpacity(FLinearColor InColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetAnimationCurrentTime(UWidgetAnimation* InAnimation, float InTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetAnimationCurrentTime", 12)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InTime, float, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetAnchorsInViewport(FAnchors Anchors)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetAnchorsInViewport", 32)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Anchors.Minimum, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Anchors.Maximum, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetAlignmentInViewport(FVector2D Alignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:SetAlignmentInViewport", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Alignment.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Alignment.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void ReverseAnimation(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:ReverseAnimation", 8)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        void RemoveFromViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:RemoveFromViewport", 0)
            UE_CALL_FUNCTION()
        }
        void RemoveExtensions(TSubclassOf<UUserWidgetExtension> InExtensionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:RemoveExtensions", 8)
            UE_COPY_PROPERTY_CUSTOM(InExtensionType, TSubclassOf<UUserWidgetExtension>, 0x0)
            UE_CALL_FUNCTION()
        }
        void RemoveExtension(UUserWidgetExtension* InExtension)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:RemoveExtension", 8)
            UE_COPY_PROPERTY_CUSTOM(InExtension, UUserWidgetExtension*, 0x0)
            UE_CALL_FUNCTION()
        }
        void RegisterInputComponent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:RegisterInputComponent", 0)
            UE_CALL_FUNCTION()
        }
        void PreConstruct(bool IsDesignTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PreConstruct", 1)
            UE_COPY_PROPERTY_CUSTOM(IsDesignTime, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void PlaySound(USoundBase* SoundToPlay)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PlaySound", 8)
            UE_COPY_PROPERTY_CUSTOM(SoundToPlay, USoundBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        UUMGSequencePlayer* PlayAnimationTimeRange(UWidgetAnimation* InAnimation, float StartAtTime, float EndAtTime, int32 NumLoopsToPlay, TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode, float PlaybackSpeed, bool bRestoreState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PlayAnimationTimeRange", 40)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(StartAtTime, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(EndAtTime, float, 0xC)
            UE_COPY_PROPERTY_CUSTOM(NumLoopsToPlay, int32, 0x10)
            UE_COPY_PROPERTY_CUSTOM(PlayMode, TEnumAsByte<EUMGSequencePlayMode::Type>, 0x14)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x18)
            UE_COPY_PROPERTY_CUSTOM(bRestoreState, bool, 0x1C)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUMGSequencePlayer*, 0x20)
        }
        UUMGSequencePlayer* PlayAnimationReverse(UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PlayAnimationReverse", 24)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bRestoreState, bool, 0xC)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUMGSequencePlayer*, 0x10)
        }
        UUMGSequencePlayer* PlayAnimationForward(UWidgetAnimation* InAnimation, float PlaybackSpeed, bool bRestoreState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PlayAnimationForward", 24)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bRestoreState, bool, 0xC)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUMGSequencePlayer*, 0x10)
        }
        UUMGSequencePlayer* PlayAnimation(UWidgetAnimation* InAnimation, float StartAtTime, int32 NumLoopsToPlay, TEnumAsByte<EUMGSequencePlayMode::Type> PlayMode, float PlaybackSpeed, bool bRestoreState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PlayAnimation", 40)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(StartAtTime, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(NumLoopsToPlay, int32, 0xC)
            UE_COPY_PROPERTY_CUSTOM(PlayMode, TEnumAsByte<EUMGSequencePlayMode::Type>, 0x10)
            UE_COPY_PROPERTY_CUSTOM(PlaybackSpeed, float, 0x14)
            UE_COPY_PROPERTY_CUSTOM(bRestoreState, bool, 0x18)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUMGSequencePlayer*, 0x20)
        }
        float PauseAnimation(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:PauseAnimation", 12)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x8)
        }
        FEventReply OnTouchStarted(FGeometry MyGeometry, FPointerEvent& InTouchEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnTouchStarted", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTouchEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnTouchMoved(FGeometry MyGeometry, FPointerEvent& InTouchEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnTouchMoved", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTouchEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnTouchGesture(FGeometry MyGeometry, FPointerEvent& GestureEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnTouchGesture", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(GestureEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnTouchForceChanged(FGeometry MyGeometry, FPointerEvent& InTouchEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnTouchForceChanged", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTouchEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnTouchEnded(FGeometry MyGeometry, FPointerEvent& InTouchEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnTouchEnded", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTouchEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        void OnRemovedFromFocusPath(FFocusEvent InFocusEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnRemovedFromFocusPath", 8)
            UE_CALL_FUNCTION()
        }
        FEventReply OnPreviewMouseButtonDown(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnPreviewMouseButtonDown", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnPreviewKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnPreviewKeyDown", 312)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x80)
        }
        void OnPaint(FPaintContext& Context)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnPaint", 48)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Context, FPaintContext, 0x0)
        }
        FEventReply OnMouseWheel(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseWheel", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnMouseMove(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseMove", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        void OnMouseLeave(FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseLeave", 152)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x0)
        }
        void OnMouseEnter(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseEnter", 216)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
        }
        void OnMouseCaptureLost()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseCaptureLost", 0)
            UE_CALL_FUNCTION()
        }
        FEventReply OnMouseButtonUp(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseButtonUp", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnMouseButtonDown(FGeometry MyGeometry, FPointerEvent& MouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseButtonDown", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(MouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnMouseButtonDoubleClick(FGeometry InMyGeometry, FPointerEvent& InMouseEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMouseButtonDoubleClick", 400)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InMouseEvent, FPointerEvent, 0x40)
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xD8)
        }
        FEventReply OnMotionDetected(FGeometry MyGeometry, FMotionEvent InMotionEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnMotionDetected", 376)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0xC0)
        }
        FEventReply OnKeyUp(FGeometry MyGeometry, FKeyEvent InKeyEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnKeyUp", 312)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x80)
        }
        FEventReply OnKeyDown(FGeometry MyGeometry, FKeyEvent InKeyEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnKeyDown", 312)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x80)
        }
        FEventReply OnKeyChar(FGeometry MyGeometry, FCharacterEvent InCharacterEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnKeyChar", 288)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x68)
        }
        void OnInitialized()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnInitialized", 0)
            UE_CALL_FUNCTION()
        }
        FEventReply OnFocusReceived(FGeometry MyGeometry, FFocusEvent InFocusEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnFocusReceived", 256)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x48)
        }
        void OnFocusLost(FFocusEvent InFocusEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnFocusLost", 8)
            UE_CALL_FUNCTION()
        }
        bool OnDrop(FGeometry MyGeometry, FPointerEvent PointerEvent, UDragDropOperation* Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDrop", 225)
            UE_COPY_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0xD8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xE0)
        }
        bool OnDragOver(FGeometry MyGeometry, FPointerEvent PointerEvent, UDragDropOperation* Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDragOver", 225)
            UE_COPY_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0xD8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xE0)
        }
        void OnDragLeave(FPointerEvent PointerEvent, UDragDropOperation* Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDragLeave", 160)
            UE_COPY_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0x98)
            UE_CALL_FUNCTION()
        }
        void OnDragEnter(FGeometry MyGeometry, FPointerEvent PointerEvent, UDragDropOperation* Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDragEnter", 224)
            UE_COPY_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0xD8)
            UE_CALL_FUNCTION()
        }
        void OnDragDetected(FGeometry MyGeometry, FPointerEvent& PointerEvent, UDragDropOperation*& Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDragDetected", 224)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x40)
            UE_COPY_OUT_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0xD8)
        }
        void OnDragCancelled(FPointerEvent& PointerEvent, UDragDropOperation* Operation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnDragCancelled", 160)
            UE_COPY_PROPERTY_CUSTOM(Operation, UDragDropOperation*, 0x98)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PointerEvent, FPointerEvent, 0x0)
        }
        void OnAnimationStarted(UWidgetAnimation* Animation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnAnimationStarted", 8)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnAnimationFinished(UWidgetAnimation* Animation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnAnimationFinished", 8)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
        }
        FEventReply OnAnalogValueChanged(FGeometry MyGeometry, FAnalogInputEvent InAnalogInputEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnAnalogValueChanged", 320)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FEventReply, 0x88)
        }
        void OnAddedToFocusPath(FFocusEvent InFocusEvent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:OnAddedToFocusPath", 8)
            UE_CALL_FUNCTION()
        }
        void ListenForInputAction(FName ActionName, TEnumAsByte<EInputEvent> EventType, bool bConsume, FScriptDelegate Callback)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:ListenForInputAction", 28)
            UE_COPY_PROPERTY_CUSTOM(ActionName, FName, 0x0)
            UE_COPY_PROPERTY_CUSTOM(EventType, TEnumAsByte<EInputEvent>, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bConsume, bool, 0x9)
            UE_COPY_PROPERTY_CUSTOM(Callback, FScriptDelegate, 0xC)
            UE_CALL_FUNCTION()
        }
        bool IsPlayingAnimation()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsPlayingAnimation", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsListeningForInputAction(FName ActionName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsListeningForInputAction", 9)
            UE_COPY_PROPERTY_CUSTOM(ActionName, FName, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool IsInteractable()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsInteractable", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsAnyAnimationPlaying()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsAnyAnimationPlaying", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsAnimationPlayingForward(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsAnimationPlayingForward", 9)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool IsAnimationPlaying(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:IsAnimationPlaying", 9)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        APawn* GetOwningPlayerPawn()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetOwningPlayerPawn", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(APawn*, 0x0)
        }
        APlayerCameraManager* GetOwningPlayerCameraManager()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetOwningPlayerCameraManager", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(APlayerCameraManager*, 0x0)
        }
        bool GetIsVisible()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetIsVisible", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        TArray<UUserWidgetExtension*> GetExtensions(TSubclassOf<UUserWidgetExtension> ExtensionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetExtensions", 24)
            UE_COPY_PROPERTY_CUSTOM(ExtensionType, TSubclassOf<UUserWidgetExtension>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UUserWidgetExtension*>, 0x8)
        }
        UUserWidgetExtension* GetExtension(TSubclassOf<UUserWidgetExtension> ExtensionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetExtension", 16)
            UE_COPY_PROPERTY_CUSTOM(ExtensionType, TSubclassOf<UUserWidgetExtension>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidgetExtension*, 0x8)
        }
        float GetAnimationCurrentTime(UWidgetAnimation* InAnimation)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetAnimationCurrentTime", 12)
            UE_COPY_PROPERTY_CUSTOM(InAnimation, UWidgetAnimation*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x8)
        }
        FAnchors GetAnchorsInViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetAnchorsInViewport", 32)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FAnchors, 0x0)
        }
        FVector2D GetAlignmentInViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:GetAlignmentInViewport", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        void FlushAnimations()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:FlushAnimations", 0)
            UE_CALL_FUNCTION()
        }
        void Destruct()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:Destruct", 0)
            UE_CALL_FUNCTION()
        }
        void Construct()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:Construct", 0)
            UE_CALL_FUNCTION()
        }
        void CancelLatentActions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:CancelLatentActions", 0)
            UE_CALL_FUNCTION()
        }
        void BindToAnimationStarted(UWidgetAnimation* Animation, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:BindToAnimationStarted", 24)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void BindToAnimationFinished(UWidgetAnimation* Animation, FScriptDelegate Delegate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:BindToAnimationFinished", 24)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_CALL_FUNCTION()
        }
        void BindToAnimationEvent(UWidgetAnimation* Animation, FScriptDelegate Delegate, EWidgetAnimationEvent AnimationEvent, FName UserTag)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:BindToAnimationEvent", 36)
            UE_COPY_PROPERTY_CUSTOM(Animation, UWidgetAnimation*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Delegate, FScriptDelegate, 0x8)
            UE_COPY_PROPERTY_CUSTOM(AnimationEvent, EWidgetAnimationEvent, 0x18)
            UE_COPY_PROPERTY_CUSTOM(UserTag, FName, 0x1C)
            UE_CALL_FUNCTION()
        }
        void AddToViewport(int32 ZOrder)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:AddToViewport", 4)
            UE_COPY_PROPERTY_CUSTOM(ZOrder, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        bool AddToPlayerScreen(int32 ZOrder)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:AddToPlayerScreen", 5)
            UE_COPY_PROPERTY_CUSTOM(ZOrder, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x4)
        }
        UUserWidgetExtension* AddExtension(TSubclassOf<UUserWidgetExtension> InExtensionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UserWidget:AddExtension", 16)
            UE_COPY_PROPERTY_CUSTOM(InExtensionType, TSubclassOf<UUserWidgetExtension>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidgetExtension*, 0x8)
        }
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETickMode : uint8
    {
        Disabled,
        Enabled,
        Automatic,
    };
}

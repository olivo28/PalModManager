#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetSpace : uint8
    {
        World,
        Screen,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SceneComponentInstanceData.hpp>

namespace WSDK
{
    // Super Size: 0xB8
    // Size: 0xC8 (unaligned: 0xC8, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWidgetComponentInstanceData : public WSDK::FSceneComponentInstanceData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC8;
        }

        FWidgetComponentInstanceData& operator=(const FWidgetComponentInstanceData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x10]{}; // 0xB8

        // Functions.
    };


}

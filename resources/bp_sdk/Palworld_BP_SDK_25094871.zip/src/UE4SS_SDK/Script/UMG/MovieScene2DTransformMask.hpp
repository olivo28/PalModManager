#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x4 (unaligned: 0x4, alignment: 0x4)
    struct RC_UE4SS_SDK_API FMovieScene2DTransformMask
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x4;
        }

        FMovieScene2DTransformMask& operator=(const FMovieScene2DTransformMask& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint32 mask{}; // 0x0

        // Functions.
    };


}

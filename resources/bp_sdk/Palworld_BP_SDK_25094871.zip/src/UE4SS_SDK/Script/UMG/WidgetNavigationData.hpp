#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EUINavigationRule.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FWeakObjectPtr.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x0
    // Size: 0x24 (unaligned: 0x24, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWidgetNavigationData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x24;
        }

        FWidgetNavigationData& operator=(const FWidgetNavigationData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EUINavigationRule Rule{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        FName WidgetToFocus{}; // 0x4
        TWeakObjectPtr<UWidget> Widget{}; // 0xC
        FScriptDelegate CustomDelegate{}; // 0x14

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextOverflowPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextTransformPolicy.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/TextBlockStyle.hpp>
#include <UE4SS_SDK/Script/UMG/TextLayoutWidget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UDataTable;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class URichTextBlockDecorator;

    // Super Size: 0x170
    // Size: 0x890 (unaligned: 0x890, alignment: 0x10)
    class RC_UE4SS_SDK_API URichTextBlock : public WSDK::UTextLayoutWidget
    {
    public:
        // Properties.
        FText Text{}; // 0x170
        UDataTable* TextStyleSet{}; // 0x188
        TArray<TSubclassOf<URichTextBlockDecorator>> DecoratorClasses{}; // 0x190
        bool bOverrideDefaultStyle{}; // 0x1A0
        uint8 padding_1[0xF]{}; // 0x1A1
        FTextBlockStyle DefaultTextStyleOverride{}; // 0x1B0
        float MinDesiredWidth{}; // 0x500
        ETextTransformPolicy TextTransformPolicy{}; // 0x504
        ETextOverflowPolicy TextOverflowPolicy{}; // 0x505
        uint8 padding_2[0xA]{}; // 0x506
        FTextBlockStyle DefaultTextStyle{}; // 0x510
        TArray<URichTextBlockDecorator*> InstanceDecorators{}; // 0x860
        uint8 padding_3[0x20]{}; // 0x870

        // Functions.
        void SetTextTransformPolicy(ETextTransformPolicy InTransformPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetTextTransformPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InTransformPolicy, ETextTransformPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTextStyleSet(UDataTable* NewTextStyleSet)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetTextStyleSet", 8)
            UE_COPY_PROPERTY_CUSTOM(NewTextStyleSet, UDataTable*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetTextOverflowPolicy(ETextOverflowPolicy InOverflowPolicy)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetTextOverflowPolicy", 1)
            UE_COPY_PROPERTY_CUSTOM(InOverflowPolicy, ETextOverflowPolicy, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetText(FText& InText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetText", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InText, FText, 0x0)
        }
        void SetMinDesiredWidth(float InMinDesiredWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetMinDesiredWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDefaultTextStyle(FTextBlockStyle& InDefaultTextStyle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultTextStyle", 848)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InDefaultTextStyle, FTextBlockStyle, 0x0)
        }
        void SetDefaultStrikeBrush(FSlateBrush& InStrikeBrush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultStrikeBrush", 208)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InStrikeBrush, FSlateBrush, 0x0)
        }
        void SetDefaultShadowOffset(FVector2D InShadowOffset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultShadowOffset", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InShadowOffset.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InShadowOffset.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetDefaultShadowColorAndOpacity(FLinearColor InShadowColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultShadowColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InShadowColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetDefaultMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDefaultFont(FSlateFontInfo InFontInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultFont", 96)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontObject, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(UObject*, InFontInfo.FontMaterial, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FFontOutlineSettings, InFontInfo.OutlineSettings, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, InFontInfo.TypefaceFontName, 0x0, 0x48)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.Size, 0x0, 0x50)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, InFontInfo.LetterSpacing, 0x0, 0x54)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InFontInfo.SkewAmount, 0x0, 0x58)
            UE_CALL_FUNCTION()
        }
        void SetDefaultColorAndOpacity(FSlateColor InColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDefaultColorAndOpacity", 20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FLinearColor, InColorAndOpacity.SpecifiedColor, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ESlateColorStylingMode, InColorAndOpacity.ColorUseRule, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetDecorators(TArray<TSubclassOf<URichTextBlockDecorator>>& InDecoratorClasses)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetDecorators", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InDecoratorClasses, TArray<TSubclassOf<URichTextBlockDecorator>>, 0x0)
        }
        void SetAutoWrapText(bool InAutoTextWrap)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:SetAutoWrapText", 1)
            UE_COPY_PROPERTY_CUSTOM(InAutoTextWrap, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void RefreshTextLayout()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:RefreshTextLayout", 0)
            UE_CALL_FUNCTION()
        }
        UDataTable* GetTextStyleSet()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:GetTextStyleSet", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UDataTable*, 0x0)
        }
        FText GetText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:GetText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        UMaterialInstanceDynamic* GetDefaultDynamicMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:GetDefaultDynamicMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        URichTextBlockDecorator* GetDecoratorByClass(TSubclassOf<URichTextBlockDecorator> DecoratorClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:GetDecoratorByClass", 16)
            UE_COPY_PROPERTY_CUSTOM(DecoratorClass, TSubclassOf<URichTextBlockDecorator>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(URichTextBlockDecorator*, 0x8)
        }
        void ClearAllDefaultStyleOverrides()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.RichTextBlock:ClearAllDefaultStyleOverrides", 0)
            UE_CALL_FUNCTION()
        }
    };


}

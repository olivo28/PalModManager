#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ComboBoxStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/ESelectInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateFontInfo.hpp>
#include <UE4SS_SDK/Script/SlateCore/TableRowStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x1630 (unaligned: 0x1630, alignment: 0x10)
    class RC_UE4SS_SDK_API UComboBoxString : public WSDK::UWidget
    {
    public:
        // Properties.
        TArray<FString> DefaultOptions{}; // 0x150
        FString SelectedOption{}; // 0x160
        FComboBoxStyle WidgetStyle{}; // 0x170
        FTableRowStyle ItemStyle{}; // 0x7D0
        FMargin ContentPadding{}; // 0x1520
        float MaxListHeight{}; // 0x1530
        bool HasDownArrow{}; // 0x1534
        bool EnableGamepadNavigationMode{}; // 0x1535
        uint8 padding_1[0x2]{}; // 0x1536
        FSlateFontInfo Font{}; // 0x1538
        FSlateColor ForegroundColor{}; // 0x1598
        bool bIsFocusable{}; // 0x15AC
        uint8 padding_2[0x3]{}; // 0x15AD
        FScriptDelegate OnGenerateWidgetEvent{}; // 0x15B0
        FMulticastScriptDelegate OnSelectionChanged{}; // 0x15C0
        FMulticastScriptDelegate OnOpening{}; // 0x15D0
        uint8 padding_3[0x50]{}; // 0x15E0

        // Functions.
        void SetSelectedOption(FString& Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:SetSelectedOption", 16)
            UE_COPY_PROPERTY_CUSTOM(Option, FString, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSelectedIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:SetSelectedIndex", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        bool RemoveOption(FString& Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:RemoveOption", 17)
            UE_COPY_PROPERTY_CUSTOM(Option, FString, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        void RefreshOptions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:RefreshOptions", 0)
            UE_CALL_FUNCTION()
        }
        void OnSelectionChangedEvent__DelegateSignature(FString& SelectedItem, TEnumAsByte<ESelectInfo::Type> SelectionType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:OnSelectionChangedEvent__DelegateSignature", 17)
            UE_COPY_PROPERTY_CUSTOM(SelectedItem, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(SelectionType, TEnumAsByte<ESelectInfo::Type>, 0x10)
            UE_CALL_FUNCTION()
        }
        void OnOpeningEvent__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:OnOpeningEvent__DelegateSignature", 0)
            UE_CALL_FUNCTION()
        }
        bool IsOpen()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:IsOpen", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FString GetSelectedOption()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:GetSelectedOption", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x0)
        }
        int32 GetSelectedIndex()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:GetSelectedIndex", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        int32 GetOptionCount()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:GetOptionCount", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        FString GetOptionAtIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:GetOptionAtIndex", 24)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x8)
        }
        int32 FindOptionIndex(FString& Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:FindOptionIndex", 20)
            UE_COPY_PROPERTY_CUSTOM(Option, FString, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x10)
        }
        void ClearSelection()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:ClearSelection", 0)
            UE_CALL_FUNCTION()
        }
        void ClearOptions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:ClearOptions", 0)
            UE_CALL_FUNCTION()
        }
        void AddOption(FString& Option)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ComboBoxString:AddOption", 16)
            UE_COPY_PROPERTY_CUSTOM(Option, FString, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

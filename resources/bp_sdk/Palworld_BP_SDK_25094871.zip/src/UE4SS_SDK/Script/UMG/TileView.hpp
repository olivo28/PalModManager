#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/EListItemAlignment.hpp>
#include <UE4SS_SDK/Script/UMG/ListView.hpp>

namespace WSDK
{
    // Super Size: 0xC20
    // Size: 0xC40 (unaligned: 0xC40, alignment: 0x10)
    class RC_UE4SS_SDK_API UTileView : public WSDK::UListView
    {
    public:
        // Properties.
        float EntryHeight{}; // 0xC20
        float EntryWidth{}; // 0xC24
        EListItemAlignment TileAlignment{}; // 0xC28
        bool bWrapHorizontalNavigation{}; // 0xC29
        uint8 padding_1[0x16]{}; // 0xC2A

        // Functions.
        void SetEntryWidth(float NewWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TileView:SetEntryWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(NewWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetEntryHeight(float NewHeight)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TileView:SetEntryHeight", 4)
            UE_COPY_PROPERTY_CUSTOM(NewHeight, float, 0x0)
            UE_CALL_FUNCTION()
        }
        float GetEntryWidth()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TileView:GetEntryWidth", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetEntryHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TileView:GetEntryHeight", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

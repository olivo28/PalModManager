#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetAnimationEvent.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x1C (unaligned: 0x1C, alignment: 0x4)
    struct RC_UE4SS_SDK_API FBlueprintWidgetAnimationDelegateBinding
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x1C;
        }

        FBlueprintWidgetAnimationDelegateBinding& operator=(const FBlueprintWidgetAnimationDelegateBinding& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWidgetAnimationEvent action{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        FName AnimationToBind{}; // 0x4
        FName FunctionNameToBind{}; // 0xC
        FName UserTag{}; // 0x14

        // Functions.
    };


}

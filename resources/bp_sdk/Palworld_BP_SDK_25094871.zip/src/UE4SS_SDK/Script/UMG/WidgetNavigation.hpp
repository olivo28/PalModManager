#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UMG/WidgetNavigationData.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x100 (unaligned: 0x100, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetNavigation : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FWidgetNavigationData Up{}; // 0x28
        FWidgetNavigationData Down{}; // 0x4C
        FWidgetNavigationData Left{}; // 0x70
        FWidgetNavigationData Right{}; // 0x94
        FWidgetNavigationData Next{}; // 0xB8
        FWidgetNavigationData Previous{}; // 0xDC

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/DynamicEntryBoxBase.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UUserWidget;

    // Super Size: 0x230
    // Size: 0x238 (unaligned: 0x238, alignment: 0x8)
    class RC_UE4SS_SDK_API UDynamicEntryBox : public WSDK::UDynamicEntryBoxBase
    {
    public:
        // Properties.
        TSubclassOf<UUserWidget> EntryWidgetClass{}; // 0x230

        // Functions.
        void Reset(bool bDeleteWidgets)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBox:Reset", 1)
            UE_COPY_PROPERTY_CUSTOM(bDeleteWidgets, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void RemoveEntry(UUserWidget* EntryWidget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBox:RemoveEntry", 8)
            UE_COPY_PROPERTY_CUSTOM(EntryWidget, UUserWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        UUserWidget* BP_CreateEntryOfClass(TSubclassOf<UUserWidget> EntryClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBox:BP_CreateEntryOfClass", 16)
            UE_COPY_PROPERTY_CUSTOM(EntryClass, TSubclassOf<UUserWidget>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x8)
        }
        UUserWidget* BP_CreateEntry()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.DynamicEntryBox:BP_CreateEntry", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x0)
        }
    };


}

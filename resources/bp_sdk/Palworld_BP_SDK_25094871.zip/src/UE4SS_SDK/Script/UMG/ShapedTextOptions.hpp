#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Slate/ETextFlowDirection.hpp>
#include <UE4SS_SDK/Script/SlateCore/ETextShapingMethod.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x3 (unaligned: 0x3, alignment: 0x1)
    struct RC_UE4SS_SDK_API FShapedTextOptions
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x3;
        }

        FShapedTextOptions& operator=(const FShapedTextOptions& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 bOverride_TextShapingMethod : 1{}; // 0x0 (0x1)
        uint8 bOverride_TextFlowDirection : 1{}; // 0x0 (0x2)
        uint8 padding_1 : 1{}; // 0x0 (0x4)
        uint8 padding_2 : 1{}; // 0x0 (0x8)
        uint8 padding_3 : 1{}; // 0x0 (0x10)
        uint8 padding_4 : 1{}; // 0x0 (0x20)
        uint8 padding_5 : 1{}; // 0x0 (0x40)
        uint8 padding_6 : 1{}; // 0x0 (0x80)
        ETextShapingMethod TextShapingMethod{}; // 0x1
        ETextFlowDirection TextFlowDirection{}; // 0x2

        // Functions.
    };


}

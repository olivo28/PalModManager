#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>

namespace WSDK
{
    // Super Size: 0x168
    // Size: 0x1A0 (unaligned: 0x1A0, alignment: 0x8)
    class RC_UE4SS_SDK_API USizeBox : public WSDK::UContentWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0x168
        float WidthOverride{}; // 0x178
        float HeightOverride{}; // 0x17C
        float MinDesiredWidth{}; // 0x180
        float MinDesiredHeight{}; // 0x184
        float MaxDesiredWidth{}; // 0x188
        float MaxDesiredHeight{}; // 0x18C
        float MinAspectRatio{}; // 0x190
        float MaxAspectRatio{}; // 0x194
        uint8 bOverride_WidthOverride : 1{}; // 0x198 (0x1)
        uint8 bOverride_HeightOverride : 1{}; // 0x198 (0x2)
        uint8 bOverride_MinDesiredWidth : 1{}; // 0x198 (0x4)
        uint8 bOverride_MinDesiredHeight : 1{}; // 0x198 (0x8)
        uint8 bOverride_MaxDesiredWidth : 1{}; // 0x198 (0x10)
        uint8 bOverride_MaxDesiredHeight : 1{}; // 0x198 (0x20)
        uint8 bOverride_MinAspectRatio : 1{}; // 0x198 (0x40)
        uint8 bOverride_MaxAspectRatio : 1{}; // 0x198 (0x80)
        uint8 padding_2[0x7]{}; // 0x199

        // Functions.
        void SetWidthOverride(float InWidthOverride)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetWidthOverride", 4)
            UE_COPY_PROPERTY_CUSTOM(InWidthOverride, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinDesiredWidth(float InMinDesiredWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMinDesiredWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinDesiredHeight(float InMinDesiredHeight)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMinDesiredHeight", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinDesiredHeight, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMinAspectRatio(float InMinAspectRatio)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMinAspectRatio", 4)
            UE_COPY_PROPERTY_CUSTOM(InMinAspectRatio, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxDesiredWidth(float InMaxDesiredWidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMaxDesiredWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InMaxDesiredWidth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxDesiredHeight(float InMaxDesiredHeight)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMaxDesiredHeight", 4)
            UE_COPY_PROPERTY_CUSTOM(InMaxDesiredHeight, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetMaxAspectRatio(float InMaxAspectRatio)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetMaxAspectRatio", 4)
            UE_COPY_PROPERTY_CUSTOM(InMaxAspectRatio, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHeightOverride(float InHeightOverride)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:SetHeightOverride", 4)
            UE_COPY_PROPERTY_CUSTOM(InHeightOverride, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void ClearWidthOverride()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearWidthOverride", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMinDesiredWidth()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMinDesiredWidth", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMinDesiredHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMinDesiredHeight", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMinAspectRatio()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMinAspectRatio", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMaxDesiredWidth()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMaxDesiredWidth", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMaxDesiredHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMaxDesiredHeight", 0)
            UE_CALL_FUNCTION()
        }
        void ClearMaxAspectRatio()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearMaxAspectRatio", 0)
            UE_CALL_FUNCTION()
        }
        void ClearHeightOverride()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.SizeBox:ClearHeightOverride", 0)
            UE_CALL_FUNCTION()
        }
    };


}

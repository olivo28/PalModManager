#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UWidget;
    class UWrapBoxSlot;

    // Super Size: 0x168
    // Size: 0x190 (unaligned: 0x190, alignment: 0x8)
    class RC_UE4SS_SDK_API UWrapBox : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        FVector2D InnerSlotPadding{}; // 0x168
        float WrapSize{}; // 0x178
        bool bExplicitWrapSize{}; // 0x17C
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x17D
        TEnumAsByte<EOrientation> Orientation{}; // 0x17E
        uint8 padding_1[0x11]{}; // 0x17F

        // Functions.
        void SetInnerSlotPadding(FVector2D InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBox:SetInnerSlotPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InPadding.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InPadding.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBox:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        UWrapBoxSlot* AddChildToWrapBox(UWidget* Content)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBox:AddChildToWrapBox", 16)
            UE_COPY_PROPERTY_CUSTOM(Content, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWrapBoxSlot*, 0x8)
        }
    };


}

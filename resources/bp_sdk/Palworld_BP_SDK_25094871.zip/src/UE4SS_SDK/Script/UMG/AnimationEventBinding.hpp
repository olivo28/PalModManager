#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetAnimationEvent.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidgetAnimation;

    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FAnimationEventBinding
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FAnimationEventBinding& operator=(const FAnimationEventBinding& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        UWidgetAnimation* Animation{}; // 0x0
        FScriptDelegate Delegate{}; // 0x8
        EWidgetAnimationEvent AnimationEvent{}; // 0x18
        uint8 padding_1[0x3]{}; // 0x19
        FName UserTag{}; // 0x1C
        uint8 padding_2[0x4]{}; // 0x24

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x50 (unaligned: 0x50, alignment: 0x8)
    class RC_UE4SS_SDK_API UUniformGridSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x38
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x39
        uint8 padding_1[0x2]{}; // 0x3A
        int32 Row{}; // 0x3C
        int32 Column{}; // 0x40
        uint8 padding_2[0xC]{}; // 0x44

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridSlot:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRow(int32 InRow)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridSlot:SetRow", 4)
            UE_COPY_PROPERTY_CUSTOM(InRow, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridSlot:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetColumn(int32 InColumn)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.UniformGridSlot:SetColumn", 4)
            UE_COPY_PROPERTY_CUSTOM(InColumn, int32, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

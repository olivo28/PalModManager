#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/UserWidgetExtension.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetFieldNotificationExtension : public WSDK::UUserWidgetExtension
    {
    public:
        // Properties.
        uint8 padding_1[0x18]{}; // 0x28

        // Functions.
    };


}

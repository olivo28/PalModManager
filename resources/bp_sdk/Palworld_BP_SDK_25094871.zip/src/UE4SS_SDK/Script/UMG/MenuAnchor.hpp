#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EMenuPlacement.hpp>
#include <UE4SS_SDK/Script/UMG/ContentWidget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UUserWidget;

    // Super Size: 0x168
    // Size: 0x1B8 (unaligned: 0x1B8, alignment: 0x8)
    class RC_UE4SS_SDK_API UMenuAnchor : public WSDK::UContentWidget
    {
    public:
        // Properties.
        TSubclassOf<UUserWidget> MenuClass{}; // 0x168
        FScriptDelegate OnGetMenuContentEvent{}; // 0x170
        FScriptDelegate OnGetUserMenuContentEvent{}; // 0x180
        TEnumAsByte<EMenuPlacement> Placement{}; // 0x190
        bool bFitInWindow{}; // 0x191
        bool ShouldDeferPaintingAfterWindowContent{}; // 0x192
        bool UseApplicationMenuStack{}; // 0x193
        uint8 padding_1[0x4]{}; // 0x194
        FMulticastScriptDelegate OnMenuOpenChanged{}; // 0x198
        uint8 padding_2[0x10]{}; // 0x1A8

        // Functions.
        void ToggleOpen(bool bFocusOnOpen)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:ToggleOpen", 1)
            UE_COPY_PROPERTY_CUSTOM(bFocusOnOpen, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        bool ShouldOpenDueToClick()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:ShouldOpenDueToClick", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        void SetPlacement(TEnumAsByte<EMenuPlacement> InPlacement)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:SetPlacement", 1)
            UE_COPY_PROPERTY_CUSTOM(InPlacement, TEnumAsByte<EMenuPlacement>, 0x0)
            UE_CALL_FUNCTION()
        }
        void Open(bool bFocusMenu)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:Open", 1)
            UE_COPY_PROPERTY_CUSTOM(bFocusMenu, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        bool IsOpen()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:IsOpen", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool HasOpenSubMenus()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:HasOpenSubMenus", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        UUserWidget* GetUserWidget__DelegateSignature()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:GetUserWidget__DelegateSignature", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUserWidget*, 0x0)
        }
        FVector2D GetMenuPosition()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:GetMenuPosition", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
        void FitInWindow(bool bFit)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:FitInWindow", 1)
            UE_COPY_PROPERTY_CUSTOM(bFit, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void Close()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.MenuAnchor:Close", 0)
            UE_CALL_FUNCTION()
        }
    };


}

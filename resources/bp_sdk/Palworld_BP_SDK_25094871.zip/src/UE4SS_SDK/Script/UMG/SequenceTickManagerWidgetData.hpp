#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x3 (unaligned: 0x3, alignment: 0x1)
    struct RC_UE4SS_SDK_API FSequenceTickManagerWidgetData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x3;
        }

        FSequenceTickManagerWidgetData& operator=(const FSequenceTickManagerWidgetData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x3]{}; // 0x0

        // Functions.
    };


}

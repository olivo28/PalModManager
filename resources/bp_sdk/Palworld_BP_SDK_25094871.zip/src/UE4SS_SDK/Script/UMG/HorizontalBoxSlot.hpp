#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <UE4SS_SDK/Script/UMG/SlateChildSize.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UHorizontalBoxSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x38
        FSlateChildSize Size{}; // 0x40
        FMargin Padding{}; // 0x48
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x58
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x59
        uint8 padding_2[0x6]{}; // 0x5A

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.HorizontalBoxSlot:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSize(FSlateChildSize InSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.HorizontalBoxSlot:SetSize", 8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InSize.Value, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(TEnumAsByte<ESlateSizeRule::Type>, InSize.SizeRule, 0x0, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.HorizontalBoxSlot:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.HorizontalBoxSlot:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

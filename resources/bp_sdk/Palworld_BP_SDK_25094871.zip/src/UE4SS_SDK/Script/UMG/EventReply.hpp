#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xB8 (unaligned: 0xB8, alignment: 0x8)
    struct RC_UE4SS_SDK_API alignas(0x8) FEventReply
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xB8;
        }

        FEventReply& operator=(const FEventReply& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0xB8]{}; // 0x0

        // Functions.
    };


}

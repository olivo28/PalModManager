#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/MaterialInterface.hpp>
#include <UE4SS_SDK/Script/Engine/Texture2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/SoftObjectPtr.hpp>

namespace WSDK
{
    class ISlateTextureAtlasInterface;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class UObject;
    class USlateBrushAsset;
    class UTexture2D;
    class UTexture2DDynamic;

    // Super Size: 0x150
    // Size: 0x2B0 (unaligned: 0x2B0, alignment: 0x10)
    class RC_UE4SS_SDK_API UImage : public WSDK::UWidget
    {
    public:
        // Properties.
        FSlateBrush Brush{}; // 0x150
        FScriptDelegate BrushDelegate{}; // 0x220
        FLinearColor ColorAndOpacity{}; // 0x230
        FScriptDelegate ColorAndOpacityDelegate{}; // 0x240
        bool bFlipForRightToLeftFlowDirection{}; // 0x250
        uint8 padding_1[0x3]{}; // 0x251
        FScriptDelegate OnMouseButtonDownEvent{}; // 0x254
        uint8 padding_2[0x4C]{}; // 0x264

        // Functions.
        void SetOpacity(float InOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetOpacity", 4)
            UE_COPY_PROPERTY_CUSTOM(InOpacity, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDesiredSizeOverride(FVector2D DesiredSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetDesiredSizeOverride", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, DesiredSize.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, DesiredSize.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetColorAndOpacity(FLinearColor InColorAndOpacity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetColorAndOpacity", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InColorAndOpacity.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetBrushTintColor(FSlateColor TintColor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushTintColor", 20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FLinearColor, TintColor.SpecifiedColor, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ESlateColorStylingMode, TintColor.ColorUseRule, 0x0, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetBrushResourceObject(UObject* ResourceObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushResourceObject", 8)
            UE_COPY_PROPERTY_CUSTOM(ResourceObject, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromTextureDynamic(UTexture2DDynamic* Texture, bool bMatchSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromTextureDynamic", 9)
            UE_COPY_PROPERTY_CUSTOM(Texture, UTexture2DDynamic*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bMatchSize, bool, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromTexture(UTexture2D* Texture, bool bMatchSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromTexture", 9)
            UE_COPY_PROPERTY_CUSTOM(Texture, UTexture2D*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bMatchSize, bool, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromSoftTexture(TSoftObjectPtr<UTexture2D> SoftTexture, bool bMatchSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromSoftTexture", 49)
            UE_COPY_PROPERTY_CUSTOM(SoftTexture, TSoftObjectPtr<UTexture2D>, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bMatchSize, bool, 0x30)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromSoftMaterial(TSoftObjectPtr<UMaterialInterface> SoftMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromSoftMaterial", 48)
            UE_COPY_PROPERTY_CUSTOM(SoftMaterial, TSoftObjectPtr<UMaterialInterface>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromMaterial(UMaterialInterface* Material)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(Material, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromAtlasInterface(TScriptInterface<ISlateTextureAtlasInterface> AtlasRegion, bool bMatchSize)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromAtlasInterface", 17)
            UE_COPY_PROPERTY_CUSTOM(AtlasRegion, TScriptInterface<ISlateTextureAtlasInterface>, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bMatchSize, bool, 0x10)
            UE_CALL_FUNCTION()
        }
        void SetBrushFromAsset(USlateBrushAsset* Asset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrushFromAsset", 8)
            UE_COPY_PROPERTY_CUSTOM(Asset, USlateBrushAsset*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBrush(FSlateBrush& InBrush)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:SetBrush", 208)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InBrush, FSlateBrush, 0x0)
        }
        UMaterialInstanceDynamic* GetDynamicMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Image:GetDynamicMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x78 (unaligned: 0x78, alignment: 0x8)
    class RC_UE4SS_SDK_API UGridSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        FMargin Padding{}; // 0x38
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x48
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x49
        uint8 padding_1[0x2]{}; // 0x4A
        int32 Row{}; // 0x4C
        int32 RowSpan{}; // 0x50
        int32 Column{}; // 0x54
        int32 ColumnSpan{}; // 0x58
        int32 Layer{}; // 0x5C
        FVector2D Nudge{}; // 0x60
        uint8 padding_2[0x8]{}; // 0x70

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRowSpan(int32 InRowSpan)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetRowSpan", 4)
            UE_COPY_PROPERTY_CUSTOM(InRowSpan, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetRow(int32 InRow)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetRow", 4)
            UE_COPY_PROPERTY_CUSTOM(InRow, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetNudge(FVector2D InNudge)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetNudge", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InNudge.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InNudge.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetLayer(int32 InLayer)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetLayer", 4)
            UE_COPY_PROPERTY_CUSTOM(InLayer, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetColumnSpan(int32 InColumnSpan)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetColumnSpan", 4)
            UE_COPY_PROPERTY_CUSTOM(InColumnSpan, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetColumn(int32 InColumn)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GridSlot:SetColumn", 4)
            UE_COPY_PROPERTY_CUSTOM(InColumn, int32, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

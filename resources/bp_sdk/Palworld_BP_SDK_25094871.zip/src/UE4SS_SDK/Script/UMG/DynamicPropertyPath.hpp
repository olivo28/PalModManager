#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/PropertyPath/CachedPropertyPath.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FDynamicPropertyPath : public WSDK::FCachedPropertyPath
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FDynamicPropertyPath& operator=(const FDynamicPropertyPath& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.

        // Functions.
    };


}

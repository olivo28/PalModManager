#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/EHorizontalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/EVerticalAlignment.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/UMG/PanelSlot.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    // Super Size: 0x38
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API UWrapBoxSlot : public WSDK::UPanelSlot
    {
    public:
        // Properties.
        FMargin Padding{}; // 0x38
        float FillSpanWhenLessThan{}; // 0x48
        TEnumAsByte<EHorizontalAlignment> HorizontalAlignment{}; // 0x4C
        TEnumAsByte<EVerticalAlignment> VerticalAlignment{}; // 0x4D
        bool bFillEmptySpace{}; // 0x4E
        bool bForceNewLine{}; // 0x4F
        uint8 padding_1[0x8]{}; // 0x50

        // Functions.
        void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment> InVerticalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetVerticalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InVerticalAlignment, TEnumAsByte<EVerticalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPadding(FMargin InPadding)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetPadding", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Left, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Top, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Right, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InPadding.Bottom, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetNewLine(bool InForceNewLine)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetNewLine", 1)
            UE_COPY_PROPERTY_CUSTOM(InForceNewLine, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment> InHorizontalAlignment)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetHorizontalAlignment", 1)
            UE_COPY_PROPERTY_CUSTOM(InHorizontalAlignment, TEnumAsByte<EHorizontalAlignment>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFillSpanWhenLessThan(float InFillSpanWhenLessThan)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetFillSpanWhenLessThan", 4)
            UE_COPY_PROPERTY_CUSTOM(InFillSpanWhenLessThan, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFillEmptySpace(bool InbFillEmptySpace)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WrapBoxSlot:SetFillEmptySpace", 1)
            UE_COPY_PROPERTY_CUSTOM(InbFillEmptySpace, bool, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

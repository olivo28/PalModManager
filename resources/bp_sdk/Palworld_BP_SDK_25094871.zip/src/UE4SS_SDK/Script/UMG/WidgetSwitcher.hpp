#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PanelWidget.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x168
    // Size: 0x180 (unaligned: 0x180, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetSwitcher : public WSDK::UPanelWidget
    {
    public:
        // Properties.
        int32 ActiveWidgetIndex{}; // 0x168
        uint8 padding_1[0x14]{}; // 0x16C

        // Functions.
        void SetActiveWidgetIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:SetActiveWidgetIndex", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetActiveWidget(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:SetActiveWidget", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        UWidget* GetWidgetAtIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:GetWidgetAtIndex", 16)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x8)
        }
        int32 GetNumWidgets()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:GetNumWidgets", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        int32 GetActiveWidgetIndex()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:GetActiveWidgetIndex", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        UWidget* GetActiveWidget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetSwitcher:GetActiveWidget", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidget*, 0x0)
        }
    };


}

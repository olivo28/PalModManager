#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieSceneTracks/MovieScenePropertySystem.hpp>

namespace WSDK
{
    // Super Size: 0x58
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieScene2DTransformPropertySystem : public WSDK::UMovieScenePropertySystem
    {
    public:
        // Properties.

        // Functions.
    };


}

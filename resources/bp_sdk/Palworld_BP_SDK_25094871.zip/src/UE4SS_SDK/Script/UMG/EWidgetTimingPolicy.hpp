#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetTimingPolicy : uint8
    {
        RealTime,
        GameTime,
    };
}

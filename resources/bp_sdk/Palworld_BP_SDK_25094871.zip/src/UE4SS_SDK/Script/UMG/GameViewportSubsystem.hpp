#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/GameInstanceSubsystem.hpp>
#include <UE4SS_SDK/Script/UMG/GameViewportWidgetSlot.hpp>

namespace WSDK
{
    class ULocalPlayer;
    class UWidget;

    // Super Size: 0x30
    // Size: 0x80 (unaligned: 0x80, alignment: 0x8)
    class RC_UE4SS_SDK_API UGameViewportSubsystem : public WSDK::UGameInstanceSubsystem
    {
    public:
        // Properties.
        uint8 padding_1[0x50]{}; // 0x30

        // Functions.
        static FGameViewportWidgetSlot SetWidgetSlotPosition(FGameViewportWidgetSlot Slot, UWidget* Widget, FVector2D Position, bool bRemoveDPIScale)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:SetWidgetSlotPosition", 176)
            UE_SET_STATIC_SELF("/Script/UMG.Default__GameViewportSubsystem")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FAnchors, Slot.Anchors, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, Slot.Offsets, 0x0, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Slot.Alignment, 0x0, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, Slot.ZOrder, 0x0, 0x40)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x48)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.X, 0x50, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Position.Y, 0x50, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bRemoveDPIScale, bool, 0x60)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGameViewportWidgetSlot, 0x68)
        }
        static FGameViewportWidgetSlot SetWidgetSlotDesiredSize(FGameViewportWidgetSlot Slot, FVector2D Size)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:SetWidgetSlotDesiredSize", 160)
            UE_SET_STATIC_SELF("/Script/UMG.Default__GameViewportSubsystem")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FAnchors, Slot.Anchors, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, Slot.Offsets, 0x0, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Slot.Alignment, 0x0, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, Slot.ZOrder, 0x0, 0x40)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.X, 0x48, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, Size.Y, 0x48, 0x8)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGameViewportWidgetSlot, 0x58)
        }
        void SetWidgetSlot(UWidget* Widget, FGameViewportWidgetSlot Slot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:SetWidgetSlot", 80)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FAnchors, Slot.Anchors, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, Slot.Offsets, 0x8, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Slot.Alignment, 0x8, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, Slot.ZOrder, 0x8, 0x40)
            UE_CALL_FUNCTION()
        }
        void RemoveWidget(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:RemoveWidget", 8)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        bool IsWidgetAdded(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:IsWidgetAdded", 9)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        FGameViewportWidgetSlot GetWidgetSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:GetWidgetSlot", 80)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGameViewportWidgetSlot, 0x8)
        }
        void AddWidgetForPlayer(UWidget* Widget, ULocalPlayer* Player, FGameViewportWidgetSlot Slot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:AddWidgetForPlayer", 88)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Player, ULocalPlayer*, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FAnchors, Slot.Anchors, 0x10, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, Slot.Offsets, 0x10, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Slot.Alignment, 0x10, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, Slot.ZOrder, 0x10, 0x40)
            UE_CALL_FUNCTION()
        }
        void AddWidget(UWidget* Widget, FGameViewportWidgetSlot Slot)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.GameViewportSubsystem:AddWidget", 80)
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FAnchors, Slot.Anchors, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMargin, Slot.Offsets, 0x8, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FVector2D, Slot.Alignment, 0x8, 0x30)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, Slot.ZOrder, 0x8, 0x40)
            UE_CALL_FUNCTION()
        }
    };


}

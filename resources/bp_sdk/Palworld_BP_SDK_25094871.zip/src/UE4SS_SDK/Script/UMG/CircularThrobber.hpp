#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x250 (unaligned: 0x250, alignment: 0x10)
    class RC_UE4SS_SDK_API UCircularThrobber : public WSDK::UWidget
    {
    public:
        // Properties.
        int32 NumberOfPieces{}; // 0x150
        float Period{}; // 0x154
        float Radius{}; // 0x158
        uint8 padding_1[0x4]{}; // 0x15C
        FSlateBrush Image{}; // 0x160
        bool bEnableRadius{}; // 0x230
        uint8 padding_2[0x1F]{}; // 0x231

        // Functions.
        void SetRadius(float InRadius)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CircularThrobber:SetRadius", 4)
            UE_COPY_PROPERTY_CUSTOM(InRadius, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPeriod(float InPeriod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CircularThrobber:SetPeriod", 4)
            UE_COPY_PROPERTY_CUSTOM(InPeriod, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetNumberOfPieces(int32 InNumberOfPieces)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.CircularThrobber:SetNumberOfPieces", 4)
            UE_COPY_PROPERTY_CUSTOM(InNumberOfPieces, int32, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/EEndPlayReason.hpp>
#include <UE4SS_SDK/Script/Slate/ESelectionMode.hpp>
#include <UE4SS_SDK/Script/SlateCore/EConsumeMouseWheel.hpp>
#include <UE4SS_SDK/Script/SlateCore/EOrientation.hpp>
#include <UE4SS_SDK/Script/SlateCore/ScrollBarStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/TableViewStyle.hpp>
#include <UE4SS_SDK/Script/UMG/ListViewBase.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class AActor;
    class UObject;

    // Super Size: 0x268
    // Size: 0xC20 (unaligned: 0xC20, alignment: 0x10)
    class RC_UE4SS_SDK_API UListView : public WSDK::UListViewBase
    {
    public:
        // Properties.
        uint8 padding_1[0xD8]{}; // 0x268
        FTableViewStyle WidgetStyle{}; // 0x340
        FScrollBarStyle ScrollBarStyle{}; // 0x420
        TEnumAsByte<EOrientation> Orientation{}; // 0xB90
        TEnumAsByte<ESelectionMode::Type> SelectionMode{}; // 0xB91
        EConsumeMouseWheel ConsumeMouseWheel{}; // 0xB92
        bool bClearSelectionOnClick{}; // 0xB93
        bool bIsFocusable{}; // 0xB94
        uint8 padding_2[0x3]{}; // 0xB95
        float EntrySpacing{}; // 0xB98
        bool bReturnFocusToSelection{}; // 0xB9C
        uint8 padding_3[0x3]{}; // 0xB9D
        TArray<UObject*> ListItems{}; // 0xBA0
        uint8 padding_4[0x10]{}; // 0xBB0
        FMulticastScriptDelegate BP_OnEntryInitialized{}; // 0xBC0
        FMulticastScriptDelegate BP_OnItemClicked{}; // 0xBD0
        FMulticastScriptDelegate BP_OnItemDoubleClicked{}; // 0xBE0
        FMulticastScriptDelegate BP_OnItemIsHoveredChanged{}; // 0xBF0
        FMulticastScriptDelegate BP_OnItemSelectionChanged{}; // 0xC00
        FMulticastScriptDelegate BP_OnItemScrolledIntoView{}; // 0xC10

        // Functions.
        void SetSelectionMode(TEnumAsByte<ESelectionMode::Type> SelectionMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:SetSelectionMode", 1)
            UE_COPY_PROPERTY_CUSTOM(SelectionMode, TEnumAsByte<ESelectionMode::Type>, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSelectedIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:SetSelectedIndex", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void ScrollIndexIntoView(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:ScrollIndexIntoView", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void RemoveItem(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:RemoveItem", 8)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnListItemOuterEndPlayed(AActor* ItemOuter, TEnumAsByte<EEndPlayReason::Type> EndPlayReason)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:OnListItemOuterEndPlayed", 9)
            UE_COPY_PROPERTY_CUSTOM(ItemOuter, AActor*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(EndPlayReason, TEnumAsByte<EEndPlayReason::Type>, 0x8)
            UE_CALL_FUNCTION()
        }
        void OnListItemEndPlayed(AActor* Item, TEnumAsByte<EEndPlayReason::Type> EndPlayReason)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:OnListItemEndPlayed", 9)
            UE_COPY_PROPERTY_CUSTOM(Item, AActor*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(EndPlayReason, TEnumAsByte<EEndPlayReason::Type>, 0x8)
            UE_CALL_FUNCTION()
        }
        void NavigateToIndex(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:NavigateToIndex", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        bool IsRefreshPending()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:IsRefreshPending", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        int32 GetNumItems()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:GetNumItems", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        TArray<UObject*> GetListItems()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:GetListItems", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UObject*>, 0x0)
        }
        UObject* GetItemAt(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:GetItemAt", 16)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x8)
        }
        int32 GetIndexForItem(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:GetIndexForItem", 12)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x8)
        }
        void ClearListItems()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:ClearListItems", 0)
            UE_CALL_FUNCTION()
        }
        void BP_SetSelectedItem(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_SetSelectedItem", 8)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
        void BP_SetListItems(TArray<UObject*>& InListItems)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_SetListItems", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InListItems, TArray<UObject*>, 0x0)
        }
        void BP_SetItemSelection(UObject* Item, bool bSelected)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_SetItemSelection", 9)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bSelected, bool, 0x8)
            UE_CALL_FUNCTION()
        }
        void BP_ScrollItemIntoView(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_ScrollItemIntoView", 8)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
        void BP_NavigateToItem(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_NavigateToItem", 8)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
        bool BP_IsItemVisible(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_IsItemVisible", 9)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool BP_GetSelectedItems(TArray<UObject*>& Items)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_GetSelectedItems", 17)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Items, TArray<UObject*>, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        UObject* BP_GetSelectedItem()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_GetSelectedItem", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x0)
        }
        int32 BP_GetNumItemsSelected()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_GetNumItemsSelected", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        void BP_ClearSelection()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_ClearSelection", 0)
            UE_CALL_FUNCTION()
        }
        void BP_CancelScrollIntoView()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:BP_CancelScrollIntoView", 0)
            UE_CALL_FUNCTION()
        }
        void AddItem(UObject* Item)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListView:AddItem", 8)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

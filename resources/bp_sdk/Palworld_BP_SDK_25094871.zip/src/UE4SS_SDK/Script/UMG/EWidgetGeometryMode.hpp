#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWidgetGeometryMode : uint8
    {
        Plane,
        Cylinder,
    };
}

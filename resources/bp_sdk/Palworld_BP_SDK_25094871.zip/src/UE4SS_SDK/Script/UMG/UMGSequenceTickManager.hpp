#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UMG/SequenceTickManagerWidgetData.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/FWeakObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMovieSceneEntitySystemLinker;
    class UUserWidget;

    // Super Size: 0x28
    // Size: 0xC0 (unaligned: 0xC0, alignment: 0x8)
    class RC_UE4SS_SDK_API UUMGSequenceTickManager : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TMap<TWeakObjectPtr<UUserWidget>, FSequenceTickManagerWidgetData> WeakUserWidgetData{}; // 0x28
        UMovieSceneEntitySystemLinker* Linker{}; // 0x78
        uint8 padding_1[0x40]{}; // 0x80

        // Functions.
    };


}

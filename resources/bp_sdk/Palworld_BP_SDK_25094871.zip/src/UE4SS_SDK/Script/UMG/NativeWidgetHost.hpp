#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x160 (unaligned: 0x160, alignment: 0x8)
    class RC_UE4SS_SDK_API UNativeWidgetHost : public WSDK::UWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0x150

        // Functions.
    };


}

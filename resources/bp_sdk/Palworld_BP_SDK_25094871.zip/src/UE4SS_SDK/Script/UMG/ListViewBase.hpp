#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ESlateVisibility.hpp>
#include <UE4SS_SDK/Script/UMG/UserWidgetPool.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UUserWidget;

    // Super Size: 0x150
    // Size: 0x268 (unaligned: 0x268, alignment: 0x8)
    class RC_UE4SS_SDK_API UListViewBase : public WSDK::UWidget
    {
    public:
        // Properties.
        FMulticastScriptDelegate BP_OnEntryGenerated{}; // 0x150
        uint8 padding_1[0x10]{}; // 0x160
        TSubclassOf<UUserWidget> EntryWidgetClass{}; // 0x170
        float WheelScrollMultiplier{}; // 0x178
        bool bEnableScrollAnimation{}; // 0x17C
        bool AllowOverscroll{}; // 0x17D
        bool bEnableRightClickScrolling{}; // 0x17E
        bool bEnableFixedLineOffset{}; // 0x17F
        float FixedLineScrollOffset{}; // 0x180
        bool bAllowDragging{}; // 0x184
        uint8 padding_2[0x3]{}; // 0x185
        FMulticastScriptDelegate BP_OnEntryReleased{}; // 0x188
        FUserWidgetPool EntryWidgetPool{}; // 0x198
        uint8 padding_3[0x48]{}; // 0x220

        // Functions.
        void SetWheelScrollMultiplier(float NewWheelScrollMultiplier)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:SetWheelScrollMultiplier", 4)
            UE_COPY_PROPERTY_CUSTOM(NewWheelScrollMultiplier, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollOffset(float InScrollOffset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:SetScrollOffset", 4)
            UE_COPY_PROPERTY_CUSTOM(InScrollOffset, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrollBarVisibility(ESlateVisibility InVisibility)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:SetScrollBarVisibility", 1)
            UE_COPY_PROPERTY_CUSTOM(InVisibility, ESlateVisibility, 0x0)
            UE_CALL_FUNCTION()
        }
        void ScrollToTop()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:ScrollToTop", 0)
            UE_CALL_FUNCTION()
        }
        void ScrollToBottom()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:ScrollToBottom", 0)
            UE_CALL_FUNCTION()
        }
        void RequestRefresh()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:RequestRefresh", 0)
            UE_CALL_FUNCTION()
        }
        void RegenerateAllEntries()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:RegenerateAllEntries", 0)
            UE_CALL_FUNCTION()
        }
        float GetScrollOffset()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:GetScrollOffset", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        TArray<UUserWidget*> GetDisplayedEntryWidgets()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ListViewBase:GetDisplayedEntryWidgets", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UUserWidget*>, 0x0)
        }
    };


}

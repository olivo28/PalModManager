#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESlateAccessibleBehavior : uint8
    {
        NotAccessible,
        Auto,
        Summary,
        Custom,
        ToolTip,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ExpandableAreaStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateColor.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x150
    // Size: 0x460 (unaligned: 0x460, alignment: 0x10)
    class RC_UE4SS_SDK_API UExpandableArea : public WSDK::UWidget
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0x150
        FExpandableAreaStyle Style{}; // 0x160
        FSlateBrush BorderBrush{}; // 0x320
        FSlateColor BorderColor{}; // 0x3F0
        bool bIsExpanded{}; // 0x404
        uint8 padding_2[0x3]{}; // 0x405
        float maxHeight{}; // 0x408
        FMargin HeaderPadding{}; // 0x40C
        FMargin AreaPadding{}; // 0x41C
        uint8 padding_3[0x4]{}; // 0x42C
        FMulticastScriptDelegate OnExpansionChanged{}; // 0x430
        UWidget* HeaderContent{}; // 0x440
        UWidget* BodyContent{}; // 0x448
        uint8 padding_4[0x10]{}; // 0x450

        // Functions.
        void SetIsExpanded_Animated(bool IsExpanded)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ExpandableArea:SetIsExpanded_Animated", 1)
            UE_COPY_PROPERTY_CUSTOM(IsExpanded, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIsExpanded(bool IsExpanded)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ExpandableArea:SetIsExpanded", 1)
            UE_COPY_PROPERTY_CUSTOM(IsExpanded, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        bool GetIsExpanded()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.ExpandableArea:GetIsExpanded", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

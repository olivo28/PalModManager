#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/PropertyBinding.hpp>

namespace WSDK
{
    // Super Size: 0x60
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UInt32Binding : public WSDK::UPropertyBinding
    {
    public:
        // Properties.

        // Functions.
        int32 GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.Int32Binding:GetValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
    };


}

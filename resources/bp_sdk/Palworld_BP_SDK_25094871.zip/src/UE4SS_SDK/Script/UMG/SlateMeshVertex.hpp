#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Color.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2f.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x3C (unaligned: 0x3C, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSlateMeshVertex
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x3C;
        }

        FSlateMeshVertex& operator=(const FSlateMeshVertex& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FVector2f Position{}; // 0x0
        FColor Color{}; // 0x8
        FVector2f UV0{}; // 0xC
        FVector2f UV1{}; // 0x14
        FVector2f UV2{}; // 0x1C
        FVector2f UV3{}; // 0x24
        FVector2f UV4{}; // 0x2C
        FVector2f UV5{}; // 0x34

        // Functions.
    };


}

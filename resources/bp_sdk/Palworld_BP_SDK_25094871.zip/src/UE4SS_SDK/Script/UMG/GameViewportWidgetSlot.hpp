#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Slate/Anchors.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    struct RC_UE4SS_SDK_API FGameViewportWidgetSlot
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x48;
        }

        FGameViewportWidgetSlot& operator=(const FGameViewportWidgetSlot& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FAnchors Anchors{}; // 0x0
        FMargin Offsets{}; // 0x20
        FVector2D Alignment{}; // 0x30
        int32 ZOrder{}; // 0x40
        uint8 padding_1[0x4]{}; // 0x44

        // Functions.
    };


}

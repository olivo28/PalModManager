#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TableRowBase.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0xE0 (unaligned: 0xE0, alignment: 0x10)
    struct RC_UE4SS_SDK_API FRichImageRow : public WSDK::FTableRowBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xE0;
        }

        FRichImageRow& operator=(const FRichImageRow& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FSlateBrush Brush{}; // 0x10

        // Functions.
    };


}

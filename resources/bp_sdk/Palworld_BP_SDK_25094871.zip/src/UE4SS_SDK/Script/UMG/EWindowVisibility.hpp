#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWindowVisibility : uint8
    {
        Visible,
        SelfHitTestInvisible,
    };
}

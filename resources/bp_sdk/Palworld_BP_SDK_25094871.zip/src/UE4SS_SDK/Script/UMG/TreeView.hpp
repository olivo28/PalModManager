#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/ListView.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0xC20
    // Size: 0xC80 (unaligned: 0xC80, alignment: 0x10)
    class RC_UE4SS_SDK_API UTreeView : public WSDK::UListView
    {
    public:
        // Properties.
        uint8 padding_1[0x10]{}; // 0xC20
        FScriptDelegate BP_OnGetItemChildren{}; // 0xC30
        FMulticastScriptDelegate BP_OnItemExpansionChanged{}; // 0xC40
        uint8 padding_2[0x30]{}; // 0xC50

        // Functions.
        void SetItemExpansion(UObject* Item, bool bExpandItem)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TreeView:SetItemExpansion", 9)
            UE_COPY_PROPERTY_CUSTOM(Item, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bExpandItem, bool, 0x8)
            UE_CALL_FUNCTION()
        }
        void ExpandAll()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TreeView:ExpandAll", 0)
            UE_CALL_FUNCTION()
        }
        void CollapseAll()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.TreeView:CollapseAll", 0)
            UE_CALL_FUNCTION()
        }
    };


}

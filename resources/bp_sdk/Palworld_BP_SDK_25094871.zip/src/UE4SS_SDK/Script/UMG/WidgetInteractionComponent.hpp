#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/ECollisionChannel.hpp>
#include <UE4SS_SDK/Script/Engine/HitResult.hpp>
#include <UE4SS_SDK/Script/Engine/SceneComponent.hpp>
#include <UE4SS_SDK/Script/InputCore/Key.hpp>
#include <UE4SS_SDK/Script/UMG/EWidgetInteractionSource.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UWidget;
    class UWidgetComponent;

    // Super Size: 0x2A0
    // Size: 0x570 (unaligned: 0x570, alignment: 0x10)
    class RC_UE4SS_SDK_API UWidgetInteractionComponent : public WSDK::USceneComponent
    {
    public:
        // Properties.
        FMulticastScriptDelegate OnHoveredWidgetChanged{}; // 0x2A0
        uint8 padding_1[0x10]{}; // 0x2B0
        int32 VirtualUserIndex{}; // 0x2C0
        int32 PointerIndex{}; // 0x2C4
        TEnumAsByte<ECollisionChannel> TraceChannel{}; // 0x2C8
        uint8 padding_2[0x3]{}; // 0x2C9
        float InteractionDistance{}; // 0x2CC
        EWidgetInteractionSource InteractionSource{}; // 0x2D0
        bool bEnableHitTesting{}; // 0x2D1
        bool bShowDebug{}; // 0x2D2
        uint8 padding_3[0x1]{}; // 0x2D3
        float DebugSphereLineThickness{}; // 0x2D4
        float DebugLineThickness{}; // 0x2D8
        FLinearColor DebugColor{}; // 0x2DC
        uint8 padding_4[0x7C]{}; // 0x2EC
        FHitResult CustomHitResult{}; // 0x368
        FVector2D LocalHitLocation{}; // 0x450
        FVector2D LastLocalHitLocation{}; // 0x460
        UWidgetComponent* HoveredWidgetComponent{}; // 0x470
        FHitResult LastHitResult{}; // 0x478
        bool bIsHoveredWidgetInteractable{}; // 0x560
        bool bIsHoveredWidgetFocusable{}; // 0x561
        bool bIsHoveredWidgetHitTestVisible{}; // 0x562
        uint8 padding_5[0xD]{}; // 0x563

        // Functions.
        void SetFocus(UWidget* FocusWidget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:SetFocus", 8)
            UE_COPY_PROPERTY_CUSTOM(FocusWidget, UWidget*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetCustomHitResult(FHitResult& HitResult)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:SetCustomHitResult", 232)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(HitResult, FHitResult, 0x0)
        }
        bool SendKeyChar(FString& Characters, bool bRepeat)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:SendKeyChar", 18)
            UE_COPY_PROPERTY_CUSTOM(Characters, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bRepeat, bool, 0x10)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x11)
        }
        void ScrollWheel(float ScrollDelta)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:ScrollWheel", 4)
            UE_COPY_PROPERTY_CUSTOM(ScrollDelta, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void ReleasePointerKey(FKey Key)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:ReleasePointerKey", 24)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Key.KeyName, 0x0, 0x0)
            UE_CALL_FUNCTION()
        }
        bool ReleaseKey(FKey Key)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:ReleaseKey", 25)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Key.KeyName, 0x0, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        void PressPointerKey(FKey Key)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:PressPointerKey", 24)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Key.KeyName, 0x0, 0x0)
            UE_CALL_FUNCTION()
        }
        bool PressKey(FKey Key, bool bRepeat)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:PressKey", 26)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Key.KeyName, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bRepeat, bool, 0x18)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x19)
        }
        bool PressAndReleaseKey(FKey Key)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:PressAndReleaseKey", 25)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Key.KeyName, 0x0, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        bool IsOverInteractableWidget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:IsOverInteractableWidget", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsOverHitTestVisibleWidget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:IsOverHitTestVisibleWidget", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsOverFocusableWidget()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:IsOverFocusableWidget", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FHitResult GetLastHitResult()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:GetLastHitResult", 232)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FHitResult, 0x0)
        }
        UWidgetComponent* GetHoveredWidgetComponent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:GetHoveredWidgetComponent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidgetComponent*, 0x0)
        }
        FVector2D Get2DHitLocation()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetInteractionComponent:Get2DHitLocation", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
    };


}

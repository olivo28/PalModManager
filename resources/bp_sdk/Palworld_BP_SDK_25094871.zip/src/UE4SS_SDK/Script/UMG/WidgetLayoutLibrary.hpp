#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/SlateCore/Geometry.hpp>

namespace WSDK
{
    class APlayerController;
    class UBorderSlot;
    class UCanvasPanelSlot;
    class UGridSlot;
    class UHorizontalBoxSlot;
    class UObject;
    class UOverlaySlot;
    class USafeZoneSlot;
    class UScaleBoxSlot;
    class UScrollBoxSlot;
    class USizeBoxSlot;
    class UUniformGridSlot;
    class UVerticalBoxSlot;
    class UWidget;
    class UWidgetSwitcherSlot;
    class UWrapBoxSlot;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWidgetLayoutLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static UWrapBoxSlot* SlotAsWrapBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsWrapBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWrapBoxSlot*, 0x8)
        }
        static UWidgetSwitcherSlot* SlotAsWidgetSwitcherSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsWidgetSwitcherSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWidgetSwitcherSlot*, 0x8)
        }
        static UVerticalBoxSlot* SlotAsVerticalBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsVerticalBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVerticalBoxSlot*, 0x8)
        }
        static UUniformGridSlot* SlotAsUniformGridSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsUniformGridSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UUniformGridSlot*, 0x8)
        }
        static USizeBoxSlot* SlotAsSizeBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsSizeBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(USizeBoxSlot*, 0x8)
        }
        static UScrollBoxSlot* SlotAsScrollBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsScrollBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UScrollBoxSlot*, 0x8)
        }
        static UScaleBoxSlot* SlotAsScaleBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsScaleBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UScaleBoxSlot*, 0x8)
        }
        static USafeZoneSlot* SlotAsSafeBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsSafeBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(USafeZoneSlot*, 0x8)
        }
        static UOverlaySlot* SlotAsOverlaySlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsOverlaySlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UOverlaySlot*, 0x8)
        }
        static UHorizontalBoxSlot* SlotAsHorizontalBoxSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsHorizontalBoxSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UHorizontalBoxSlot*, 0x8)
        }
        static UGridSlot* SlotAsGridSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsGridSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UGridSlot*, 0x8)
        }
        static UCanvasPanelSlot* SlotAsCanvasSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsCanvasSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UCanvasPanelSlot*, 0x8)
        }
        static UBorderSlot* SlotAsBorderSlot(UWidget* Widget)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:SlotAsBorderSlot", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Widget, UWidget*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UBorderSlot*, 0x8)
        }
        static void RemoveAllWidgets(UObject* WorldContextObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:RemoveAllWidgets", 8)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static bool ProjectWorldLocationToWidgetPosition(APlayerController* PlayerController, FVector WorldLocation, FVector2D& ScreenPosition, bool bPlayerViewportRelative)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:ProjectWorldLocationToWidgetPosition", 50)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_COPY_VECTOR(WorldLocation, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bPlayerViewportRelative, bool, 0x30)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ScreenPosition, FVector2D, 0x20)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x31)
        }
        static FGeometry GetViewportWidgetGeometry(UObject* WorldContextObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetViewportWidgetGeometry", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGeometry, 0x8)
        }
        static FVector2D GetViewportSize(UObject* WorldContextObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetViewportSize", 24)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x8)
        }
        static float GetViewportScale(UObject* WorldContextObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetViewportScale", 12)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x8)
        }
        static FGeometry GetPlayerScreenWidgetGeometry(APlayerController* PlayerController)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetPlayerScreenWidgetGeometry", 72)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(PlayerController, APlayerController*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FGeometry, 0x8)
        }
        static bool GetMousePositionScaledByDPI(APlayerController* Player, float& LocationX, float& LocationY)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetMousePositionScaledByDPI", 17)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(Player, APlayerController*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(LocationX, float, 0x8)
            UE_COPY_OUT_PROPERTY_CUSTOM(LocationY, float, 0xC)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static FVector2D GetMousePositionOnViewport(UObject* WorldContextObject)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetMousePositionOnViewport", 24)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x8)
        }
        static FVector2D GetMousePositionOnPlatform()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/UMG.WidgetLayoutLibrary:GetMousePositionOnPlatform", 16)
            UE_SET_STATIC_SELF("/Script/UMG.Default__WidgetLayoutLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
    };


}

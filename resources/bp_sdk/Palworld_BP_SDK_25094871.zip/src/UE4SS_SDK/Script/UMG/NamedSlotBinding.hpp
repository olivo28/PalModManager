#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWidget;

    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x8)
    struct RC_UE4SS_SDK_API FNamedSlotBinding
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FNamedSlotBinding& operator=(const FNamedSlotBinding& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FName Name{}; // 0x0
        UWidget* Content{}; // 0x8

        // Functions.
    };


}

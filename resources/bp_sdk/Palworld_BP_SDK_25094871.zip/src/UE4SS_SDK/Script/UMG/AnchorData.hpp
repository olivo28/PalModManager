#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Slate/Anchors.hpp>
#include <UE4SS_SDK/Script/SlateCore/Margin.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    struct RC_UE4SS_SDK_API FAnchorData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x40;
        }

        FAnchorData& operator=(const FAnchorData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FMargin Offsets{}; // 0x0
        FAnchors Anchors{}; // 0x10
        FVector2D Alignment{}; // 0x30

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneFloatChannel.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSection.hpp>

namespace WSDK
{
    // Super Size: 0xF0
    // Size: 0x538 (unaligned: 0x538, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieSceneMarginSection : public WSDK::UMovieSceneSection
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0xF0
        FMovieSceneFloatChannel TopCurve{}; // 0xF8
        FMovieSceneFloatChannel LeftCurve{}; // 0x208
        FMovieSceneFloatChannel RightCurve{}; // 0x318
        FMovieSceneFloatChannel BottomCurve{}; // 0x428

        // Functions.
    };


}

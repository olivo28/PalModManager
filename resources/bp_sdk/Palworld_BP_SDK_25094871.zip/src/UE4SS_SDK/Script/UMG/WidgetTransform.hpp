#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWidgetTransform
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x38;
        }

        FWidgetTransform& operator=(const FWidgetTransform& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FVector2D Translation{}; // 0x0
        FVector2D Scale{}; // 0x10
        FVector2D Shear{}; // 0x20
        float Angle{}; // 0x30
        uint8 padding_1[0x4]{}; // 0x34

        // Functions.
    };


}

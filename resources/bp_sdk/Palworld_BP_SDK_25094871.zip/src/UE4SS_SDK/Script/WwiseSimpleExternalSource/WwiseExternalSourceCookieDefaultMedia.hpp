#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TableRowBase.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseExternalSourceCookieDefaultMedia : public WSDK::FTableRowBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x38;
        }

        FWwiseExternalSourceCookieDefaultMedia& operator=(const FWwiseExternalSourceCookieDefaultMedia& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 ExternalSourceCookie{}; // 0x8
        uint8 padding_1[0x4]{}; // 0xC
        FString ExternalSourceName{}; // 0x10
        int32 MediaInfoId{}; // 0x20
        uint8 padding_2[0x4]{}; // 0x24
        FString MediaName{}; // 0x28

        // Functions.
    };


}

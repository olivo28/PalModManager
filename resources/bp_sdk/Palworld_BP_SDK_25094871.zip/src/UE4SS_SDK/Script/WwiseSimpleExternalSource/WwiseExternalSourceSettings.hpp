#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/DirectoryPath.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/SoftObjectPath.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x90 (unaligned: 0x90, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseExternalSourceSettings : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FSoftObjectPath MediaInfoTable{}; // 0x28
        FSoftObjectPath ExternalSourceDefaultMedia{}; // 0x48
        FDirectoryPath ExternalSourceStagingDirectory{}; // 0x68
        uint8 padding_1[0x18]{}; // 0x78

        // Functions.
    };


}

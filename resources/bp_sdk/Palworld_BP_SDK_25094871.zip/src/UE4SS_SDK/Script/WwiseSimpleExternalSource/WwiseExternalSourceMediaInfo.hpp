#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TableRowBase.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseExternalSourceMediaInfo : public WSDK::FTableRowBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FWwiseExternalSourceMediaInfo& operator=(const FWwiseExternalSourceMediaInfo& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 ExternalSourceMediaInfoId{}; // 0x8
        FName MediaName{}; // 0xC
        int32 CodecID{}; // 0x14
        bool bIsStreamed{}; // 0x18
        bool bUseDeviceMemory{}; // 0x19
        uint8 padding_1[0x2]{}; // 0x1A
        int32 MemoryAlignment{}; // 0x1C
        int32 PrefetchSize{}; // 0x20
        uint8 padding_2[0x4]{}; // 0x24

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API alignas(0x8) FChunkedStructBuffer
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FChunkedStructBuffer& operator=(const FChunkedStructBuffer& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x20]{}; // 0x0

        // Functions.
    };


}

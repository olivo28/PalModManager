#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EPropertyBagPropertyType : uint8
    {
        None,
        Bool,
        Byte,
        Int32,
        Int64,
        Float,
        Double,
        Name,
        String,
        Text,
        Enum,
        Struct,
        Object,
        SoftObject,
        Class,
        SoftClass,
    };
}

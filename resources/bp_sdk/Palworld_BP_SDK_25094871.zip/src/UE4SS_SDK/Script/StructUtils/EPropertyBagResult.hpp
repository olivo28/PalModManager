#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EPropertyBagResult
    {
        Success,
        TypeMismatch,
        OutOfBounds,
        PropertyNotFound,
    };
}

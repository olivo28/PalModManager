#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x4 (unaligned: 0x4, alignment: 0x4)
    struct RC_UE4SS_SDK_API FAkUInt32Wrapper
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x4;
        }

        FAkUInt32Wrapper& operator=(const FAkUInt32Wrapper& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint32 UInt32Value{}; // 0x0

        // Functions.
    };


}

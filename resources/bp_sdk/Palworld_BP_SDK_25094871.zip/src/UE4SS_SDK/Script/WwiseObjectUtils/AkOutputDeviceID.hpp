#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseObjectUtils/AkUInt64Wrapper.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x8 (unaligned: 0x8, alignment: 0x8)
    struct RC_UE4SS_SDK_API FAkOutputDeviceID : public WSDK::FAkUInt64Wrapper
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FAkOutputDeviceID& operator=(const FAkOutputDeviceID& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x8)
    struct RC_UE4SS_SDK_API FAkUInt64Wrapper
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FAkUInt64Wrapper& operator=(const FAkUInt64Wrapper& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint64 UInt64Value{}; // 0x0

        // Functions.
    };


}

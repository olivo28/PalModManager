#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseObjectUtils/AkUInt32Wrapper.hpp>

namespace WSDK
{
    // Super Size: 0x4
    // Size: 0x4 (unaligned: 0x4, alignment: 0x4)
    struct RC_UE4SS_SDK_API FAkUniqueID : public WSDK::FAkUInt32Wrapper
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x4;
        }

        FAkUniqueID& operator=(const FAkUniqueID& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.

        // Functions.
    };


}

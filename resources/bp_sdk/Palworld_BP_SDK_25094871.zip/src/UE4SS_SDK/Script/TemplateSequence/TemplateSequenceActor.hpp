#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/SoftObjectPath.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSequencePlaybackSettings.hpp>
#include <UE4SS_SDK/Script/TemplateSequence/TemplateSequenceBindingOverrideData.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AActor;
    class UTemplateSequence;
    class UTemplateSequencePlayer;

    // Super Size: 0x290
    // Size: 0x2F0 (unaligned: 0x2F0, alignment: 0x8)
    class RC_UE4SS_SDK_API ATemplateSequenceActor : public WSDK::AActor
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x290
        FMovieSceneSequencePlaybackSettings PlaybackSettings{}; // 0x298
        UTemplateSequencePlayer* SequencePlayer{}; // 0x2B8
        FSoftObjectPath TemplateSequence{}; // 0x2C0
        FTemplateSequenceBindingOverrideData BindingOverride{}; // 0x2E0
        uint8 padding_2[0x4]{}; // 0x2EC

        // Functions.
        void SetSequence(UTemplateSequence* InSequence)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequenceActor:SetSequence", 8)
            UE_COPY_PROPERTY_CUSTOM(InSequence, UTemplateSequence*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBinding(AActor* Actor, bool bOverridesDefault)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequenceActor:SetBinding", 9)
            UE_COPY_PROPERTY_CUSTOM(Actor, AActor*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bOverridesDefault, bool, 0x8)
            UE_CALL_FUNCTION()
        }
        UTemplateSequence* LoadSequence()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequenceActor:LoadSequence", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTemplateSequence*, 0x0)
        }
        UTemplateSequencePlayer* GetSequencePlayer()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequenceActor:GetSequencePlayer", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTemplateSequencePlayer*, 0x0)
        }
        UTemplateSequence* GetSequence()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequenceActor:GetSequence", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTemplateSequence*, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSubTrack.hpp>

namespace WSDK
{
    // Super Size: 0xA8
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API UTemplateSequenceTrack : public WSDK::UMovieSceneSubTrack
    {
    public:
        // Properties.

        // Functions.
    };


}

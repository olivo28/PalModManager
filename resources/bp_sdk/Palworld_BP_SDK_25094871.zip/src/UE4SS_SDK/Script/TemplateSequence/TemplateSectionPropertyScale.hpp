#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneFloatChannel.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieScenePropertyBinding.hpp>
#include <UE4SS_SDK/Script/TemplateSequence/ETemplateSectionPropertyScaleType.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x138 (unaligned: 0x138, alignment: 0x8)
    struct RC_UE4SS_SDK_API FTemplateSectionPropertyScale
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x138;
        }

        FTemplateSectionPropertyScale& operator=(const FTemplateSectionPropertyScale& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FGuid ObjectBinding{}; // 0x0
        FMovieScenePropertyBinding PropertyBinding{}; // 0x10
        ETemplateSectionPropertyScaleType PropertyScaleType{}; // 0x24
        FMovieSceneFloatChannel FloatChannel{}; // 0x28

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API USequenceCameraShakeTestUtil : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        // Function 'GetPostProcessBlendCache' omitted: a parameter or return type is not representable in this SDK.
        // Function 'GetLastFrameCameraCachePOV' omitted: a parameter or return type is not representable in this SDK.
        // Function 'GetCameraCachePOV' omitted: a parameter or return type is not representable in this SDK.
    };


}

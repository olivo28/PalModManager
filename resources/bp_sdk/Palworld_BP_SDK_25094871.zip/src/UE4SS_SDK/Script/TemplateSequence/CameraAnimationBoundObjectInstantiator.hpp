#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneEntityInstantiatorSystem.hpp>

namespace WSDK
{
    // Super Size: 0x40
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UCameraAnimationBoundObjectInstantiator : public WSDK::UMovieSceneEntityInstantiatorSystem
    {
    public:
        // Properties.

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/CameraShakePattern.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UCameraAnimationSequence;
    class UCameraAnimationSequenceCameraStandIn;
    class UCameraAnimationSequencePlayer;

    // Super Size: 0x28
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API USequenceCameraShakePattern : public WSDK::UCameraShakePattern
    {
    public:
        // Properties.
        UCameraAnimationSequence* Sequence{}; // 0x28
        float PlayRate{}; // 0x30
        float Scale{}; // 0x34
        float BlendInTime{}; // 0x38
        float BlendOutTime{}; // 0x3C
        float RandomSegmentDuration{}; // 0x40
        bool bRandomSegment{}; // 0x44
        uint8 padding_1[0x3]{}; // 0x45
        UCameraAnimationSequencePlayer* Player{}; // 0x48
        UCameraAnimationSequenceCameraStandIn* CameraStandIn{}; // 0x50

        // Functions.
    };


}

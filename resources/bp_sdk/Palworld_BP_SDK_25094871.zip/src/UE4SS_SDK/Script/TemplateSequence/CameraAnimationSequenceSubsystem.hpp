#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/WorldSubsystem.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMovieSceneEntitySystemLinker;

    // Super Size: 0x30
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    class RC_UE4SS_SDK_API UCameraAnimationSequenceSubsystem : public WSDK::UWorldSubsystem
    {
    public:
        // Properties.
        UMovieSceneEntitySystemLinker* Linker{}; // 0x30
        uint8 padding_1[0x10]{}; // 0x38

        // Functions.
    };


}

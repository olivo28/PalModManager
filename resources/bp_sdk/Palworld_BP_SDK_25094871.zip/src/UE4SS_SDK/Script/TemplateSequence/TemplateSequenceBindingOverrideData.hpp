#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/FWeakObjectPtr.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FTemplateSequenceBindingOverrideData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FTemplateSequenceBindingOverrideData& operator=(const FTemplateSequenceBindingOverrideData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TWeakObjectPtr<UObject> Object{}; // 0x0
        bool bOverridesDefault{}; // 0x8
        uint8 padding_1[0x3]{}; // 0x9

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSubSection.hpp>
#include <UE4SS_SDK/Script/TemplateSequence/TemplateSectionPropertyScale.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x130
    // Size: 0x148 (unaligned: 0x148, alignment: 0x8)
    class RC_UE4SS_SDK_API UTemplateSequenceSection : public WSDK::UMovieSceneSubSection
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x130
        TArray<FTemplateSectionPropertyScale> PropertyScales{}; // 0x138

        // Functions.
    };


}

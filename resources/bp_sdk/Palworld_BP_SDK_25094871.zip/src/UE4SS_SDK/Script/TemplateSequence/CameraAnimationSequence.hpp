#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/TemplateSequence/TemplateSequence.hpp>

namespace WSDK
{
    // Super Size: 0x120
    // Size: 0x120 (unaligned: 0x120, alignment: 0x8)
    class RC_UE4SS_SDK_API UCameraAnimationSequence : public WSDK::UTemplateSequence
    {
    public:
        // Properties.

        // Functions.
    };


}

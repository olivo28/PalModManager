#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CinematicCamera/CameraFilmbackSettings.hpp>
#include <UE4SS_SDK/Script/CinematicCamera/CameraFocusSettings.hpp>
#include <UE4SS_SDK/Script/CinematicCamera/CameraLensSettings.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/Engine/PostProcessSettings.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x840 (unaligned: 0x840, alignment: 0x10)
    class RC_UE4SS_SDK_API UCameraAnimationSequenceCameraStandIn : public RC::Unreal::UObject
    {
    public:
        // Properties.
        float FieldOfView{}; // 0x28
        uint8 bConstrainAspectRatio : 1{}; // 0x2C (0x1)
        uint8 padding_1 : 1{}; // 0x2C (0x2)
        uint8 padding_2 : 1{}; // 0x2C (0x4)
        uint8 padding_3 : 1{}; // 0x2C (0x8)
        uint8 padding_4 : 1{}; // 0x2C (0x10)
        uint8 padding_5 : 1{}; // 0x2C (0x20)
        uint8 padding_6 : 1{}; // 0x2C (0x40)
        uint8 padding_7 : 1{}; // 0x2C (0x80)
        uint8 padding_8[0x3]{}; // 0x2D
        float AspectRatio{}; // 0x30
        uint8 padding_9[0xC]{}; // 0x34
        FPostProcessSettings PostProcessSettings{}; // 0x40
        float PostProcessBlendWeight{}; // 0x720
        FCameraFilmbackSettings Filmback{}; // 0x724
        FCameraLensSettings LensSettings{}; // 0x730
        uint8 padding_10[0x4]{}; // 0x74C
        FCameraFocusSettings FocusSettings{}; // 0x750
        float CurrentFocalLength{}; // 0x7B8
        float CurrentAperture{}; // 0x7BC
        float CurrentFocusDistance{}; // 0x7C0
        uint8 padding_11[0x7C]{}; // 0x7C4

        // Functions.
    };


}

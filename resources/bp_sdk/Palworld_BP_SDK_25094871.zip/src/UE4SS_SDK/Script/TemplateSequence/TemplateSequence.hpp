#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSequence.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/SoftObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AActor;
    class UMovieScene;

    // Super Size: 0x68
    // Size: 0x120 (unaligned: 0x120, alignment: 0x8)
    class RC_UE4SS_SDK_API UTemplateSequence : public WSDK::UMovieSceneSequence
    {
    public:
        // Properties.
        UMovieScene* MovieScene{}; // 0x68
        TSoftClassPtr<AActor> BoundActorClass{}; // 0x70
        TSoftObjectPtr<AActor> BoundPreviewActor{}; // 0xA0
        TMap<FGuid, FName> BoundActorComponents{}; // 0xD0

        // Functions.
    };


}

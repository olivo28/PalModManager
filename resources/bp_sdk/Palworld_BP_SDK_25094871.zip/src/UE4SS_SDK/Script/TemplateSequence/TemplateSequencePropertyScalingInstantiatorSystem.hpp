#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneEntitySystem.hpp>

namespace WSDK
{
    // Super Size: 0x40
    // Size: 0x98 (unaligned: 0x98, alignment: 0x8)
    class RC_UE4SS_SDK_API UTemplateSequencePropertyScalingInstantiatorSystem : public WSDK::UMovieSceneEntitySystem
    {
    public:
        // Properties.
        uint8 padding_1[0x58]{}; // 0x40

        // Functions.
    };


}

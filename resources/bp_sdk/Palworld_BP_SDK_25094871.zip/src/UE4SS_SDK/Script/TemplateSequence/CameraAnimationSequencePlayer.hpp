#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneRootEvaluationTemplateInstance.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMovieSceneSequence;
    class UObject;

    // Super Size: 0x28
    // Size: 0x380 (unaligned: 0x380, alignment: 0x8)
    class RC_UE4SS_SDK_API UCameraAnimationSequencePlayer : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x260]{}; // 0x28
        UObject* BoundObjectOverride{}; // 0x288
        UMovieSceneSequence* Sequence{}; // 0x290
        FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance{}; // 0x298
        uint8 padding_2[0x60]{}; // 0x320

        // Functions.
    };


}

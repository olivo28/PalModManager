#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETemplateSectionPropertyScaleType : int32
    {
        FloatProperty,
        TransformPropertyLocationOnly,
        TransformPropertyRotationOnly,
    };
}

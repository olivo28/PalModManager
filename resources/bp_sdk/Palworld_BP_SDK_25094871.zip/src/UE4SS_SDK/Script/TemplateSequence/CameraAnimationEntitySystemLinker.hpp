#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneEntitySystemLinker.hpp>

namespace WSDK
{
    // Super Size: 0x6D8
    // Size: 0x6D8 (unaligned: 0x6D8, alignment: 0x8)
    class RC_UE4SS_SDK_API UCameraAnimationEntitySystemLinker : public WSDK::UMovieSceneEntitySystemLinker
    {
    public:
        // Properties.

        // Functions.
    };


}

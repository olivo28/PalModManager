#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSequencePlaybackSettings.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSequencePlayer.hpp>

namespace WSDK
{
    class ATemplateSequenceActor;
    class UObject;
    class UTemplateSequence;
    class UTemplateSequencePlayer;

    // Super Size: 0x4A8
    // Size: 0x4B0 (unaligned: 0x4B0, alignment: 0x8)
    class RC_UE4SS_SDK_API UTemplateSequencePlayer : public WSDK::UMovieSceneSequencePlayer
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x4A8

        // Functions.
        static UTemplateSequencePlayer* CreateTemplateSequencePlayer(UObject* WorldContextObject, UTemplateSequence* TemplateSequence, FMovieSceneSequencePlaybackSettings Settings, ATemplateSequenceActor*& OutActor)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TemplateSequence.TemplateSequencePlayer:CreateTemplateSequencePlayer", 64)
            UE_SET_STATIC_SELF("/Script/TemplateSequence.Default__TemplateSequencePlayer")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(TemplateSequence, UTemplateSequence*, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bAutoPlay, 0x10, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMovieSceneSequenceLoopCount, Settings.LoopCount, 0x10, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FMovieSceneSequenceTickInterval, Settings.TickInterval, 0x10, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Settings.PlayRate, 0x10, 0x14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, Settings.StartTime, 0x10, 0x18)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bRandomStartTime, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bRestoreState, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bDisableMovementInput, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bDisableLookAtInput, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bHidePlayer, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bHideHud, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bDisableCameraCuts, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bPauseAtEnd, 0x10, 0x1C)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint8, Settings.bInheritTickIntervalFromOwner, 0x10, 0x1D)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutActor, ATemplateSequenceActor*, 0x30)
            UE_RETURN_PROPERTY_CUSTOM(UTemplateSequencePlayer*, 0x38)
        }
    };


}

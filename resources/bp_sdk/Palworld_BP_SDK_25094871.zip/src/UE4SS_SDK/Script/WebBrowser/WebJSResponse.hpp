#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WebBrowser/WebJSCallbackBase.hpp>

namespace WSDK
{
    // Super Size: 0x20
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWebJSResponse : public WSDK::FWebJSCallbackBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FWebJSResponse& operator=(const FWebJSResponse& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.

        // Functions.
    };


}

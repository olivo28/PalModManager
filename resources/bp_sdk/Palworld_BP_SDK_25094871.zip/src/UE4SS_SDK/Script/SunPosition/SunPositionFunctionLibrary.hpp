#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/SunPosition/SunPositionData.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API USunPositionFunctionLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static void GetSunPosition(float Latitude, float Longitude, float TimeZone, bool bIsDaylightSavingTime, int32 Year, int32 Month, int32 Day, int32 Hours, int32 Minutes, int32 Seconds, FSunPositionData& SunPositionData)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/SunPosition.SunPositionFunctionLibrary:GetSunPosition", 80)
            UE_SET_STATIC_SELF("/Script/SunPosition.Default__SunPositionFunctionLibrary")
            UE_COPY_PROPERTY_CUSTOM(Latitude, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Longitude, float, 0x4)
            UE_COPY_PROPERTY_CUSTOM(TimeZone, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bIsDaylightSavingTime, bool, 0xC)
            UE_COPY_PROPERTY_CUSTOM(Year, int32, 0x10)
            UE_COPY_PROPERTY_CUSTOM(Month, int32, 0x14)
            UE_COPY_PROPERTY_CUSTOM(Day, int32, 0x18)
            UE_COPY_PROPERTY_CUSTOM(Hours, int32, 0x1C)
            UE_COPY_PROPERTY_CUSTOM(Minutes, int32, 0x20)
            UE_COPY_PROPERTY_CUSTOM(Seconds, int32, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(SunPositionData, FSunPositionData, 0x28)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Timespan.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSunPositionData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FSunPositionData& operator=(const FSunPositionData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Elevation{}; // 0x0
        float CorrectedElevation{}; // 0x4
        float Azimuth{}; // 0x8
        uint8 padding_1[0x4]{}; // 0xC
        FTimespan SunriseTime{}; // 0x10
        FTimespan SunsetTime{}; // 0x18
        FTimespan SolarNoon{}; // 0x20

        // Functions.
    };


}

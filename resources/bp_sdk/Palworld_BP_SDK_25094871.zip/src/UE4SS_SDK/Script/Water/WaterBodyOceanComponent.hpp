#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyComponent.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UOceanBoxCollisionComponent;
    class UOceanCollisionComponent;

    // Super Size: 0x1530
    // Size: 0x1580 (unaligned: 0x1580, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterBodyOceanComponent : public WSDK::UWaterBodyComponent
    {
    public:
        // Properties.
        TArray<UOceanBoxCollisionComponent*> CollisionBoxes{}; // 0x1530
        TArray<UOceanCollisionComponent*> CollisionHullSets{}; // 0x1540
        FVector2D VisualExtents{}; // 0x1550
        FVector CollisionExtents{}; // 0x1560
        float HeightOffset{}; // 0x1578
        uint8 padding_1[0x4]{}; // 0x157C

        // Functions.
    };


}

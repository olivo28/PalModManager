#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/EWaterBrushFalloffMode.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x14 (unaligned: 0x14, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWaterFalloffSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x14;
        }

        FWaterFalloffSettings& operator=(const FWaterFalloffSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWaterBrushFalloffMode FalloffMode{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float FalloffAngle{}; // 0x4
        float FalloffWidth{}; // 0x8
        float EdgeOffset{}; // 0xC
        float ZOffset{}; // 0x10

        // Functions.
    };


}

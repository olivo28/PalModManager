#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EBuoyancyEvent
    {
        EnteredWaterBody,
        ExitedWaterBody,
    };
}

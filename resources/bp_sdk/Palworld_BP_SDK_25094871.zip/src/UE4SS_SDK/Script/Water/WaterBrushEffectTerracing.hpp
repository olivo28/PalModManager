#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x14 (unaligned: 0x14, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWaterBrushEffectTerracing
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x14;
        }

        FWaterBrushEffectTerracing& operator=(const FWaterBrushEffectTerracing& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float TerraceAlpha{}; // 0x0
        float TerraceSpacing{}; // 0x4
        float TerraceSmoothness{}; // 0x8
        float MaskLength{}; // 0xC
        float MaskStartOffset{}; // 0x10

        // Functions.
    };


}

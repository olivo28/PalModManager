#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyGenerator.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UStaticMeshComponent;

    // Super Size: 0x28
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    class RC_UE4SS_SDK_API UDEPRECATED_CustomMeshGenerator : public WSDK::UDEPRECATED_WaterBodyGenerator
    {
    public:
        // Properties.
        UStaticMeshComponent* MeshComp{}; // 0x28

        // Functions.
    };


}

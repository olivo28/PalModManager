#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/PhysicsVolume.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AWaterBody;

    // Super Size: 0x2D8
    // Size: 0x2F0 (unaligned: 0x2F0, alignment: 0x8)
    class RC_UE4SS_SDK_API AWaterBodyExclusionVolume : public WSDK::APhysicsVolume
    {
    public:
        // Properties.
        bool bExcludeAllOverlappingWaterBodies{}; // 0x2D8
        uint8 padding_1[0x7]{}; // 0x2D9
        TArray<AWaterBody*> WaterBodiesToExclude{}; // 0x2E0

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x14 (unaligned: 0x14, alignment: 0x4)
    struct RC_UE4SS_SDK_API FGerstnerWaveOctave
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x14;
        }

        FGerstnerWaveOctave& operator=(const FGerstnerWaveOctave& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 NumWaves{}; // 0x0
        float AmplitudeScale{}; // 0x4
        float MainDirection{}; // 0x8
        float SpreadAngle{}; // 0xC
        bool bUniformSpread{}; // 0x10
        uint8 padding_1[0x3]{}; // 0x11

        // Functions.
    };


}

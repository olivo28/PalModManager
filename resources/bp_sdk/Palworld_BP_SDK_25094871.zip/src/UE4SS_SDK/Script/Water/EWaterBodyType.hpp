#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaterBodyType : uint8
    {
        River,
        Lake,
        Ocean,
        Transition,
        Num,
    };
}

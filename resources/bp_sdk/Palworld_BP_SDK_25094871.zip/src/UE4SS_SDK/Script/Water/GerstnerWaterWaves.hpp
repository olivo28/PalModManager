#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/GerstnerWave.hpp>
#include <UE4SS_SDK/Script/Water/WaterWaves.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UGerstnerWaterWaveGeneratorBase;

    // Super Size: 0x28
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    class RC_UE4SS_SDK_API UGerstnerWaterWaves : public WSDK::UWaterWaves
    {
    public:
        // Properties.
        UGerstnerWaterWaveGeneratorBase* GerstnerWaveGenerator{}; // 0x28
        TArray<FGerstnerWave> GerstnerWaves{}; // 0x30
        float MaxWaveHeight{}; // 0x40
        uint8 padding_1[0x4]{}; // 0x44

        // Functions.
    };


}

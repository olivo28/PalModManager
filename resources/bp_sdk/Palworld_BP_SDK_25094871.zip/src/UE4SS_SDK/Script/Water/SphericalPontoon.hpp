#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Quat.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWaterBodyComponent;

    // Super Size: 0x0
    // Size: 0x2D0 (unaligned: 0x2D0, alignment: 0x10)
    struct RC_UE4SS_SDK_API FSphericalPontoon
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x2D0;
        }

        FSphericalPontoon& operator=(const FSphericalPontoon& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FName CenterSocket{}; // 0x0
        FVector RelativeLocation{}; // 0x8
        float Radius{}; // 0x20
        bool bFXEnabled{}; // 0x24
        uint8 padding_1[0x3]{}; // 0x25
        FVector LocalForce{}; // 0x28
        FVector CenterLocation{}; // 0x40
        uint8 padding_2[0x8]{}; // 0x58
        FQuat SocketRotation{}; // 0x60
        FVector Offset{}; // 0x80
        uint8 padding_3[0x4]{}; // 0x98
        float WaterHeight{}; // 0x9C
        float WaterDepth{}; // 0xA0
        float ImmersionDepth{}; // 0xA4
        FVector WaterPlaneLocation{}; // 0xA8
        FVector WaterPlaneNormal{}; // 0xC0
        FVector WaterSurfacePosition{}; // 0xD8
        FVector WaterVelocity{}; // 0xF0
        int32 WaterBodyIndex{}; // 0x108
        bool bIsInWater{}; // 0x10C
        uint8 padding_4[0x1AB]{}; // 0x10D
        UWaterBodyComponent* CurrentWaterBodyComponent{}; // 0x2B8
        uint8 padding_5[0x10]{}; // 0x2C0

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaveSpectrumType : uint8
    {
        Phillips,
        PiersonMoskowitz,
        JONSWAP,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BoxComponent.hpp>

namespace WSDK
{
    // Super Size: 0x580
    // Size: 0x580 (unaligned: 0x580, alignment: 0x10)
    class RC_UE4SS_SDK_API UOceanBoxCollisionComponent : public WSDK::UBoxComponent
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x578

        // Functions.
    };


}

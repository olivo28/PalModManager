#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UTexture2D;

    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaterBodyWeightmapSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FWaterBodyWeightmapSettings& operator=(const FWaterBodyWeightmapSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float FalloffWidth{}; // 0x0
        float EdgeOffset{}; // 0x4
        UTexture2D* ModulationTexture{}; // 0x8
        float TextureTiling{}; // 0x10
        float TextureInfluence{}; // 0x14
        float Midpoint{}; // 0x18
        float FinalOpacity{}; // 0x1C

        // Functions.
    };


}

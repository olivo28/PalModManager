#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TickableWorldSubsystem.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class ABuoyancyManager;
    class UMaterialParameterCollection;
    class UStaticMesh;

    // Super Size: 0x40
    // Size: 0x110 (unaligned: 0x110, alignment: 0x8)
    class RC_UE4SS_SDK_API UWaterSubsystem : public WSDK::UTickableWorldSubsystem
    {
    public:
        // Properties.
        uint8 padding_1[0x38]{}; // 0x40
        ABuoyancyManager* BuoyancyManager{}; // 0x78
        FMulticastScriptDelegate OnCameraUnderwaterStateChanged{}; // 0x80
        FMulticastScriptDelegate OnWaterScalabilityChanged{}; // 0x90
        UStaticMesh* DefaultRiverMesh{}; // 0xA0
        UStaticMesh* DefaultLakeMesh{}; // 0xA8
        uint8 padding_2[0x28]{}; // 0xB0
        UMaterialParameterCollection* MaterialParameterCollection{}; // 0xD8
        uint8 padding_3[0x30]{}; // 0xE0

        // Functions.
        void SetOceanFloodHeight(float InFloodHeight)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:SetOceanFloodHeight", 4)
            UE_COPY_PROPERTY_CUSTOM(InFloodHeight, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void PrintToWaterLog(FString& Message, bool bWarning)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:PrintToWaterLog", 17)
            UE_COPY_PROPERTY_CUSTOM(Message, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bWarning, bool, 0x10)
            UE_CALL_FUNCTION()
        }
        bool IsWaterRenderingEnabled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:IsWaterRenderingEnabled", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsUnderwaterPostProcessEnabled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:IsUnderwaterPostProcessEnabled", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsShallowWaterSimulationEnabled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:IsShallowWaterSimulationEnabled", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        float GetWaterTimeSeconds()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetWaterTimeSeconds", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetSmoothedWorldTimeSeconds()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetSmoothedWorldTimeSeconds", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        static int32 GetShallowWaterSimulationRenderTargetSize()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetShallowWaterSimulationRenderTargetSize", 4)
            UE_SET_STATIC_SELF("/Script/Water.Default__WaterSubsystem")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        static int32 GetShallowWaterMaxImpulseForces()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetShallowWaterMaxImpulseForces", 4)
            UE_SET_STATIC_SELF("/Script/Water.Default__WaterSubsystem")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        static int32 GetShallowWaterMaxDynamicForces()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetShallowWaterMaxDynamicForces", 4)
            UE_SET_STATIC_SELF("/Script/Water.Default__WaterSubsystem")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        float GetOceanTotalHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetOceanTotalHeight", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetOceanFloodHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetOceanFloodHeight", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetOceanBaseHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetOceanBaseHeight", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetCameraUnderwaterDepth()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterSubsystem:GetCameraUnderwaterDepth", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

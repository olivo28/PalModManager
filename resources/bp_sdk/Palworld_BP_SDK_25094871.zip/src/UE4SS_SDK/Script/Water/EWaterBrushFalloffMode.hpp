#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaterBrushFalloffMode : uint8
    {
        Angle,
        Width,
    };
}

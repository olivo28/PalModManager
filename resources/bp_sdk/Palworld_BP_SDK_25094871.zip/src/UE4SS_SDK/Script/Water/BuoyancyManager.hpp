#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class ABuoyancyManager;
    class UBuoyancyComponent;
    class UObject;

    // Super Size: 0x290
    // Size: 0x358 (unaligned: 0x358, alignment: 0x8)
    class RC_UE4SS_SDK_API ABuoyancyManager : public WSDK::AActor
    {
    public:
        // Properties.
        uint8 padding_1[0x50]{}; // 0x290
        TArray<UBuoyancyComponent*> BuoyancyComponents{}; // 0x2E0
        uint8 padding_2[0x68]{}; // 0x2F0

        // Functions.
        static bool GetBuoyancyComponentManager(UObject* WorldContextObject, ABuoyancyManager*& Manager)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyManager:GetBuoyancyComponentManager", 17)
            UE_SET_STATIC_SELF("/Script/Water.Default__BuoyancyManager")
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Manager, ABuoyancyManager*, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
    };


}

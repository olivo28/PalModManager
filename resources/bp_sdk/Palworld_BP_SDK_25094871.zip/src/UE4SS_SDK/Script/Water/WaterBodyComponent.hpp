#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/Engine/PostProcessSettings.hpp>
#include <UE4SS_SDK/Script/Engine/PrimitiveComponent.hpp>
#include <UE4SS_SDK/Script/Water/UnderwaterPostProcessSettings.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyExclusionVolume.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyHeightmapSettings.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyIsland.hpp>
#include <UE4SS_SDK/Script/Water/WaterCurveSettings.hpp>
#include <UE4SS_SDK/Script/Water/WaterZone.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FWeakObjectPtr.hpp>
#include <Unreal/SoftObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class ALandscapeProxy;
    class AWaterBody;
    class AWaterBodyExclusionVolume;
    class AWaterBodyIsland;
    class AWaterZone;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class UNavAreaBase;
    class UPhysicalMaterial;
    class UPrimitiveComponent;
    class UStaticMesh;
    class UWaterSplineComponent;
    class UWaterSplineMetadata;
    class UWaterWavesBase;

    // Super Size: 0x540
    // Size: 0x1530 (unaligned: 0x1530, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterBodyComponent : public WSDK::UPrimitiveComponent
    {
    public:
        // Properties.
        UPhysicalMaterial* PhysicalMaterial{}; // 0x538
        float TargetWaveMaskDepth{}; // 0x540
        float MaxWaveHeightOffset{}; // 0x544
        uint8 padding_1[0x8]{}; // 0x548
        FUnderwaterPostProcessSettings UnderwaterPostProcessSettings{}; // 0x550
        FWaterCurveSettings CurveSettings{}; // 0xC50
        UMaterialInterface* WaterMaterial{}; // 0xC70
        UMaterialInterface* WaterHLODMaterial{}; // 0xC78
        UMaterialInterface* WaterLODMaterial{}; // 0xC80
        UMaterialInterface* UnderwaterPostProcessMaterial{}; // 0xC88
        UMaterialInterface* WaterInfoMaterial{}; // 0xC90
        FWaterBodyHeightmapSettings WaterHeightmapSettings{}; // 0xC98
        float ShapeDilation{}; // 0xD18
        float CollisionHeightOffset{}; // 0xD1C
        bool bAffectsLandscape{}; // 0xD20
        uint8 padding_2[0x3]{}; // 0xD21
        int32 WaterBodyIndex{}; // 0xD24
        UStaticMesh* WaterMeshOverride{}; // 0xD28
        bool bAlwaysGenerateWaterMeshTiles{}; // 0xD30
        uint8 padding_3[0x3]{}; // 0xD31
        int32 OverlapMaterialPriority{}; // 0xD34
        UWaterSplineMetadata* WaterSplineMetadata{}; // 0xD38
        UMaterialInstanceDynamic* WaterMID{}; // 0xD40
        UMaterialInstanceDynamic* WaterLODMID{}; // 0xD48
        UMaterialInstanceDynamic* UnderwaterPostProcessMID{}; // 0xD50
        UMaterialInstanceDynamic* WaterInfoMID{}; // 0xD58
        TArray<TSoftObjectPtr<AWaterBodyIsland>> WaterBodyIslands{}; // 0xD60
        TArray<TSoftObjectPtr<AWaterBodyExclusionVolume>> WaterBodyExclusionVolumes{}; // 0xD70
        TWeakObjectPtr<ALandscapeProxy> Landscape{}; // 0xD80
        TSoftObjectPtr<AWaterZone> OwningWaterZone{}; // 0xD88
        TSoftObjectPtr<AWaterZone> WaterZoneOverride{}; // 0xDB8
        uint8 padding_4[0x8]{}; // 0xDE8
        FPostProcessSettings CurrentPostProcessSettings{}; // 0xDF0
        TSubclassOf<UNavAreaBase> WaterNavAreaClass{}; // 0x14D0
        uint8 padding_5[0x50]{}; // 0x14D8
        double FixedWaterDepth{}; // 0x1528

        // Functions.
        void SetWaterAndUnderWaterPostProcessMaterial(UMaterialInterface* InWaterMaterial, UMaterialInterface* InUnderWaterPostProcessMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:SetWaterAndUnderWaterPostProcessMaterial", 16)
            UE_COPY_PROPERTY_CUSTOM(InWaterMaterial, UMaterialInterface*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InUnderWaterPostProcessMaterial, UMaterialInterface*, 0x8)
            UE_CALL_FUNCTION()
        }
        void OnWaterBodyChanged(bool bShapeOrPositionChanged, bool bWeightmapSettingsChanged)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:OnWaterBodyChanged", 2)
            UE_COPY_PROPERTY_CUSTOM(bShapeOrPositionChanged, bool, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bWeightmapSettingsChanged, bool, 0x1)
            UE_CALL_FUNCTION()
        }
        UWaterWavesBase* GetWaterWaves()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterWaves", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWaterWavesBase*, 0x0)
        }
        float GetWaterVelocityAtSplineInputKey(float InKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterVelocityAtSplineInputKey", 8)
            UE_COPY_PROPERTY_CUSTOM(InKey, float, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x4)
        }
        void GetWaterSurfaceInfoAtLocation(FVector& InLocation, FVector& OutWaterSurfaceLocation, FVector& OutWaterSurfaceNormal, FVector& OutWaterVelocity, float& OutWaterDepth, bool bIncludeDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterSurfaceInfoAtLocation", 101)
            UE_COPY_PROPERTY_CUSTOM(bIncludeDepth, bool, 0x64)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InLocation, FVector, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterSurfaceLocation, FVector, 0x18)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterSurfaceNormal, FVector, 0x30)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterVelocity, FVector, 0x48)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterDepth, float, 0x60)
        }
        UWaterSplineComponent* GetWaterSpline()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterSpline", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWaterSplineComponent*, 0x0)
        }
        UMaterialInstanceDynamic* GetWaterMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        UMaterialInterface* GetWaterMaterial()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterMaterial", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInterface*, 0x0)
        }
        UMaterialInstanceDynamic* GetWaterLODMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterLODMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        UMaterialInstanceDynamic* GetWaterInfoMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterInfoMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        AWaterBody* GetWaterBodyActor()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetWaterBodyActor", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(AWaterBody*, 0x0)
        }
        UMaterialInstanceDynamic* GetUnderwaterPostProcessMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetUnderwaterPostProcessMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        TArray<UPrimitiveComponent*> GetStandardRenderableComponents()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetStandardRenderableComponents", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UPrimitiveComponent*>, 0x0)
        }
        UMaterialInstanceDynamic* GetRiverToOceanTransitionMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetRiverToOceanTransitionMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        UMaterialInstanceDynamic* GetRiverToLakeTransitionMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetRiverToLakeTransitionMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        float GetMaxWaveHeight()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetMaxWaveHeight", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        TArray<AWaterBodyIsland*> GetIslands()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetIslands", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<AWaterBodyIsland*>, 0x0)
        }
        TArray<AWaterBodyExclusionVolume*> GetExclusionVolumes()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetExclusionVolumes", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<AWaterBodyExclusionVolume*>, 0x0)
        }
        TArray<UPrimitiveComponent*> GetCollisionComponents(bool bInOnlyEnabledComponents)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyComponent:GetCollisionComponents", 24)
            UE_COPY_PROPERTY_CUSTOM(bInOnlyEnabledComponents, bool, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UPrimitiveComponent*>, 0x8)
        }
    };


}

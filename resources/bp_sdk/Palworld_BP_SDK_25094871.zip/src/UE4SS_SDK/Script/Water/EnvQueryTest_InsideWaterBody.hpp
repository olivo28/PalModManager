#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AIModule/EnvQueryTest.hpp>

namespace WSDK
{
    // Super Size: 0x1F8
    // Size: 0x200 (unaligned: 0x200, alignment: 0x8)
    class RC_UE4SS_SDK_API UEnvQueryTest_InsideWaterBody : public WSDK::UEnvQueryTest
    {
    public:
        // Properties.
        bool bIncludeWaves{}; // 0x1F8
        bool bSimpleWaves{}; // 0x1F9
        bool bIgnoreExclusionVolumes{}; // 0x1FA
        uint8 padding_1[0x5]{}; // 0x1FB

        // Functions.
    };


}

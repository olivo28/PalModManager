#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/EWaveSpectrumType.hpp>
#include <UE4SS_SDK/Script/Water/GerstnerWaterWaveGeneratorBase.hpp>
#include <UE4SS_SDK/Script/Water/GerstnerWaveOctave.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UGerstnerWaterWaveGeneratorSpectrum : public WSDK::UGerstnerWaterWaveGeneratorBase
    {
    public:
        // Properties.
        EWaveSpectrumType SpectrumType{}; // 0x28
        uint8 padding_1[0x7]{}; // 0x29
        TArray<FGerstnerWaveOctave> Octaves{}; // 0x30

        // Functions.
    };


}

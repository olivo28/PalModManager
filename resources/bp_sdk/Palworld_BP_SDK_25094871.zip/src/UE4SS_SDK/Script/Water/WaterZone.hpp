#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/IntPoint.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FWeakObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UTextureRenderTarget2D;
    class UWaterBodyComponent;
    class UWaterMeshComponent;

    // Super Size: 0x290
    // Size: 0x320 (unaligned: 0x320, alignment: 0x8)
    class RC_UE4SS_SDK_API AWaterZone : public WSDK::AActor
    {
    public:
        // Properties.
        UTextureRenderTarget2D* WaterInfoTexture{}; // 0x290
        TArray<TWeakObjectPtr<UWaterBodyComponent>> OwnedWaterBodies{}; // 0x298
        FIntPoint RenderTargetResolution{}; // 0x2A8
        UWaterMeshComponent* WaterMesh{}; // 0x2B0
        FVector2D ZoneExtent{}; // 0x2B8
        float CaptureZOffset{}; // 0x2C8
        bool bHalfPrecisionTexture{}; // 0x2CC
        uint8 padding_1[0x3]{}; // 0x2CD
        int32 VelocityBlurRadius{}; // 0x2D0
        uint8 padding_2[0x4]{}; // 0x2D4
        FVector TessellatedWaterMeshExtent{}; // 0x2D8
        uint32 NonTessellatedLODSectionScale{}; // 0x2F0
        int32 OverlapPriority{}; // 0x2F4
        bool bEnableNonTessellatedLODMesh{}; // 0x2F8
        uint8 padding_3[0x27]{}; // 0x2F9

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyGenerator.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UBoxComponent;
    class ULakeCollisionComponent;
    class UStaticMeshComponent;

    // Super Size: 0x28
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UDEPRECATED_LakeGenerator : public WSDK::UDEPRECATED_WaterBodyGenerator
    {
    public:
        // Properties.
        UStaticMeshComponent* LakeMeshComp{}; // 0x28
        UBoxComponent* LakeCollisionComp{}; // 0x30
        ULakeCollisionComponent* LakeCollision{}; // 0x38

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyGenerator.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class USplineMeshComponent;

    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UDEPRECATED_RiverGenerator : public WSDK::UDEPRECATED_WaterBodyGenerator
    {
    public:
        // Properties.
        TArray<USplineMeshComponent*> SplineMeshComponents{}; // 0x28

        // Functions.
    };


}

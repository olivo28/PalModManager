#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWaterSplineComponent;

    // Super Size: 0x290
    // Size: 0x2A0 (unaligned: 0x2A0, alignment: 0x8)
    class RC_UE4SS_SDK_API AWaterBodyIsland : public WSDK::AActor
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x290
        UWaterSplineComponent* SplineComp{}; // 0x298

        // Functions.
        UWaterSplineComponent* GetWaterSpline()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBodyIsland:GetWaterSpline", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWaterSplineComponent*, 0x0)
        }
    };


}

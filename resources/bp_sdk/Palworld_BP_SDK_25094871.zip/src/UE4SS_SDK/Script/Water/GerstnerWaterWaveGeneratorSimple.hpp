#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/GerstnerWaterWaveGeneratorBase.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UGerstnerWaterWaveGeneratorSimple : public WSDK::UGerstnerWaterWaveGeneratorBase
    {
    public:
        // Properties.
        int32 NumWaves{}; // 0x28
        int32 Seed{}; // 0x2C
        float Randomness{}; // 0x30
        float MinWavelength{}; // 0x34
        float MaxWavelength{}; // 0x38
        float WavelengthFalloff{}; // 0x3C
        float MinAmplitude{}; // 0x40
        float MaxAmplitude{}; // 0x44
        float AmplitudeFalloff{}; // 0x48
        float WindAngleDeg{}; // 0x4C
        float DirectionAngularSpreadDeg{}; // 0x50
        float SmallWaveSteepness{}; // 0x54
        float LargeWaveSteepness{}; // 0x58
        float SteepnessFalloff{}; // 0x5C

        // Functions.
    };


}

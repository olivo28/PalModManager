#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/InterpCurveFloat.hpp>
#include <UE4SS_SDK/Script/CoreUObject/InterpCurveVector.hpp>
#include <UE4SS_SDK/Script/Engine/SplineMetadata.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0xA0 (unaligned: 0xA0, alignment: 0x8)
    class RC_UE4SS_SDK_API UWaterSplineMetadata : public WSDK::USplineMetadata
    {
    public:
        // Properties.
        FInterpCurveFloat Depth{}; // 0x28
        FInterpCurveFloat WaterVelocityScalar{}; // 0x40
        FInterpCurveFloat RiverWidth{}; // 0x58
        FInterpCurveFloat AudioIntensity{}; // 0x70
        FInterpCurveVector WaterVelocity{}; // 0x88

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaterBrushBlendType : uint8
    {
        AlphaBlend,
        Min,
        Max,
        Additive,
    };
}

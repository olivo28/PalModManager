#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UTexture2D;

    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaterBrushEffectDisplacement
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FWaterBrushEffectDisplacement& operator=(const FWaterBrushEffectDisplacement& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float DisplacementHeight{}; // 0x0
        float DisplacementTiling{}; // 0x4
        UTexture2D* Texture{}; // 0x8
        float Midpoint{}; // 0x10
        FLinearColor Channel{}; // 0x14
        float WeightmapInfluence{}; // 0x24

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyComponent.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class USplineMeshComponent;

    // Super Size: 0x1530
    // Size: 0x1560 (unaligned: 0x1560, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterBodyRiverComponent : public WSDK::UWaterBodyComponent
    {
    public:
        // Properties.
        TArray<USplineMeshComponent*> SplineMeshComponents{}; // 0x1530
        UMaterialInterface* LakeTransitionMaterial{}; // 0x1540
        UMaterialInstanceDynamic* LakeTransitionMID{}; // 0x1548
        UMaterialInterface* OceanTransitionMaterial{}; // 0x1550
        UMaterialInstanceDynamic* OceanTransitionMID{}; // 0x1558

        // Functions.
    };


}

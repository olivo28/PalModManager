#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/Engine/PrimitiveComponent.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UBodySetup;

    // Super Size: 0x540
    // Size: 0x560 (unaligned: 0x560, alignment: 0x10)
    class RC_UE4SS_SDK_API ULakeCollisionComponent : public WSDK::UPrimitiveComponent
    {
    public:
        // Properties.
        UBodySetup* CachedBodySetup{}; // 0x538
        FVector BoxExtent{}; // 0x540
        uint8 padding_1[0x8]{}; // 0x558

        // Functions.
    };


}

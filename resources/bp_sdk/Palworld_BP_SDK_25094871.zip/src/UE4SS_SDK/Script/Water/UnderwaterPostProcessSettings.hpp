#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/PostProcessSettings.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMaterialInterface;

    // Super Size: 0x0
    // Size: 0x700 (unaligned: 0x700, alignment: 0x10)
    struct RC_UE4SS_SDK_API FUnderwaterPostProcessSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x700;
        }

        FUnderwaterPostProcessSettings& operator=(const FUnderwaterPostProcessSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bEnabled{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float Priority{}; // 0x4
        float BlendRadius{}; // 0x8
        float BlendWeight{}; // 0xC
        FPostProcessSettings PostProcessSettings{}; // 0x10
        UMaterialInterface* UnderwaterPostProcessMaterial{}; // 0x6F0
        uint8 padding_2[0x8]{}; // 0x6F8

        // Functions.
    };


}

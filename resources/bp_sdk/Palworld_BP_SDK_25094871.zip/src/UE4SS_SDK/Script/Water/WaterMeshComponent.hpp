#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/IntPoint.hpp>
#include <UE4SS_SDK/Script/Engine/MeshComponent.hpp>
#include <Unreal/Core/Containers/Set.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMaterialInterface;

    // Super Size: 0x570
    // Size: 0x690 (unaligned: 0x690, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterMeshComponent : public WSDK::UMeshComponent
    {
    public:
        // Properties.
        int32 ForceCollapseDensityLevel{}; // 0x570
        uint8 padding_1[0x4]{}; // 0x574
        UMaterialInterface* FarDistanceMaterial{}; // 0x578
        float FarDistanceMeshExtent{}; // 0x580
        float TileSize{}; // 0x584
        FIntPoint ExtentInTiles{}; // 0x588
        uint8 padding_2[0x98]{}; // 0x590
        TSet<UMaterialInterface*> UsedMaterials{}; // 0x628
        uint8 padding_3[0x10]{}; // 0x678
        int32 TessellationFactor{}; // 0x688
        float LODScale{}; // 0x68C

        // Functions.
        bool IsEnabled()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterMeshComponent:IsEnabled", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
    };


}

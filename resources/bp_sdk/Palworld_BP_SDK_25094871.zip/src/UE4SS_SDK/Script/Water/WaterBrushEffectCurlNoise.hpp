#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWaterBrushEffectCurlNoise
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FWaterBrushEffectCurlNoise& operator=(const FWaterBrushEffectCurlNoise& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Curl1Amount{}; // 0x0
        float Curl2Amount{}; // 0x4
        float Curl1Tiling{}; // 0x8
        float Curl2Tiling{}; // 0xC

        // Functions.
    };


}

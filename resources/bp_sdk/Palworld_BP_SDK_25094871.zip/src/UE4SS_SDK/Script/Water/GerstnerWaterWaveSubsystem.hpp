#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/EngineSubsystem.hpp>

namespace WSDK
{
    // Super Size: 0x30
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    class RC_UE4SS_SDK_API UGerstnerWaterWaveSubsystem : public WSDK::UEngineSubsystem
    {
    public:
        // Properties.
        uint8 padding_1[0x18]{}; // 0x30

        // Functions.
    };


}

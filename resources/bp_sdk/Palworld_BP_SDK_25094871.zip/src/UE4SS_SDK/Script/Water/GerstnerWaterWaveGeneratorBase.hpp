#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/Water/GerstnerWave.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UGerstnerWaterWaveGeneratorBase : public RC::Unreal::UObject
    {
    public:
        // Properties.

        // Functions.
        void GenerateGerstnerWaves(TArray<FGerstnerWave>& OutWaves)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.GerstnerWaterWaveGeneratorBase:GenerateGerstnerWaves", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaves, TArray<FGerstnerWave>, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SplineComponent.hpp>
#include <UE4SS_SDK/Script/Water/WaterSplineCurveDefaults.hpp>

namespace WSDK
{
    // Super Size: 0x640
    // Size: 0x660 (unaligned: 0x660, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterSplineComponent : public WSDK::USplineComponent
    {
    public:
        // Properties.
        FWaterSplineCurveDefaults WaterSplineDefaults{}; // 0x638
        FWaterSplineCurveDefaults PreviousWaterSplineDefaults{}; // 0x648
        uint8 padding_1[0x8]{}; // 0x658

        // Functions.
    };


}

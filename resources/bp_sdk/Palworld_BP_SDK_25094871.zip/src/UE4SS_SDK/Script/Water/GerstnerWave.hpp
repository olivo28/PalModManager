#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    struct RC_UE4SS_SDK_API FGerstnerWave
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x48;
        }

        FGerstnerWave& operator=(const FGerstnerWave& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float WaveLength{}; // 0x0
        float Amplitude{}; // 0x4
        float Steepness{}; // 0x8
        uint8 padding_1[0x4]{}; // 0xC
        FVector Direction{}; // 0x10
        FVector2D WaveVector{}; // 0x28
        float WaveSpeed{}; // 0x38
        float WKA{}; // 0x3C
        float Q{}; // 0x40
        float PhaseOffset{}; // 0x44

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWaterWaves;

    // Super Size: 0x28
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    class RC_UE4SS_SDK_API UWaterWavesAsset : public RC::Unreal::UObject
    {
    public:
        // Properties.
        UWaterWaves* WaterWaves{}; // 0x28

        // Functions.
    };


}

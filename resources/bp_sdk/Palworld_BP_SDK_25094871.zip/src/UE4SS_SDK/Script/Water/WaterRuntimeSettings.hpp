#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/DeveloperSettings/DeveloperSettings.hpp>
#include <UE4SS_SDK/Script/Engine/ECollisionChannel.hpp>
#include <UE4SS_SDK/Script/Engine/MaterialInterface.hpp>
#include <UE4SS_SDK/Script/Engine/MaterialParameterCollection.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/SoftObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>
#include <Unreal/ULocalPlayer.hpp>

namespace WSDK
{
    class UMaterialInterface;
    class UMaterialParameterCollection;
    class UWaterBodyCustomComponent;
    class UWaterBodyLakeComponent;
    class UWaterBodyOceanComponent;
    class UWaterBodyRiverComponent;

    // Super Size: 0x38
    // Size: 0xD0 (unaligned: 0xD0, alignment: 0x8)
    class RC_UE4SS_SDK_API UWaterRuntimeSettings : public WSDK::UDeveloperSettings
    {
    public:
        // Properties.
        TEnumAsByte<ECollisionChannel> CollisionChannelForWaterTraces{}; // 0x38
        uint8 padding_1[0x7]{}; // 0x39
        TSoftObjectPtr<UMaterialParameterCollection> MaterialParameterCollection{}; // 0x40
        float WaterBodyIconWorldZOffset{}; // 0x70
        FName DefaultWaterCollisionProfileName{}; // 0x74
        uint8 padding_2[0x4]{}; // 0x7C
        TSoftObjectPtr<UMaterialInterface> DefaultWaterInfoMaterial{}; // 0x80
        TSubclassOf<UWaterBodyRiverComponent> WaterBodyRiverComponentClass{}; // 0xB0
        TSubclassOf<UWaterBodyLakeComponent> WaterBodyLakeComponentClass{}; // 0xB8
        TSubclassOf<UWaterBodyOceanComponent> WaterBodyOceanComponentClass{}; // 0xC0
        TSubclassOf<UWaterBodyCustomComponent> WaterBodyCustomComponentClass{}; // 0xC8

        // Functions.
    };


}

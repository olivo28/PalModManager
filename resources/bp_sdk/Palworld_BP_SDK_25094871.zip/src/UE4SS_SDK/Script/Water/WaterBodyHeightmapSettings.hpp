#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/EWaterBrushBlendType.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffects.hpp>
#include <UE4SS_SDK/Script/Water/WaterFalloffSettings.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x80 (unaligned: 0x80, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaterBodyHeightmapSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x80;
        }

        FWaterBodyHeightmapSettings& operator=(const FWaterBodyHeightmapSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWaterBrushBlendType BlendMode{}; // 0x0
        bool bInvertShape{}; // 0x1
        uint8 padding_1[0x2]{}; // 0x2
        FWaterFalloffSettings FalloffSettings{}; // 0x4
        FWaterBrushEffects Effects{}; // 0x18
        int32 Priority{}; // 0x78
        uint8 padding_2[0x4]{}; // 0x7C

        // Functions.
    };


}

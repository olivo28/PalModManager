#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWaterBrushEffectBlurring
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FWaterBrushEffectBlurring& operator=(const FWaterBrushEffectBlurring& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bBlurShape{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        int32 Radius{}; // 0x4

        // Functions.
    };


}

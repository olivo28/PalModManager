#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UCurveFloat;

    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaterBrushEffectCurves
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FWaterBrushEffectCurves& operator=(const FWaterBrushEffectCurves& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bUseCurveChannel{}; // 0x0
        uint8 padding_1[0x7]{}; // 0x1
        UCurveFloat* ElevationCurveAsset{}; // 0x8
        float ChannelEdgeOffset{}; // 0x10
        float ChannelDepth{}; // 0x14
        float CurveRampWidth{}; // 0x18
        uint8 padding_2[0x4]{}; // 0x1C

        // Functions.
    };


}

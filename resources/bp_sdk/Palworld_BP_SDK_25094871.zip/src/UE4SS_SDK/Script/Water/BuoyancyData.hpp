#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/Water/SphericalPontoon.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x90 (unaligned: 0x90, alignment: 0x8)
    struct RC_UE4SS_SDK_API FBuoyancyData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x90;
        }

        FBuoyancyData& operator=(const FBuoyancyData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TArray<FSphericalPontoon> Pontoons{}; // 0x0
        bool bCenterPontoonsOnCOM{}; // 0x10
        uint8 padding_1[0x3]{}; // 0x11
        float BuoyancyCoefficient{}; // 0x14
        float BuoyancyDamp{}; // 0x18
        float BuoyancyDamp2{}; // 0x1C
        float BuoyancyRampMinVelocity{}; // 0x20
        float BuoyancyRampMaxVelocity{}; // 0x24
        float BuoyancyRampMax{}; // 0x28
        float MaxBuoyantForce{}; // 0x2C
        bool bApplyDragForcesInWater{}; // 0x30
        uint8 padding_2[0x3]{}; // 0x31
        float DragCoefficient{}; // 0x34
        float DragCoefficient2{}; // 0x38
        float AngularDragCoefficient{}; // 0x3C
        float MaxDragSpeed{}; // 0x40
        bool bApplyRiverForces{}; // 0x44
        uint8 padding_3[0x3]{}; // 0x45
        int32 RiverPontoonIndex{}; // 0x48
        float WaterShorePushFactor{}; // 0x4C
        float RiverTraversalPathWidth{}; // 0x50
        float MaxShorePushForce{}; // 0x54
        float WaterVelocityStrength{}; // 0x58
        float MaxWaterForce{}; // 0x5C
        bool bAlwaysAllowLateralPush{}; // 0x60
        bool bAllowCurrentWhenMovingFastUpstream{}; // 0x61
        bool bApplyDownstreamAngularRotation{}; // 0x62
        uint8 padding_4[0x5]{}; // 0x63
        FVector DownstreamAxisOfRotation{}; // 0x68
        float DownstreamRotationStrength{}; // 0x80
        float DownstreamRotationStiffness{}; // 0x84
        float DownstreamRotationAngularDamping{}; // 0x88
        float DownstreamMaxAcceleration{}; // 0x8C

        // Functions.
    };


}

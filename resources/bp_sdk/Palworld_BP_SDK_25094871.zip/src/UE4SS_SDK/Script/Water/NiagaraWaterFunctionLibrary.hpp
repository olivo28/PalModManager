#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    class AWaterBody;
    class UNiagaraComponent;
    class UWaterBodyComponent;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UNiagaraWaterFunctionLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static void SetWaterBodyComponent(UNiagaraComponent* NiagaraSystem, FString& OverrideName, UWaterBodyComponent* WaterBodyComponent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.NiagaraWaterFunctionLibrary:SetWaterBodyComponent", 32)
            UE_SET_STATIC_SELF("/Script/Water.Default__NiagaraWaterFunctionLibrary")
            UE_COPY_PROPERTY_CUSTOM(NiagaraSystem, UNiagaraComponent*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OverrideName, FString, 0x8)
            UE_COPY_PROPERTY_CUSTOM(WaterBodyComponent, UWaterBodyComponent*, 0x18)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetWaterBody(UNiagaraComponent* NiagaraSystem, FString& OverrideName, AWaterBody* WaterBody)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.NiagaraWaterFunctionLibrary:SetWaterBody", 32)
            UE_SET_STATIC_SELF("/Script/Water.Default__NiagaraWaterFunctionLibrary")
            UE_COPY_PROPERTY_CUSTOM(NiagaraSystem, UNiagaraComponent*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OverrideName, FString, 0x8)
            UE_COPY_PROPERTY_CUSTOM(WaterBody, AWaterBody*, 0x18)
            UE_CALL_STATIC_FUNCTION()
        }
    };


}

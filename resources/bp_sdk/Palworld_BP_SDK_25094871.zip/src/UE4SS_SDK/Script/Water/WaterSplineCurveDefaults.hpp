#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWaterSplineCurveDefaults
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FWaterSplineCurveDefaults& operator=(const FWaterSplineCurveDefaults& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float DefaultDepth{}; // 0x0
        float DefaultWidth{}; // 0x4
        float DefaultVelocity{}; // 0x8
        float DefaultAudioIntensity{}; // 0xC

        // Functions.
    };


}

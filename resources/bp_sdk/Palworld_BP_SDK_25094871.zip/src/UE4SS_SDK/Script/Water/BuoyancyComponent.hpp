#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/Engine/ActorComponent.hpp>
#include <UE4SS_SDK/Script/Water/BuoyancyData.hpp>
#include <UE4SS_SDK/Script/Water/SphericalPontoon.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UPrimitiveComponent;
    class UWaterBodyComponent;

    // Super Size: 0xA0
    // Size: 0x208 (unaligned: 0x208, alignment: 0x8)
    class RC_UE4SS_SDK_API UBuoyancyComponent : public WSDK::UActorComponent
    {
    public:
        // Properties.
        TArray<FSphericalPontoon> Pontoons{}; // 0xA0
        FMulticastScriptDelegate OnEnteredWaterDelegate{}; // 0xB0
        FMulticastScriptDelegate OnExitedWaterDelegate{}; // 0xC0
        FBuoyancyData BuoyancyData{}; // 0xD0
        TArray<UWaterBodyComponent*> CurrentWaterBodyComponents{}; // 0x160
        UPrimitiveComponent* SimulatingComponent{}; // 0x170
        uint8 padding_1[0x90]{}; // 0x178

        // Functions.
        void OnPontoonExitedWater(FSphericalPontoon& Pontoon)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:OnPontoonExitedWater", 720)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Pontoon, FSphericalPontoon, 0x0)
        }
        void OnPontoonEnteredWater(FSphericalPontoon& Pontoon)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:OnPontoonEnteredWater", 720)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Pontoon, FSphericalPontoon, 0x0)
        }
        bool IsOverlappingWaterBody()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:IsOverlappingWaterBody", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        bool IsInWaterBody()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:IsInWaterBody", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        void GetLastWaterSurfaceInfo(FVector& OutWaterPlaneLocation, FVector& OutWaterPlaneNormal, FVector& OutWaterSurfacePosition, float& OutWaterDepth, int32& OutWaterBodyIdx, FVector& OutWaterVelocity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:GetLastWaterSurfaceInfo", 104)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterPlaneLocation, FVector, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterPlaneNormal, FVector, 0x18)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterSurfacePosition, FVector, 0x30)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterDepth, float, 0x48)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterBodyIdx, int32, 0x4C)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWaterVelocity, FVector, 0x50)
        }
        TArray<UWaterBodyComponent*> GetCurrentWaterBodyComponents()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.BuoyancyComponent:GetCurrentWaterBodyComponents", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UWaterBodyComponent*>, 0x0)
        }
    };


}

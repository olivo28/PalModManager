#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <UE4SS_SDK/Script/Water/EWaterBodyType.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AWaterBodyExclusionVolume;
    class AWaterBodyIsland;
    class UMaterialInstanceDynamic;
    class UMaterialInterface;
    class UWaterBodyComponent;
    class UWaterSplineComponent;
    class UWaterSplineMetadata;
    class UWaterWavesBase;

    // Super Size: 0x290
    // Size: 0x2C0 (unaligned: 0x2C0, alignment: 0x8)
    class RC_UE4SS_SDK_API AWaterBody : public WSDK::AActor
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x290
        UWaterSplineComponent* SplineComp{}; // 0x298
        UWaterSplineMetadata* WaterSplineMetadata{}; // 0x2A0
        UWaterBodyComponent* WaterBodyComponent{}; // 0x2A8
        int32 WaterBodyIndex{}; // 0x2B0
        EWaterBodyType WaterBodyType{}; // 0x2B4
        uint8 padding_2[0x3]{}; // 0x2B5
        UWaterWavesBase* WaterWaves{}; // 0x2B8

        // Functions.
        void SetWaterWaves(UWaterWavesBase* InWaterWaves)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:SetWaterWaves", 8)
            UE_COPY_PROPERTY_CUSTOM(InWaterWaves, UWaterWavesBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetWaterMaterial(UMaterialInterface* InMaterial)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:SetWaterMaterial", 8)
            UE_COPY_PROPERTY_CUSTOM(InMaterial, UMaterialInterface*, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnWaterBodyChanged(bool bShapeOrPositionChanged, bool bWeightmapSettingsChanged)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:OnWaterBodyChanged", 2)
            UE_COPY_PROPERTY_CUSTOM(bShapeOrPositionChanged, bool, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bWeightmapSettingsChanged, bool, 0x1)
            UE_CALL_FUNCTION()
        }
        FVector GetWaterVelocityVectorAtSplineInputKey(float InKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterVelocityVectorAtSplineInputKey", 32)
            UE_COPY_PROPERTY_CUSTOM(InKey, float, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector, 0x8)
        }
        float GetWaterVelocityAtSplineInputKey(float InKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterVelocityAtSplineInputKey", 8)
            UE_COPY_PROPERTY_CUSTOM(InKey, float, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x4)
        }
        UWaterSplineComponent* GetWaterSpline()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterSpline", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWaterSplineComponent*, 0x0)
        }
        UMaterialInstanceDynamic* GetWaterMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        EWaterBodyType GetWaterBodyType()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterBodyType", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(EWaterBodyType, 0x0)
        }
        UWaterBodyComponent* GetWaterBodyComponent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetWaterBodyComponent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UWaterBodyComponent*, 0x0)
        }
        UMaterialInstanceDynamic* GetRiverToOceanTransitionMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetRiverToOceanTransitionMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        UMaterialInstanceDynamic* GetRiverToLakeTransitionMaterialInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetRiverToLakeTransitionMaterialInstance", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UMaterialInstanceDynamic*, 0x0)
        }
        TArray<AWaterBodyIsland*> GetIslands()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetIslands", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<AWaterBodyIsland*>, 0x0)
        }
        TArray<AWaterBodyExclusionVolume*> GetExclusionVolumes()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetExclusionVolumes", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<AWaterBodyExclusionVolume*>, 0x0)
        }
        float GetAudioIntensityAtSplineInputKey(float InKey)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Water.WaterBody:GetAudioIntensityAtSplineInputKey", 8)
            UE_COPY_PROPERTY_CUSTOM(InKey, float, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x4)
        }
    };


}

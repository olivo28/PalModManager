#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBodyComponent.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UStaticMeshComponent;

    // Super Size: 0x1530
    // Size: 0x1540 (unaligned: 0x1540, alignment: 0x10)
    class RC_UE4SS_SDK_API UWaterBodyCustomComponent : public WSDK::UWaterBodyComponent
    {
    public:
        // Properties.
        UStaticMeshComponent* MeshComp{}; // 0x1530
        uint8 padding_1[0x8]{}; // 0x1538

        // Functions.
    };


}

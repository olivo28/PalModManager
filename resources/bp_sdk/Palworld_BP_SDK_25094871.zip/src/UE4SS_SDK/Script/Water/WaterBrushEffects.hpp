#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffectBlurring.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffectCurlNoise.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffectDisplacement.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffectSmoothBlending.hpp>
#include <UE4SS_SDK/Script/Water/WaterBrushEffectTerracing.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaterBrushEffects
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x60;
        }

        FWaterBrushEffects& operator=(const FWaterBrushEffects& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FWaterBrushEffectBlurring Blurring{}; // 0x0
        FWaterBrushEffectCurlNoise CurlNoise{}; // 0x8
        FWaterBrushEffectDisplacement Displacement{}; // 0x18
        FWaterBrushEffectSmoothBlending SmoothBlending{}; // 0x40
        FWaterBrushEffectTerracing Terracing{}; // 0x48
        uint8 padding_1[0x4]{}; // 0x5C

        // Functions.
    };


}

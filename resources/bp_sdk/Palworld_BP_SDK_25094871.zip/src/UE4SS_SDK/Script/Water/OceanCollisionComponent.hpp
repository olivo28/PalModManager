#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/PrimitiveComponent.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UBodySetup;

    // Super Size: 0x540
    // Size: 0x580 (unaligned: 0x580, alignment: 0x10)
    class RC_UE4SS_SDK_API UOceanCollisionComponent : public WSDK::UPrimitiveComponent
    {
    public:
        // Properties.
        UBodySetup* CachedBodySetup{}; // 0x538
        uint8 padding_1[0x40]{}; // 0x540

        // Functions.
    };


}

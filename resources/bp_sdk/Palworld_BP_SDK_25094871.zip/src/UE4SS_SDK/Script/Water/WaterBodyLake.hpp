#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Water/WaterBody.hpp>

namespace WSDK
{
    // Super Size: 0x2C0
    // Size: 0x2C0 (unaligned: 0x2C0, alignment: 0x8)
    class RC_UE4SS_SDK_API AWaterBodyLake : public WSDK::AWaterBody
    {
    public:
        // Properties.

        // Functions.
    };


}

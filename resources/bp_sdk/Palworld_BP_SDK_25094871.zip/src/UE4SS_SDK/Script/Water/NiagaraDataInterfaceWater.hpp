#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Niagara/NiagaraDataInterface.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UWaterBodyComponent;

    // Super Size: 0x38
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    class RC_UE4SS_SDK_API UNiagaraDataInterfaceWater : public WSDK::UNiagaraDataInterface
    {
    public:
        // Properties.
        UWaterBodyComponent* SourceBodyComponent{}; // 0x38

        // Functions.
    };


}

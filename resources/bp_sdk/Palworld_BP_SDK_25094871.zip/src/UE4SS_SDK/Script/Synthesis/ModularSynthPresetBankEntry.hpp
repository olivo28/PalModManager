#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ModularSynthPreset.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xF0 (unaligned: 0xF0, alignment: 0x8)
    struct RC_UE4SS_SDK_API FModularSynthPresetBankEntry
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xF0;
        }

        FModularSynthPresetBankEntry& operator=(const FModularSynthPresetBankEntry& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FString PresetName{}; // 0x0
        FModularSynthPreset Preset{}; // 0x10

        // Functions.
    };


}

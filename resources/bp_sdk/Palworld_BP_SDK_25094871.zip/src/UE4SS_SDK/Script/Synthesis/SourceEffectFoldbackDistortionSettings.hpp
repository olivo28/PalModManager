#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectFoldbackDistortionSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FSourceEffectFoldbackDistortionSettings& operator=(const FSourceEffectFoldbackDistortionSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float InputGainDb{}; // 0x0
        float ThresholdDb{}; // 0x4
        float OutputGainDb{}; // 0x8

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/SynthComponent.hpp>
#include <UE4SS_SDK/Script/Synthesis/CurveInterpolationType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOType.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMonoWaveTableSynthPreset;

    // Super Size: 0x790
    // Size: 0xEE0 (unaligned: 0xEE0, alignment: 0x10)
    class RC_UE4SS_SDK_API USynthComponentMonoWaveTable : public WSDK::USynthComponent
    {
    public:
        // Properties.
        FMulticastScriptDelegate OnTableAltered{}; // 0x790
        FMulticastScriptDelegate OnNumTablesChanged{}; // 0x7A0
        UMonoWaveTableSynthPreset* CurrentPreset{}; // 0x7B0
        uint8 padding_1[0x728]{}; // 0x7B8

        // Functions.
        void SetWaveTablePosition(float InPosition)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetWaveTablePosition", 4)
            UE_COPY_PROPERTY_CUSTOM(InPosition, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSustainPedalState(bool InSustainPedalState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetSustainPedalState", 1)
            UE_COPY_PROPERTY_CUSTOM(InSustainPedalState, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPosLfoType(ESynthLFOType InLfoType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPosLfoType", 1)
            UE_COPY_PROPERTY_CUSTOM(InLfoType, ESynthLFOType, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPosLfoFrequency(float InLfoFrequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPosLfoFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(InLfoFrequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPosLfoDepth(float InLfoDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPosLfoDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InLfoDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeSustainGain(float InSustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(InSustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeReleaseTime(float InReleaseTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeReleaseTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InReleaseTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeInvert(bool bInInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeDecayTime(float InDecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InDecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeBiasInvert(bool bInBiasInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeBiasInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInBiasInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeBiasDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeBiasDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPositionEnvelopeAttackTime(float InAttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetPositionEnvelopeAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InAttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetLowPassFilterResonance(float InNewQ)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetLowPassFilterResonance", 4)
            UE_COPY_PROPERTY_CUSTOM(InNewQ, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFrequencyWithMidiNote(float InMidiNote)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFrequencyWithMidiNote", 4)
            UE_COPY_PROPERTY_CUSTOM(InMidiNote, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFrequencyPitchBend(float FrequencyOffsetCents)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFrequencyPitchBend", 4)
            UE_COPY_PROPERTY_CUSTOM(FrequencyOffsetCents, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFrequency(float FrequencyHz)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(FrequencyHz, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeSustainGain(float InSustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(InSustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeReleaseTime(float InReleaseTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeReleaseTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InReleaseTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopenDecayTime(float InDecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopenDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InDecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeInvert(bool bInInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeBiasInvert(bool bInBiasInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeBiasInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInBiasInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeBiasDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeBiasDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterEnvelopeAttackTime(float InAttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetFilterEnvelopeAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InAttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        bool SetCurveValue(int32 TableIndex, int32 KeyframeIndex, float NewValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetCurveValue", 13)
            UE_COPY_PROPERTY_CUSTOM(TableIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(KeyframeIndex, int32, 0x4)
            UE_COPY_PROPERTY_CUSTOM(NewValue, float, 0x8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xC)
        }
        bool SetCurveTangent(int32 TableIndex, float InNewTangent)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetCurveTangent", 9)
            UE_COPY_PROPERTY_CUSTOM(TableIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InNewTangent, float, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool SetCurveInterpolationType(CurveInterpolationType InterpolationType, int32 TableIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetCurveInterpolationType", 9)
            UE_COPY_PROPERTY_CUSTOM(InterpolationType, CurveInterpolationType, 0x0)
            UE_COPY_PROPERTY_CUSTOM(TableIndex, int32, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        void SetAmpEnvelopeSustainGain(float InSustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(InSustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeReleaseTime(float InReleaseTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeReleaseTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InReleaseTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeInvert(bool bInInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeDecayTime(float InDecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InDecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeBiasInvert(bool bInBiasInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeBiasInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInBiasInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeBiasDepth(float InDepth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeBiasDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(InDepth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAmpEnvelopeAttackTime(float InAttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:SetAmpEnvelopeAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(InAttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void RefreshWaveTable(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:RefreshWaveTable", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void RefreshAllWaveTables()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:RefreshAllWaveTables", 0)
            UE_CALL_FUNCTION()
        }
        void NoteOn(float InMidiNote, float InVelocity)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:NoteOn", 8)
            UE_COPY_PROPERTY_CUSTOM(InMidiNote, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InVelocity, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void NoteOff(float InMidiNote)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:NoteOff", 4)
            UE_COPY_PROPERTY_CUSTOM(InMidiNote, float, 0x0)
            UE_CALL_FUNCTION()
        }
        int32 GetNumTableEntries()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:GetNumTableEntries", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        int32 GetMaxTableIndex()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:GetMaxTableIndex", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        TArray<float> GetKeyFrameValuesForTable(float TableIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:GetKeyFrameValuesForTable", 24)
            UE_COPY_PROPERTY_CUSTOM(TableIndex, float, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<float>, 0x8)
        }
        float GetCurveTangent(int32 TableIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentMonoWaveTable:GetCurveTangent", 8)
            UE_COPY_PROPERTY_CUSTOM(TableIndex, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x4)
        }
    };


}

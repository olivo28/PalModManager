#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESubmixFilterAlgorithm : uint8
    {
        OnePole,
        StateVariable,
        Ladder,
        Count,
    };
}

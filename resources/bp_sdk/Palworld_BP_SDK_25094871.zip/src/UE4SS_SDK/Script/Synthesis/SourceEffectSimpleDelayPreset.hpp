#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectSimpleDelaySettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xC0 (unaligned: 0xC0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectSimpleDelayPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x40]{}; // 0x68
        FSourceEffectSimpleDelaySettings Settings{}; // 0xA8

        // Functions.
        void SetSettings(FSourceEffectSimpleDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectSimpleDelayPreset:SetSettings", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectSimpleDelaySettings, 0x0)
        }
    };


}

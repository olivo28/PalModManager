#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectMotionFilterModSource.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectMotionFilterModulationSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x40;
        }

        FSourceEffectMotionFilterModulationSettings& operator=(const FSourceEffectMotionFilterModulationSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESourceEffectMotionFilterModSource ModulationSource{}; // 0x0
        uint8 padding_1[0x7]{}; // 0x1
        FVector2D ModulationInputRange{}; // 0x8
        FVector2D ModulationOutputMinimumRange{}; // 0x18
        FVector2D ModulationOutputMaximumRange{}; // 0x28
        float UpdateEaseMS{}; // 0x38
        uint8 padding_2[0x4]{}; // 0x3C

        // Functions.
    };


}

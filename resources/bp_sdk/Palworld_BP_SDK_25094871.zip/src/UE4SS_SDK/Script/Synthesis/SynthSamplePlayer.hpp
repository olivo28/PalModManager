#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/SynthComponent.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESamplePlayerSeekType.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class USoundWave;

    // Super Size: 0x790
    // Size: 0x8C0 (unaligned: 0x8C0, alignment: 0x10)
    class RC_UE4SS_SDK_API USynthSamplePlayer : public WSDK::USynthComponent
    {
    public:
        // Properties.
        USoundWave* SoundWave{}; // 0x790
        FMulticastScriptDelegate OnSampleLoaded{}; // 0x798
        FMulticastScriptDelegate OnSamplePlaybackProgress{}; // 0x7A8
        uint8 padding_1[0x108]{}; // 0x7B8

        // Functions.
        void SetSoundWave(USoundWave* InSoundWave)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:SetSoundWave", 8)
            UE_COPY_PROPERTY_CUSTOM(InSoundWave, USoundWave*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrubTimeWidth(float InScrubTimeWidthSec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:SetScrubTimeWidth", 4)
            UE_COPY_PROPERTY_CUSTOM(InScrubTimeWidthSec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrubMode(bool bScrubMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:SetScrubMode", 1)
            UE_COPY_PROPERTY_CUSTOM(bScrubMode, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPitch(float InPitch, float TimeSec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:SetPitch", 8)
            UE_COPY_PROPERTY_CUSTOM(InPitch, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(TimeSec, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SeekToTime(float TimeSec, ESamplePlayerSeekType SeekType, bool bWrap)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:SeekToTime", 6)
            UE_COPY_PROPERTY_CUSTOM(TimeSec, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(SeekType, ESamplePlayerSeekType, 0x4)
            UE_COPY_PROPERTY_CUSTOM(bWrap, bool, 0x5)
            UE_CALL_FUNCTION()
        }
        bool IsLoaded()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:IsLoaded", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        float GetSampleDuration()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:GetSampleDuration", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetCurrentPlaybackProgressTime()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:GetCurrentPlaybackProgressTime", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetCurrentPlaybackProgressPercent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthSamplePlayer:GetCurrentPlaybackProgressPercent", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/Synthesis/ModularSynthPresetBankEntry.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UModularSynthPresetBank : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TArray<FModularSynthPresetBankEntry> Presets{}; // 0x28

        // Functions.
    };


}

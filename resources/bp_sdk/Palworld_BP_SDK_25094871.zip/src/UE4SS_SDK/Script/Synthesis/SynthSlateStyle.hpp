#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateWidgetStyle.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthSlateColorStyle.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthSlateSizeType.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x10 (unaligned: 0x10, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSynthSlateStyle : public WSDK::FSlateWidgetStyle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FSynthSlateStyle& operator=(const FSynthSlateStyle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESynthSlateSizeType SizeType{}; // 0x8
        ESynthSlateColorStyle ColorStyle{}; // 0x9
        uint8 padding_1[0x6]{}; // 0xA

        // Functions.
    };


}

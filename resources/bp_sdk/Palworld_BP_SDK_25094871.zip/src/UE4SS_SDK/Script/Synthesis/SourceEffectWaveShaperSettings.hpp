#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectWaveShaperSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FSourceEffectWaveShaperSettings& operator=(const FSourceEffectWaveShaperSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Amount{}; // 0x0
        float OutputGainDb{}; // 0x4

        // Functions.
    };


}

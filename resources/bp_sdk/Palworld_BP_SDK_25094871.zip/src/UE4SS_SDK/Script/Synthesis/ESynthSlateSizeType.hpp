#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthSlateSizeType : uint8
    {
        Small,
        Medium,
        Large,
        Count,
    };
}

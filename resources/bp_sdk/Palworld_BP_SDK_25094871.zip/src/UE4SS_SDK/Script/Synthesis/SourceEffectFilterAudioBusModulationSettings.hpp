#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectFilterParam.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioBus;

    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectFilterAudioBusModulationSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FSourceEffectFilterAudioBusModulationSettings& operator=(const FSourceEffectFilterAudioBusModulationSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        UAudioBus* AudioBus{}; // 0x0
        int32 EnvelopeFollowerAttackTimeMsec{}; // 0x8
        int32 EnvelopeFollowerReleaseTimeMsec{}; // 0xC
        float EnvelopeGainMultiplier{}; // 0x10
        ESourceEffectFilterParam FilterParam{}; // 0x14
        uint8 padding_1[0x3]{}; // 0x15
        float MinFrequencyModulation{}; // 0x18
        float MaxFrequencyModulation{}; // 0x1C
        float MinResonanceModulation{}; // 0x20
        float MaxResonanceModulation{}; // 0x24

        // Functions.
    };


}

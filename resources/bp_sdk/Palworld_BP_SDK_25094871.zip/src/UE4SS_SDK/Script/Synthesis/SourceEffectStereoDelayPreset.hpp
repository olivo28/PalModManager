#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectStereoDelaySettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xD8 (unaligned: 0xD8, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectStereoDelayPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x4C]{}; // 0x68
        FSourceEffectStereoDelaySettings Settings{}; // 0xB4

        // Functions.
        void SetSettings(FSourceEffectStereoDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectStereoDelayPreset:SetSettings", 36)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectStereoDelaySettings, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ETapLineMode.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x4)
    struct RC_UE4SS_SDK_API FTapDelayInfo
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FTapDelayInfo& operator=(const FTapDelayInfo& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ETapLineMode TapLineMode{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float DelayLength{}; // 0x4
        float Gain{}; // 0x8
        int32 OutputChannel{}; // 0xC
        float PanInDegrees{}; // 0x10
        int32 TapId{}; // 0x14

        // Functions.
    };


}

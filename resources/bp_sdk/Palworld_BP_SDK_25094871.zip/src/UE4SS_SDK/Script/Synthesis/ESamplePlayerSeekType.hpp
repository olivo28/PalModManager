#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESamplePlayerSeekType : uint8
    {
        FromBeginning,
        FromCurrentPosition,
        FromEnd,
        Count,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectEQBand
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FSourceEffectEQBand& operator=(const FSourceEffectEQBand& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Frequency{}; // 0x0
        float Bandwidth{}; // 0x4
        float GainDb{}; // 0x8
        uint8 bEnabled : 1{}; // 0xC (0x1)
        uint8 padding_1[0x3]{}; // 0xD

        // Functions.
    };


}

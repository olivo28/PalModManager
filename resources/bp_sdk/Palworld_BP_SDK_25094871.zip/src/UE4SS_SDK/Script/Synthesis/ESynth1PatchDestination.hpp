#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynth1PatchDestination : uint8
    {
        Osc1Gain,
        Osc1Frequency,
        Osc1Pulsewidth,
        Osc2Gain,
        Osc2Frequency,
        Osc2Pulsewidth,
        FilterFrequency,
        FilterQ,
        Gain,
        Pan,
        LFO1Frequency,
        LFO1Gain,
        LFO2Frequency,
        LFO2Gain,
        Count,
    };
}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthLFOMode : uint8
    {
        Sync,
        OneShot,
        Free,
        Count,
    };
}

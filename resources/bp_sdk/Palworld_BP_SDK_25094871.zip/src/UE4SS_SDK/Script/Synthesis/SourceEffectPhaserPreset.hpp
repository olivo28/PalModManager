#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectPhaserSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xB0 (unaligned: 0xB0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectPhaserPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x38]{}; // 0x68
        FSourceEffectPhaserSettings Settings{}; // 0xA0

        // Functions.
        void SetSettings(FSourceEffectPhaserSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectPhaserPreset:SetSettings", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectPhaserSettings, 0x0)
        }
    };


}

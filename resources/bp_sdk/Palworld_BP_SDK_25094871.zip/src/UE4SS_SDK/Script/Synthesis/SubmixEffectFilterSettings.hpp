#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixFilterAlgorithm.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixFilterType.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSubmixEffectFilterSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FSubmixEffectFilterSettings& operator=(const FSubmixEffectFilterSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESubmixFilterType FilterType{}; // 0x0
        ESubmixFilterAlgorithm FilterAlgorithm{}; // 0x1
        uint8 padding_1[0x2]{}; // 0x2
        float FilterFrequency{}; // 0x4
        float FilterQ{}; // 0x8

        // Functions.
    };


}

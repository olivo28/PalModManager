#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectMotionFilterCircuit.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectMotionFilterType.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectIndividualFilterSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FSourceEffectIndividualFilterSettings& operator=(const FSourceEffectIndividualFilterSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESourceEffectMotionFilterCircuit FilterCircuit{}; // 0x0
        ESourceEffectMotionFilterType FilterType{}; // 0x1
        uint8 padding_1[0x2]{}; // 0x2
        float CutoffFrequency{}; // 0x4
        float FilterQ{}; // 0x8

        // Functions.
    };


}

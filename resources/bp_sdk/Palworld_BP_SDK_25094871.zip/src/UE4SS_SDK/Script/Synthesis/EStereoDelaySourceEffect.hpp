#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EStereoDelaySourceEffect : uint8
    {
        Normal,
        Cross,
        PingPong,
        Count,
    };
}

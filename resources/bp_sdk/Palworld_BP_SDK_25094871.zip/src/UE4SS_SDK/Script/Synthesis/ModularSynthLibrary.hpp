#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/Synthesis/ModularSynthPreset.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    class UModularSynthPresetBank;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UModularSynthLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static void AddModularSynthPresetToBankAsset(UModularSynthPresetBank* InBank, FModularSynthPreset& Preset, FString& PresetName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthLibrary:AddModularSynthPresetToBankAsset", 248)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__ModularSynthLibrary")
            UE_COPY_PROPERTY_CUSTOM(InBank, UModularSynthPresetBank*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(PresetName, FString, 0xE8)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Preset, FModularSynthPreset, 0x8)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/ESubmixEffectDynamicsChannelLinkMode.hpp>
#include <UE4SS_SDK/Script/AudioMixer/ESubmixEffectDynamicsKeySource.hpp>
#include <UE4SS_SDK/Script/AudioMixer/ESubmixEffectDynamicsPeakMode.hpp>
#include <UE4SS_SDK/Script/AudioMixer/ESubmixEffectDynamicsProcessorType.hpp>
#include <UE4SS_SDK/Script/Synthesis/DynamicsBandSettings.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioBus;
    class USoundSubmix;

    // Super Size: 0x0
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSubmixEffectMultibandCompressorSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x38;
        }

        FSubmixEffectMultibandCompressorSettings& operator=(const FSubmixEffectMultibandCompressorSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESubmixEffectDynamicsProcessorType DynamicsProcessorType{}; // 0x0
        ESubmixEffectDynamicsPeakMode PeakMode{}; // 0x1
        ESubmixEffectDynamicsChannelLinkMode LinkMode{}; // 0x2
        uint8 padding_1[0x1]{}; // 0x3
        float LookAheadMsec{}; // 0x4
        bool bAnalogMode{}; // 0x8
        bool bFourPole{}; // 0x9
        bool bBypass{}; // 0xA
        ESubmixEffectDynamicsKeySource KeySource{}; // 0xB
        uint8 padding_2[0x4]{}; // 0xC
        UAudioBus* ExternalAudioBus{}; // 0x10
        USoundSubmix* ExternalSubmix{}; // 0x18
        float KeyGainDb{}; // 0x20
        bool bKeyAudition{}; // 0x24
        uint8 padding_3[0x3]{}; // 0x25
        TArray<FDynamicsBandSettings> Bands{}; // 0x28

        // Functions.
    };


}

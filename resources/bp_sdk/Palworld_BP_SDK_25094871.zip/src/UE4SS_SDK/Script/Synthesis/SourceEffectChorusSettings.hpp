#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundModulationDestinationSettings.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x258 (unaligned: 0x258, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectChorusSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x258;
        }

        FSourceEffectChorusSettings& operator=(const FSourceEffectChorusSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Depth{}; // 0x0
        float Frequency{}; // 0x4
        float Feedback{}; // 0x8
        float WetLevel{}; // 0xC
        float DryLevel{}; // 0x10
        float Spread{}; // 0x14
        FSoundModulationDestinationSettings DepthModulation{}; // 0x18
        FSoundModulationDestinationSettings FrequencyModulation{}; // 0x78
        FSoundModulationDestinationSettings FeedbackModulation{}; // 0xD8
        FSoundModulationDestinationSettings WetModulation{}; // 0x138
        FSoundModulationDestinationSettings DryModulation{}; // 0x198
        FSoundModulationDestinationSettings SpreadModulation{}; // 0x1F8

        // Functions.
    };


}

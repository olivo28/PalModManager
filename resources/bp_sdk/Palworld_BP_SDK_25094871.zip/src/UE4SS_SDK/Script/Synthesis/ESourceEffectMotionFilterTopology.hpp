#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectMotionFilterTopology : uint8
    {
        SerialMode,
        ParallelMode,
        Count,
    };
}

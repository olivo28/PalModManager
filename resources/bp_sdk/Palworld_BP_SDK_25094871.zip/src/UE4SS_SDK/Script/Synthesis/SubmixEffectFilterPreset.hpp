#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixFilterAlgorithm.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixFilterType.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectFilterSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectFilterPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        uint8 padding_1[0x34]{}; // 0x68
        FSubmixEffectFilterSettings Settings{}; // 0x9C

        // Functions.
        void SetSettings(FSubmixEffectFilterSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetSettings", 12)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectFilterSettings, 0x0)
        }
        void SetFilterType(ESubmixFilterType InType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterType", 1)
            UE_COPY_PROPERTY_CUSTOM(InType, ESubmixFilterType, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterQMod(float InQ)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterQMod", 4)
            UE_COPY_PROPERTY_CUSTOM(InQ, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterQ(float InQ)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterQ", 4)
            UE_COPY_PROPERTY_CUSTOM(InQ, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterCutoffFrequencyMod(float InFrequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterCutoffFrequencyMod", 4)
            UE_COPY_PROPERTY_CUSTOM(InFrequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterCutoffFrequency(float InFrequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterCutoffFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(InFrequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterAlgorithm(ESubmixFilterAlgorithm InAlgorithm)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectFilterPreset:SetFilterAlgorithm", 1)
            UE_COPY_PROPERTY_CUSTOM(InAlgorithm, ESubmixFilterAlgorithm, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

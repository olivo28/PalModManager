#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateWidgetStyle.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthKnobSize.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x360 (unaligned: 0x360, alignment: 0x10)
    struct RC_UE4SS_SDK_API FSynthKnobStyle : public WSDK::FSlateWidgetStyle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x360;
        }

        FSynthKnobStyle& operator=(const FSynthKnobStyle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FSlateBrush LargeKnob{}; // 0x10
        FSlateBrush LargeKnobOverlay{}; // 0xE0
        FSlateBrush MediumKnob{}; // 0x1B0
        FSlateBrush MediumKnobOverlay{}; // 0x280
        float MinValueAngle{}; // 0x350
        float MaxValueAngle{}; // 0x354
        ESynthKnobSize KnobSize{}; // 0x358
        uint8 padding_2[0x7]{}; // 0x359

        // Functions.
    };


}

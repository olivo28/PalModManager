#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSubmixEffectDelaySettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FSubmixEffectDelaySettings& operator=(const FSubmixEffectDelaySettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float MaximumDelayLength{}; // 0x0
        float InterpolationTime{}; // 0x4
        float DelayLength{}; // 0x8

        // Functions.
    };


}

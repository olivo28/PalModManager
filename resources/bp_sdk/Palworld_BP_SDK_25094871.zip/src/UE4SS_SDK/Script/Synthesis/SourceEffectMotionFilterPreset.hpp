#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectMotionFilterSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0x180 (unaligned: 0x180, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectMotionFilterPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0xA0]{}; // 0x68
        FSourceEffectMotionFilterSettings Settings{}; // 0x108

        // Functions.
        void SetSettings(FSourceEffectMotionFilterSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectMotionFilterPreset:SetSettings", 120)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectMotionFilterSettings, 0x0)
        }
    };


}

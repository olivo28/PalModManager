#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectStereoDelaySettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xD8 (unaligned: 0xD8, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectStereoDelayPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        uint8 padding_1[0x4C]{}; // 0x68
        FSubmixEffectStereoDelaySettings Settings{}; // 0xB4

        // Functions.
        void SetSettings(FSubmixEffectStereoDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectStereoDelayPreset:SetSettings", 36)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectStereoDelaySettings, 0x0)
        }
    };


}

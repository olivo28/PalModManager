#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectBitCrusherBaseSettings.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectBitCrusherSettings.hpp>
#include <Unreal/Core/Containers/Set.hpp>

namespace WSDK
{
    class USoundModulatorBase;

    // Super Size: 0x68
    // Size: 0x230 (unaligned: 0x230, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectBitCrusherPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0xF8]{}; // 0x68
        FSourceEffectBitCrusherSettings Settings{}; // 0x160

        // Functions.
        void SetSettings(FSourceEffectBitCrusherBaseSettings& Settings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetSettings", 8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Settings, FSourceEffectBitCrusherBaseSettings, 0x0)
        }
        void SetSampleRateModulators(TSet<USoundModulatorBase*>& InModulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetSampleRateModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InModulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetSampleRateModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetSampleRateModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSampleRate(float SampleRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetSampleRate", 4)
            UE_COPY_PROPERTY_CUSTOM(SampleRate, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModulationSettings(FSourceEffectBitCrusherSettings& ModulationSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetModulationSettings", 208)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ModulationSettings, FSourceEffectBitCrusherSettings, 0x0)
        }
        void SetBits(float Bits)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetBits", 4)
            UE_COPY_PROPERTY_CUSTOM(Bits, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetBitModulators(TSet<USoundModulatorBase*>& InModulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetBitModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InModulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetBitModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectBitCrusherPreset:SetBitModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

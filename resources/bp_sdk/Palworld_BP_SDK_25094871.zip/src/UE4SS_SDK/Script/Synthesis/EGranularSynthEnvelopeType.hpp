#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EGranularSynthEnvelopeType : uint8
    {
        Rectangular,
        Triangle,
        DownwardTriangle,
        UpwardTriangle,
        ExponentialDecay,
        ExponentialIncrease,
        Gaussian,
        Hanning,
        Lanczos,
        Cosine,
        CosineSquared,
        Welch,
        Blackman,
        BlackmanHarris,
        Count,
    };
}

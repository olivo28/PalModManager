#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixEffectConvolutionReverbBlockSize.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectConvolutionReverbSettings.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioImpulseResponse;

    // Super Size: 0x68
    // Size: 0xC0 (unaligned: 0xC0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectConvolutionReverbPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        UAudioImpulseResponse* ImpulseResponse{}; // 0x68
        FSourceEffectConvolutionReverbSettings Settings{}; // 0x70
        ESubmixEffectConvolutionReverbBlockSize blockSize{}; // 0x80
        bool bEnableHardwareAcceleration{}; // 0x81
        uint8 padding_1[0x3E]{}; // 0x82

        // Functions.
        void SetSettings(FSourceEffectConvolutionReverbSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectConvolutionReverbPreset:SetSettings", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectConvolutionReverbSettings, 0x0)
        }
        void SetImpulseResponse(UAudioImpulseResponse* InImpulseResponse)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectConvolutionReverbPreset:SetImpulseResponse", 8)
            UE_COPY_PROPERTY_CUSTOM(InImpulseResponse, UAudioImpulseResponse*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectMotionFilterModDestination.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectMotionFilterTopology.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectIndividualFilterSettings.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectMotionFilterModulationSettings.hpp>
#include <Unreal/Core/Containers/Map.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x78 (unaligned: 0x78, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectMotionFilterSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x78;
        }

        FSourceEffectMotionFilterSettings& operator=(const FSourceEffectMotionFilterSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESourceEffectMotionFilterTopology MotionFilterTopology{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float MotionFilterMix{}; // 0x4
        FSourceEffectIndividualFilterSettings FilterASettings{}; // 0x8
        FSourceEffectIndividualFilterSettings FilterBSettings{}; // 0x14
        TMap<ESourceEffectMotionFilterModDestination, FSourceEffectMotionFilterModulationSettings> ModulationMappings{}; // 0x20
        float DryVolumeDb{}; // 0x70
        uint8 padding_2[0x4]{}; // 0x74

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/EEnvelopeFollowerPeakMode.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectEnvelopeFollowerSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FSourceEffectEnvelopeFollowerSettings& operator=(const FSourceEffectEnvelopeFollowerSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float AttackTime{}; // 0x0
        float ReleaseTime{}; // 0x4
        EEnvelopeFollowerPeakMode PeakMode{}; // 0x8
        bool bIsAnalogMode{}; // 0x9
        uint8 padding_1[0x2]{}; // 0xA

        // Functions.
    };


}

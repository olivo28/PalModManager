#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectMotionFilterModDestination : uint8
    {
        FilterACutoffFrequency,
        FilterAResonance,
        FilterAOutputVolumeDB,
        FilterBCutoffFrequency,
        FilterBResonance,
        FilterBOutputVolumeDB,
        FilterMix,
        Count,
    };
}

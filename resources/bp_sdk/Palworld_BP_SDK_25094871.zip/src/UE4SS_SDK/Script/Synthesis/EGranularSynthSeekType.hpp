#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EGranularSynthSeekType : uint8
    {
        FromBeginning,
        FromCurrentPosition,
        Count,
    };
}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EStereoChannelMode : uint8
    {
        MidSide,
        LeftRight,
        count,
    };
}

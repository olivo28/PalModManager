#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectRingModulationSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xD0 (unaligned: 0xD0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectRingModulationPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x48]{}; // 0x68
        FSourceEffectRingModulationSettings Settings{}; // 0xB0

        // Functions.
        void SetSettings(FSourceEffectRingModulationSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectRingModulationPreset:SetSettings", 32)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectRingModulationSettings, 0x0)
        }
    };


}

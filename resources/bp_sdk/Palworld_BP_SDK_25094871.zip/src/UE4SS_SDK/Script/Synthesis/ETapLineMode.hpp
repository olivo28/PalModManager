#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETapLineMode : uint8
    {
        SendToChannel,
        Panning,
        Disabled,
    };
}

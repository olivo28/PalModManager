#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectDynamicsPeakMode : uint8
    {
        MeanSquared,
        RootMeanSquared,
        Peak,
        Count,
    };
}

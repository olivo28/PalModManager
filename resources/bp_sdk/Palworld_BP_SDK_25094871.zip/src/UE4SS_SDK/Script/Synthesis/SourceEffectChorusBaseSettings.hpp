#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectChorusBaseSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FSourceEffectChorusBaseSettings& operator=(const FSourceEffectChorusBaseSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float Depth{}; // 0x0
        float Frequency{}; // 0x4
        float Feedback{}; // 0x8
        float WetLevel{}; // 0xC
        float DryLevel{}; // 0x10
        float Spread{}; // 0x14

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x4)
    struct RC_UE4SS_SDK_API FDynamicsBandSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FDynamicsBandSettings& operator=(const FDynamicsBandSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float CrossoverTopFrequency{}; // 0x0
        float AttackTimeMsec{}; // 0x4
        float ReleaseTimeMsec{}; // 0x8
        float ThresholdDb{}; // 0xC
        float Ratio{}; // 0x10
        float KneeBandwidthDb{}; // 0x14
        float InputGainDb{}; // 0x18
        float OutputGainDb{}; // 0x1C

        // Functions.
    };


}

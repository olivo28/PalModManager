#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectDynamicsPeakMode.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectDynamicsProcessorType.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectDynamicsProcessorSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FSourceEffectDynamicsProcessorSettings& operator=(const FSourceEffectDynamicsProcessorSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESourceEffectDynamicsProcessorType DynamicsProcessorType{}; // 0x0
        ESourceEffectDynamicsPeakMode PeakMode{}; // 0x1
        uint8 padding_1[0x2]{}; // 0x2
        float LookAheadMsec{}; // 0x4
        float AttackTimeMsec{}; // 0x8
        float ReleaseTimeMsec{}; // 0xC
        float ThresholdDb{}; // 0x10
        float Ratio{}; // 0x14
        float KneeBandwidthDb{}; // 0x18
        float InputGainDb{}; // 0x1C
        float OutputGainDb{}; // 0x20
        uint8 bStereoLinked : 1{}; // 0x24 (0x1)
        uint8 bAnalogMode : 1{}; // 0x24 (0x2)
        uint8 padding_2[0x3]{}; // 0x25

        // Functions.
    };


}

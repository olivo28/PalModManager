#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynth1PatchSource : uint8
    {
        LFO1,
        LFO2,
        Envelope,
        BiasEnvelope,
        Count,
    };
}

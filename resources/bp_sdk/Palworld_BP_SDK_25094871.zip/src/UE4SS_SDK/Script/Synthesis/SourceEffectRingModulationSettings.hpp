#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ERingModulatorTypeSourceEffect.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioBus;

    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectRingModulationSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FSourceEffectRingModulationSettings& operator=(const FSourceEffectRingModulationSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ERingModulatorTypeSourceEffect ModulatorType{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float Frequency{}; // 0x4
        float Depth{}; // 0x8
        float DryLevel{}; // 0xC
        float WetLevel{}; // 0x10
        uint8 padding_2[0x4]{}; // 0x14
        UAudioBus* AudioBusModulator{}; // 0x18

        // Functions.
    };


}

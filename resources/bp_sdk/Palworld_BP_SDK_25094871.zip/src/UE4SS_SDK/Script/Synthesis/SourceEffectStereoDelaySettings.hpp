#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/EStereoDelayFiltertype.hpp>
#include <UE4SS_SDK/Script/Synthesis/EStereoDelaySourceEffect.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x24 (unaligned: 0x24, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectStereoDelaySettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x24;
        }

        FSourceEffectStereoDelaySettings& operator=(const FSourceEffectStereoDelaySettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EStereoDelaySourceEffect DelayMode{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float DelayTimeMsec{}; // 0x4
        float Feedback{}; // 0x8
        float DelayRatio{}; // 0xC
        float WetLevel{}; // 0x10
        float DryLevel{}; // 0x14
        bool bFilterEnabled{}; // 0x18
        EStereoDelayFiltertype FilterType{}; // 0x19
        uint8 padding_2[0x2]{}; // 0x1A
        float FilterFrequency{}; // 0x1C
        float FilterQ{}; // 0x20

        // Functions.
    };


}

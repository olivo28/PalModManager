#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class CurveInterpolationType : uint8
    {
        AUTOINTERP,
        LINEAR,
        CONSTANT,
    };
}

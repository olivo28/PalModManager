#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectDelaySettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xB8 (unaligned: 0xB8, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectDelayPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        uint8 padding_1[0x34]{}; // 0x68
        FSubmixEffectDelaySettings Settings{}; // 0x9C
        FSubmixEffectDelaySettings DynamicSettings{}; // 0xA8
        uint8 padding_2[0x4]{}; // 0xB4

        // Functions.
        void SetSettings(FSubmixEffectDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayPreset:SetSettings", 12)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectDelaySettings, 0x0)
        }
        void SetInterpolationTime(float Time)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayPreset:SetInterpolationTime", 4)
            UE_COPY_PROPERTY_CUSTOM(Time, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDelay(float Length)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayPreset:SetDelay", 4)
            UE_COPY_PROPERTY_CUSTOM(Length, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDefaultSettings(FSubmixEffectDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayPreset:SetDefaultSettings", 12)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectDelaySettings, 0x0)
        }
        float GetMaxDelayInMilliseconds()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayPreset:GetMaxDelayInMilliseconds", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

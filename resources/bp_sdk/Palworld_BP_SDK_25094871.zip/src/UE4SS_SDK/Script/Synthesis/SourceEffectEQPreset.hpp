#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectEQSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xB0 (unaligned: 0xB0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectEQPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x38]{}; // 0x68
        FSourceEffectEQSettings Settings{}; // 0xA0

        // Functions.
        void SetSettings(FSourceEffectEQSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectEQPreset:SetSettings", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectEQSettings, 0x0)
        }
    };


}

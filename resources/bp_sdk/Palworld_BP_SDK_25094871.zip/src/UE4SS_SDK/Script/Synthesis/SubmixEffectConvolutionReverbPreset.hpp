#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESubmixEffectConvolutionReverbBlockSize.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectConvolutionReverbSettings.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioImpulseResponse;

    // Super Size: 0x68
    // Size: 0x100 (unaligned: 0x100, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectConvolutionReverbPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        UAudioImpulseResponse* ImpulseResponse{}; // 0x68
        FSubmixEffectConvolutionReverbSettings Settings{}; // 0x70
        ESubmixEffectConvolutionReverbBlockSize blockSize{}; // 0xA0
        bool bEnableHardwareAcceleration{}; // 0xA1
        uint8 padding_1[0x5E]{}; // 0xA2

        // Functions.
        void SetSettings(FSubmixEffectConvolutionReverbSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectConvolutionReverbPreset:SetSettings", 48)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectConvolutionReverbSettings, 0x0)
        }
        void SetImpulseResponse(UAudioImpulseResponse* InImpulseResponse)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectConvolutionReverbPreset:SetImpulseResponse", 8)
            UE_COPY_PROPERTY_CUSTOM(InImpulseResponse, UAudioImpulseResponse*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

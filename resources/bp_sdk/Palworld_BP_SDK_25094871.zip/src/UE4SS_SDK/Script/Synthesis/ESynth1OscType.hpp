#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynth1OscType : uint8
    {
        Sine,
        Saw,
        Triangle,
        Square,
        Noise,
        Count,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/SynthKnobStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x580 (unaligned: 0x580, alignment: 0x10)
    class RC_UE4SS_SDK_API USynthKnob : public WSDK::UWidget
    {
    public:
        // Properties.
        float Value{}; // 0x150
        float StepSize{}; // 0x154
        float MouseSpeed{}; // 0x158
        float MouseFineTuneSpeed{}; // 0x15C
        uint8 ShowTooltipInfo : 1{}; // 0x160 (0x1)
        uint8 padding_1 : 1{}; // 0x160 (0x2)
        uint8 padding_2 : 1{}; // 0x160 (0x4)
        uint8 padding_3 : 1{}; // 0x160 (0x8)
        uint8 padding_4 : 1{}; // 0x160 (0x10)
        uint8 padding_5 : 1{}; // 0x160 (0x20)
        uint8 padding_6 : 1{}; // 0x160 (0x40)
        uint8 padding_7 : 1{}; // 0x160 (0x80)
        uint8 padding_8[0x7]{}; // 0x161
        FText ParameterName{}; // 0x168
        FText ParameterUnits{}; // 0x180
        FScriptDelegate ValueDelegate{}; // 0x198
        uint8 padding_9[0x8]{}; // 0x1A8
        FSynthKnobStyle WidgetStyle{}; // 0x1B0
        bool Locked{}; // 0x510
        bool IsFocusable{}; // 0x511
        uint8 padding_10[0x6]{}; // 0x512
        FMulticastScriptDelegate OnMouseCaptureBegin{}; // 0x518
        FMulticastScriptDelegate OnMouseCaptureEnd{}; // 0x528
        FMulticastScriptDelegate OnControllerCaptureBegin{}; // 0x538
        FMulticastScriptDelegate OnControllerCaptureEnd{}; // 0x548
        FMulticastScriptDelegate OnValueChanged{}; // 0x558
        uint8 padding_11[0x18]{}; // 0x568

        // Functions.
        void SetValue(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthKnob:SetValue", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStepSize(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthKnob:SetStepSize", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetLocked(bool InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthKnob:SetLocked", 1)
            UE_COPY_PROPERTY_CUSTOM(InValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        float GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthKnob:GetValue", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

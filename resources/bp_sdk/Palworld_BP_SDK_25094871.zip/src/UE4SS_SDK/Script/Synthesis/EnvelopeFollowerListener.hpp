#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/ActorComponent.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    // Super Size: 0xA0
    // Size: 0xC0 (unaligned: 0xC0, alignment: 0x8)
    class RC_UE4SS_SDK_API UEnvelopeFollowerListener : public WSDK::UActorComponent
    {
    public:
        // Properties.
        FMulticastScriptDelegate OnEnvelopeFollowerUpdate{}; // 0xA0
        uint8 padding_1[0x10]{}; // 0xB0

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundModulationDestinationSettings.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xD0 (unaligned: 0xD0, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectBitCrusherSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xD0;
        }

        FSourceEffectBitCrusherSettings& operator=(const FSourceEffectBitCrusherSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float CrushedSampleRate{}; // 0x0
        uint8 padding_1[0x4]{}; // 0x4
        FSoundModulationDestinationSettings SampleRateModulation{}; // 0x8
        float CrushedBits{}; // 0x68
        uint8 padding_2[0x4]{}; // 0x6C
        FSoundModulationDestinationSettings BitModulation{}; // 0x70

        // Functions.
    };


}

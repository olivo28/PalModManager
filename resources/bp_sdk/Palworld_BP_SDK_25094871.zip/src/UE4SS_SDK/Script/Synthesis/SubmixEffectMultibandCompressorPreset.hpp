#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectMultibandCompressorSettings.hpp>

namespace WSDK
{
    class UAudioBus;
    class USoundSubmix;

    // Super Size: 0x68
    // Size: 0x100 (unaligned: 0x100, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectMultibandCompressorPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        uint8 padding_1[0x60]{}; // 0x68
        FSubmixEffectMultibandCompressorSettings Settings{}; // 0xC8

        // Functions.
        void SetSettings(FSubmixEffectMultibandCompressorSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectMultibandCompressorPreset:SetSettings", 56)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectMultibandCompressorSettings, 0x0)
        }
        void SetExternalSubmix(USoundSubmix* Submix)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectMultibandCompressorPreset:SetExternalSubmix", 8)
            UE_COPY_PROPERTY_CUSTOM(Submix, USoundSubmix*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAudioBus(UAudioBus* AudioBus)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectMultibandCompressorPreset:SetAudioBus", 8)
            UE_COPY_PROPERTY_CUSTOM(AudioBus, UAudioBus*, 0x0)
            UE_CALL_FUNCTION()
        }
        void ResetKey()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectMultibandCompressorPreset:ResetKey", 0)
            UE_CALL_FUNCTION()
        }
    };


}

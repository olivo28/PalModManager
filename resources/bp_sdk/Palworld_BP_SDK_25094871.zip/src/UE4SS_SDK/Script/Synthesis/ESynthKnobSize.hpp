#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthKnobSize : uint8
    {
        Medium,
        Large,
        Count,
    };
}

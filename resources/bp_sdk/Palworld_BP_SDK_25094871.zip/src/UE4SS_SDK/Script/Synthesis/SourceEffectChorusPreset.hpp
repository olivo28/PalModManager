#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectChorusBaseSettings.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectChorusSettings.hpp>
#include <Unreal/Core/Containers/Set.hpp>

namespace WSDK
{
    class USoundModulatorBase;

    // Super Size: 0x68
    // Size: 0x540 (unaligned: 0x540, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectChorusPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x280]{}; // 0x68
        FSourceEffectChorusSettings Settings{}; // 0x2E8

        // Functions.
        void SetWetModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetWetModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetWetModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetWetModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetWet(float WetAmount)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetWet", 4)
            UE_COPY_PROPERTY_CUSTOM(WetAmount, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSpreadModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetSpreadModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetSpreadModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetSpreadModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSpread(float Spread)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetSpread", 4)
            UE_COPY_PROPERTY_CUSTOM(Spread, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSettings(FSourceEffectChorusBaseSettings& Settings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetSettings", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Settings, FSourceEffectChorusBaseSettings, 0x0)
        }
        void SetModulationSettings(FSourceEffectChorusSettings& ModulationSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetModulationSettings", 600)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ModulationSettings, FSourceEffectChorusSettings, 0x0)
        }
        void SetFrequencyModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFrequencyModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetFrequencyModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFrequencyModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFrequency(float Frequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(Frequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFeedbackModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFeedbackModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetFeedbackModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFeedbackModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFeedback(float Feedback)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetFeedback", 4)
            UE_COPY_PROPERTY_CUSTOM(Feedback, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDryModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDryModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetDryModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDryModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDry(float DryAmount)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDry", 4)
            UE_COPY_PROPERTY_CUSTOM(DryAmount, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDepthModulators(TSet<USoundModulatorBase*>& Modulators)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDepthModulators", 80)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Modulators, TSet<USoundModulatorBase*>, 0x0)
        }
        void SetDepthModulator(USoundModulatorBase* Modulator)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDepthModulator", 8)
            UE_COPY_PROPERTY_CUSTOM(Modulator, USoundModulatorBase*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDepth(float Depth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectChorusPreset:SetDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(Depth, float, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

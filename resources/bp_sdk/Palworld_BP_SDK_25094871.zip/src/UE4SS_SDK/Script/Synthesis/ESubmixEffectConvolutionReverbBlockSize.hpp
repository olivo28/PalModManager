#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESubmixEffectConvolutionReverbBlockSize : uint8
    {
        BlockSize256,
        BlockSize512,
        BlockSize1024,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/LinearColor.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Synthesis/Synth2DSliderStyle.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x640 (unaligned: 0x640, alignment: 0x10)
    class RC_UE4SS_SDK_API USynth2DSlider : public WSDK::UWidget
    {
    public:
        // Properties.
        float ValueX{}; // 0x150
        float ValueY{}; // 0x154
        FScriptDelegate ValueXDelegate{}; // 0x158
        FScriptDelegate ValueYDelegate{}; // 0x168
        uint8 padding_1[0x8]{}; // 0x178
        FSynth2DSliderStyle WidgetStyle{}; // 0x180
        FLinearColor SliderHandleColor{}; // 0x5B0
        bool IndentHandle{}; // 0x5C0
        bool Locked{}; // 0x5C1
        uint8 padding_2[0x2]{}; // 0x5C2
        float StepSize{}; // 0x5C4
        bool IsFocusable{}; // 0x5C8
        uint8 padding_3[0x7]{}; // 0x5C9
        FMulticastScriptDelegate OnMouseCaptureBegin{}; // 0x5D0
        FMulticastScriptDelegate OnMouseCaptureEnd{}; // 0x5E0
        FMulticastScriptDelegate OnControllerCaptureBegin{}; // 0x5F0
        FMulticastScriptDelegate OnControllerCaptureEnd{}; // 0x600
        FMulticastScriptDelegate OnValueChangedX{}; // 0x610
        FMulticastScriptDelegate OnValueChangedY{}; // 0x620
        uint8 padding_4[0x10]{}; // 0x630

        // Functions.
        void SetValue(FVector2D InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:SetValue", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InValue.X, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, InValue.Y, 0x0, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetStepSize(float InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:SetStepSize", 4)
            UE_COPY_PROPERTY_CUSTOM(InValue, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSliderHandleColor(FLinearColor InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:SetSliderHandleColor", 16)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.R, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.G, 0x0, 0x4)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.B, 0x0, 0x8)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(float, InValue.A, 0x0, 0xC)
            UE_CALL_FUNCTION()
        }
        void SetLocked(bool InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:SetLocked", 1)
            UE_COPY_PROPERTY_CUSTOM(InValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetIndentHandle(bool InValue)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:SetIndentHandle", 1)
            UE_COPY_PROPERTY_CUSTOM(InValue, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        FVector2D GetValue()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.Synth2DSlider:GetValue", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVector2D, 0x0)
        }
    };


}

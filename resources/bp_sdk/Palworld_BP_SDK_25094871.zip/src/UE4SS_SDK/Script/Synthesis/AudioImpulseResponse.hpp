#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API UAudioImpulseResponse : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TArray<float> ImpulseResponse{}; // 0x28
        int32 NumChannels{}; // 0x38
        int32 SampleRate{}; // 0x3C
        float NormalizationVolumeDb{}; // 0x40
        bool bTrueStereo{}; // 0x44
        uint8 padding_1[0x3]{}; // 0x45
        TArray<float> IRData{}; // 0x48

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EStereoDelayFiltertype : uint8
    {
        Lowpass,
        Highpass,
        Bandpass,
        Notch,
        Count,
    };
}

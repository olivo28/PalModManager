#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectWaveShaperSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xA0 (unaligned: 0xA0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectWaveShaperPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x30]{}; // 0x68
        FSourceEffectWaveShaperSettings Settings{}; // 0x98

        // Functions.
        void SetSettings(FSourceEffectWaveShaperSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectWaveShaperPreset:SetSettings", 8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectWaveShaperSettings, 0x0)
        }
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectFilterType : uint8
    {
        LowPass,
        HighPass,
        BandPass,
        BandStop,
        Count,
    };
}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EPhaserLFOType : uint8
    {
        Sine,
        UpSaw,
        DownSaw,
        Square,
        Triangle,
        Exponential,
        RandomSampleHold,
        Count,
    };
}

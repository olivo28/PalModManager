#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSubmixPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectTapDelaySettings.hpp>
#include <UE4SS_SDK/Script/Synthesis/TapDelayInfo.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xD8 (unaligned: 0xD8, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectTapDelayPreset : public WSDK::USoundEffectSubmixPreset
    {
    public:
        // Properties.
        uint8 padding_1[0x40]{}; // 0x68
        FSubmixEffectTapDelaySettings Settings{}; // 0xA8
        uint8 padding_2[0x18]{}; // 0xC0

        // Functions.
        void SetTap(int32 TapId, FTapDelayInfo& TapInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:SetTap", 28)
            UE_COPY_PROPERTY_CUSTOM(TapId, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(TapInfo, FTapDelayInfo, 0x4)
        }
        void SetSettings(FSubmixEffectTapDelaySettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:SetSettings", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSubmixEffectTapDelaySettings, 0x0)
        }
        void SetInterpolationTime(float Time)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:SetInterpolationTime", 4)
            UE_COPY_PROPERTY_CUSTOM(Time, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void RemoveTap(int32 TapId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:RemoveTap", 4)
            UE_COPY_PROPERTY_CUSTOM(TapId, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        void GetTapIds(TArray<int32>& TapIds)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:GetTapIds", 16)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(TapIds, TArray<int32>, 0x0)
        }
        void GetTap(int32 TapId, FTapDelayInfo& TapInfo)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:GetTap", 28)
            UE_COPY_PROPERTY_CUSTOM(TapId, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(TapInfo, FTapDelayInfo, 0x4)
        }
        float GetMaxDelayInMilliseconds()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:GetMaxDelayInMilliseconds", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        void AddTap(int32& TapId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectTapDelayPreset:AddTap", 4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(TapId, int32, 0x0)
        }
    };


}

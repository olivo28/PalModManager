#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectEnvelopeFollowerSettings.hpp>

namespace WSDK
{
    class UEnvelopeFollowerListener;

    // Super Size: 0x68
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectEnvelopeFollowerPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x34]{}; // 0x68
        FSourceEffectEnvelopeFollowerSettings Settings{}; // 0x9C

        // Functions.
        void UnregisterEnvelopeFollowerListener(UEnvelopeFollowerListener* EnvelopeFollowerListener)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectEnvelopeFollowerPreset:UnregisterEnvelopeFollowerListener", 8)
            UE_COPY_PROPERTY_CUSTOM(EnvelopeFollowerListener, UEnvelopeFollowerListener*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSettings(FSourceEffectEnvelopeFollowerSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectEnvelopeFollowerPreset:SetSettings", 12)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectEnvelopeFollowerSettings, 0x0)
        }
        void RegisterEnvelopeFollowerListener(UEnvelopeFollowerListener* EnvelopeFollowerListener)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectEnvelopeFollowerPreset:RegisterEnvelopeFollowerListener", 8)
            UE_COPY_PROPERTY_CUSTOM(EnvelopeFollowerListener, UEnvelopeFollowerListener*, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

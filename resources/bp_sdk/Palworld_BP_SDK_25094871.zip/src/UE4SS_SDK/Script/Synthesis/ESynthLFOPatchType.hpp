#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthLFOPatchType : uint8
    {
        PatchToNone,
        PatchToGain,
        PatchToOscFreq,
        PatchToFilterFreq,
        PatchToFilterQ,
        PatchToOscPulseWidth,
        PatchToOscPan,
        PatchLFO1ToLFO2Frequency,
        PatchLFO1ToLFO2Gain,
        Count,
    };
}

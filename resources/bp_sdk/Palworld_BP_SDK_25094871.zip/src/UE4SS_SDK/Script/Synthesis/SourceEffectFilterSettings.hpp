#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectFilterCircuit.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESourceEffectFilterType.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectFilterAudioBusModulationSettings.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSourceEffectFilterSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FSourceEffectFilterSettings& operator=(const FSourceEffectFilterSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESourceEffectFilterCircuit FilterCircuit{}; // 0x0
        ESourceEffectFilterType FilterType{}; // 0x1
        uint8 padding_1[0x2]{}; // 0x2
        float CutoffFrequency{}; // 0x4
        float FilterQ{}; // 0x8
        uint8 padding_2[0x4]{}; // 0xC
        TArray<FSourceEffectFilterAudioBusModulationSettings> AudioBusModulation{}; // 0x10

        // Functions.
    };


}

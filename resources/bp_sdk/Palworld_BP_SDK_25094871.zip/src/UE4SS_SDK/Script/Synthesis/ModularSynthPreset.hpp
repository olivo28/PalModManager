#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TableRowBase.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynth1OscType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthFilterAlgorithm.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthFilterType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOMode.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOPatchType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthModEnvBiasPatch.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthModEnvPatch.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthStereoDelayMode.hpp>
#include <UE4SS_SDK/Script/Synthesis/EpicSynth1Patch.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0xE0 (unaligned: 0xE0, alignment: 0x8)
    struct RC_UE4SS_SDK_API FModularSynthPreset : public WSDK::FTableRowBase
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xE0;
        }

        FModularSynthPreset& operator=(const FModularSynthPreset& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 bEnablePolyphony : 1{}; // 0x8 (0x1)
        uint8 padding_1 : 1{}; // 0x8 (0x2)
        uint8 padding_2 : 1{}; // 0x8 (0x4)
        uint8 padding_3 : 1{}; // 0x8 (0x8)
        uint8 padding_4 : 1{}; // 0x8 (0x10)
        uint8 padding_5 : 1{}; // 0x8 (0x20)
        uint8 padding_6 : 1{}; // 0x8 (0x40)
        uint8 padding_7 : 1{}; // 0x8 (0x80)
        uint8 padding_8[0x3]{}; // 0x9
        ESynth1OscType Osc1Type{}; // 0xC
        uint8 padding_9[0x3]{}; // 0xD
        float Osc1Gain{}; // 0x10
        float Osc1Octave{}; // 0x14
        float Osc1Semitones{}; // 0x18
        float Osc1Cents{}; // 0x1C
        float Osc1PulseWidth{}; // 0x20
        ESynth1OscType Osc2Type{}; // 0x24
        uint8 padding_10[0x3]{}; // 0x25
        float Osc2Gain{}; // 0x28
        float Osc2Octave{}; // 0x2C
        float Osc2Semitones{}; // 0x30
        float Osc2Cents{}; // 0x34
        float Osc2PulseWidth{}; // 0x38
        float Portamento{}; // 0x3C
        uint8 bEnableUnison : 1{}; // 0x40 (0x1)
        uint8 bEnableOscillatorSync : 1{}; // 0x40 (0x2)
        uint8 padding_11 : 1{}; // 0x40 (0x4)
        uint8 padding_12 : 1{}; // 0x40 (0x8)
        uint8 padding_13 : 1{}; // 0x40 (0x10)
        uint8 padding_14 : 1{}; // 0x40 (0x20)
        uint8 padding_15 : 1{}; // 0x40 (0x40)
        uint8 padding_16 : 1{}; // 0x40 (0x80)
        uint8 padding_17[0x3]{}; // 0x41
        float Spread{}; // 0x44
        float Pan{}; // 0x48
        float LFO1Frequency{}; // 0x4C
        float LFO1Gain{}; // 0x50
        ESynthLFOType LFO1Type{}; // 0x54
        ESynthLFOMode LFO1Mode{}; // 0x55
        ESynthLFOPatchType LFO1PatchType{}; // 0x56
        uint8 padding_18[0x1]{}; // 0x57
        float LFO2Frequency{}; // 0x58
        float LFO2Gain{}; // 0x5C
        ESynthLFOType LFO2Type{}; // 0x60
        ESynthLFOMode LFO2Mode{}; // 0x61
        ESynthLFOPatchType LFO2PatchType{}; // 0x62
        uint8 padding_19[0x1]{}; // 0x63
        float GainDb{}; // 0x64
        float AttackTime{}; // 0x68
        float DecayTime{}; // 0x6C
        float SustainGain{}; // 0x70
        float ReleaseTime{}; // 0x74
        ESynthModEnvPatch ModEnvPatchType{}; // 0x78
        ESynthModEnvBiasPatch ModEnvBiasPatchType{}; // 0x79
        uint8 padding_20[0x2]{}; // 0x7A
        uint8 bInvertModulationEnvelope : 1{}; // 0x7C (0x1)
        uint8 bInvertModulationEnvelopeBias : 1{}; // 0x7C (0x2)
        uint8 padding_21 : 1{}; // 0x7C (0x4)
        uint8 padding_22 : 1{}; // 0x7C (0x8)
        uint8 padding_23 : 1{}; // 0x7C (0x10)
        uint8 padding_24 : 1{}; // 0x7C (0x20)
        uint8 padding_25 : 1{}; // 0x7C (0x40)
        uint8 padding_26 : 1{}; // 0x7C (0x80)
        uint8 padding_27[0x3]{}; // 0x7D
        float ModulationEnvelopeDepth{}; // 0x80
        float ModulationEnvelopeAttackTime{}; // 0x84
        float ModulationEnvelopeDecayTime{}; // 0x88
        float ModulationEnvelopeSustainGain{}; // 0x8C
        float ModulationEnvelopeReleaseTime{}; // 0x90
        uint8 bLegato : 1{}; // 0x94 (0x1)
        uint8 bRetrigger : 1{}; // 0x94 (0x2)
        uint8 padding_28 : 1{}; // 0x94 (0x4)
        uint8 padding_29 : 1{}; // 0x94 (0x8)
        uint8 padding_30 : 1{}; // 0x94 (0x10)
        uint8 padding_31 : 1{}; // 0x94 (0x20)
        uint8 padding_32 : 1{}; // 0x94 (0x40)
        uint8 padding_33 : 1{}; // 0x94 (0x80)
        uint8 padding_34[0x3]{}; // 0x95
        float FilterFrequency{}; // 0x98
        float FilterQ{}; // 0x9C
        ESynthFilterType FilterType{}; // 0xA0
        ESynthFilterAlgorithm FilterAlgorithm{}; // 0xA1
        uint8 padding_35[0x2]{}; // 0xA2
        uint8 bStereoDelayEnabled : 1{}; // 0xA4 (0x1)
        uint8 padding_36 : 1{}; // 0xA4 (0x2)
        uint8 padding_37 : 1{}; // 0xA4 (0x4)
        uint8 padding_38 : 1{}; // 0xA4 (0x8)
        uint8 padding_39 : 1{}; // 0xA4 (0x10)
        uint8 padding_40 : 1{}; // 0xA4 (0x20)
        uint8 padding_41 : 1{}; // 0xA4 (0x40)
        uint8 padding_42 : 1{}; // 0xA4 (0x80)
        uint8 padding_43[0x3]{}; // 0xA5
        ESynthStereoDelayMode StereoDelayMode{}; // 0xA8
        uint8 padding_44[0x3]{}; // 0xA9
        float StereoDelayTime{}; // 0xAC
        float StereoDelayFeedback{}; // 0xB0
        float StereoDelayWetlevel{}; // 0xB4
        float StereoDelayRatio{}; // 0xB8
        uint8 bChorusEnabled : 1{}; // 0xBC (0x1)
        uint8 padding_45 : 1{}; // 0xBC (0x2)
        uint8 padding_46 : 1{}; // 0xBC (0x4)
        uint8 padding_47 : 1{}; // 0xBC (0x8)
        uint8 padding_48 : 1{}; // 0xBC (0x10)
        uint8 padding_49 : 1{}; // 0xBC (0x20)
        uint8 padding_50 : 1{}; // 0xBC (0x40)
        uint8 padding_51 : 1{}; // 0xBC (0x80)
        uint8 padding_52[0x3]{}; // 0xBD
        float ChorusDepth{}; // 0xC0
        float ChorusFeedback{}; // 0xC4
        float ChorusFrequency{}; // 0xC8
        uint8 padding_53[0x4]{}; // 0xCC
        TArray<FEpicSynth1Patch> Patches{}; // 0xD0

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectDynamicsProcessorSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xE0 (unaligned: 0xE0, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectDynamicsProcessorPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x50]{}; // 0x68
        FSourceEffectDynamicsProcessorSettings Settings{}; // 0xB8

        // Functions.
        void SetSettings(FSourceEffectDynamicsProcessorSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectDynamicsProcessorPreset:SetSettings", 40)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectDynamicsProcessorSettings, 0x0)
        }
    };


}

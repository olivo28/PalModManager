#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynth1PatchSource.hpp>
#include <UE4SS_SDK/Script/Synthesis/Synth1PatchCable.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x8)
    struct RC_UE4SS_SDK_API FEpicSynth1Patch
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FEpicSynth1Patch& operator=(const FEpicSynth1Patch& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        ESynth1PatchSource PatchSource{}; // 0x0
        uint8 padding_1[0x7]{}; // 0x1
        TArray<FSynth1PatchCable> PatchCables{}; // 0x8

        // Functions.
    };


}

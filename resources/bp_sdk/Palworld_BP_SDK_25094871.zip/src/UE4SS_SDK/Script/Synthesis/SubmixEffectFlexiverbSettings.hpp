#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSubmixEffectFlexiverbSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FSubmixEffectFlexiverbSettings& operator=(const FSubmixEffectFlexiverbSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float PreDelay{}; // 0x0
        float DecayTime{}; // 0x4
        float RoomDampening{}; // 0x8
        int32 Complexity{}; // 0xC

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/SoundEffectSourcePreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/SourceEffectFoldbackDistortionSettings.hpp>

namespace WSDK
{
    // Super Size: 0x68
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API USourceEffectFoldbackDistortionPreset : public WSDK::USoundEffectSourcePreset
    {
    public:
        // Properties.
        uint8 padding_1[0x34]{}; // 0x68
        FSourceEffectFoldbackDistortionSettings Settings{}; // 0x9C

        // Functions.
        void SetSettings(FSourceEffectFoldbackDistortionSettings& InSettings)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SourceEffectFoldbackDistortionPreset:SetSettings", 12)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSettings, FSourceEffectFoldbackDistortionSettings, 0x0)
        }
    };


}

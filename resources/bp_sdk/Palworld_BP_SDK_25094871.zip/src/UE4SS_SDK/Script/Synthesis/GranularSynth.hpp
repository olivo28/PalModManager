#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/SynthComponent.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Synthesis/EGranularSynthEnvelopeType.hpp>
#include <UE4SS_SDK/Script/Synthesis/EGranularSynthSeekType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class USoundWave;

    // Super Size: 0x790
    // Size: 0xB70 (unaligned: 0xB70, alignment: 0x10)
    class RC_UE4SS_SDK_API UGranularSynth : public WSDK::USynthComponent
    {
    public:
        // Properties.
        USoundWave* GranulatedSoundWave{}; // 0x790
        uint8 padding_1[0x3D8]{}; // 0x798

        // Functions.
        void SetSustainGain(float SustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(SustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSoundWave(USoundWave* InSoundWave)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetSoundWave", 8)
            UE_COPY_PROPERTY_CUSTOM(InSoundWave, USoundWave*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetScrubMode(bool bScrubMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetScrubMode", 1)
            UE_COPY_PROPERTY_CUSTOM(bScrubMode, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetReleaseTimeMsec(float ReleaseTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetReleaseTimeMsec", 4)
            UE_COPY_PROPERTY_CUSTOM(ReleaseTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPlayheadTime(float InPositionSec, float LerpTimeSec, EGranularSynthSeekType SeekType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetPlayheadTime", 9)
            UE_COPY_PROPERTY_CUSTOM(InPositionSec, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(LerpTimeSec, float, 0x4)
            UE_COPY_PROPERTY_CUSTOM(SeekType, EGranularSynthSeekType, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetPlaybackSpeed(float InPlayheadRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetPlaybackSpeed", 4)
            UE_COPY_PROPERTY_CUSTOM(InPlayheadRate, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetGrainVolume(float BaseVolume, FVector2D VolumeRange)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainVolume", 24)
            UE_COPY_PROPERTY_CUSTOM(BaseVolume, float, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, VolumeRange.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, VolumeRange.Y, 0x8, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetGrainsPerSecond(float InGrainsPerSecond)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainsPerSecond", 4)
            UE_COPY_PROPERTY_CUSTOM(InGrainsPerSecond, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetGrainProbability(float InGrainProbability)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainProbability", 4)
            UE_COPY_PROPERTY_CUSTOM(InGrainProbability, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetGrainPitch(float BasePitch, FVector2D PitchRange)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainPitch", 24)
            UE_COPY_PROPERTY_CUSTOM(BasePitch, float, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PitchRange.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PitchRange.Y, 0x8, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetGrainPan(float BasePan, FVector2D PanRange)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainPan", 24)
            UE_COPY_PROPERTY_CUSTOM(BasePan, float, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PanRange.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, PanRange.Y, 0x8, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetGrainEnvelopeType(EGranularSynthEnvelopeType EnvelopeType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainEnvelopeType", 1)
            UE_COPY_PROPERTY_CUSTOM(EnvelopeType, EGranularSynthEnvelopeType, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetGrainDuration(float BaseDurationMsec, FVector2D DurationRange)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetGrainDuration", 24)
            UE_COPY_PROPERTY_CUSTOM(BaseDurationMsec, float, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, DurationRange.X, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(double, DurationRange.Y, 0x8, 0x8)
            UE_CALL_FUNCTION()
        }
        void SetDecayTime(float DecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(DecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAttackTime(float AttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:SetAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(AttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void NoteOn(float Note, int32 Velocity, float Duration)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:NoteOn", 12)
            UE_COPY_PROPERTY_CUSTOM(Note, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Velocity, int32, 0x4)
            UE_COPY_PROPERTY_CUSTOM(Duration, float, 0x8)
            UE_CALL_FUNCTION()
        }
        void NoteOff(float Note, bool bKill)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:NoteOff", 5)
            UE_COPY_PROPERTY_CUSTOM(Note, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bKill, bool, 0x4)
            UE_CALL_FUNCTION()
        }
        bool IsLoaded()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:IsLoaded", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        float GetSampleDuration()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:GetSampleDuration", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
        float GetCurrentPlayheadTime()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.GranularSynth:GetCurrentPlayheadTime", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x0)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/SynthComponent.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynth1OscType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynth1PatchSource.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthFilterAlgorithm.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthFilterType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOMode.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOPatchType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthLFOType.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthModEnvBiasPatch.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthModEnvPatch.hpp>
#include <UE4SS_SDK/Script/Synthesis/ESynthStereoDelayMode.hpp>
#include <UE4SS_SDK/Script/Synthesis/ModularSynthPreset.hpp>
#include <UE4SS_SDK/Script/Synthesis/PatchId.hpp>
#include <UE4SS_SDK/Script/Synthesis/Synth1PatchCable.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x790
    // Size: 0xE60 (unaligned: 0xE60, alignment: 0x10)
    class RC_UE4SS_SDK_API UModularSynthComponent : public WSDK::USynthComponent
    {
    public:
        // Properties.
        int32 VoiceCount{}; // 0x790
        uint8 padding_1[0x6CC]{}; // 0x794

        // Functions.
        void SetSynthPreset(FModularSynthPreset& SynthPreset)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetSynthPreset", 224)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(SynthPreset, FModularSynthPreset, 0x0)
        }
        void SetSustainGain(float SustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(SustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayWetlevel(float DelayWetlevel)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayWetlevel", 4)
            UE_COPY_PROPERTY_CUSTOM(DelayWetlevel, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayTime(float DelayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(DelayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayRatio(float DelayRatio)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayRatio", 4)
            UE_COPY_PROPERTY_CUSTOM(DelayRatio, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayMode(ESynthStereoDelayMode StereoDelayMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayMode", 1)
            UE_COPY_PROPERTY_CUSTOM(StereoDelayMode, ESynthStereoDelayMode, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayIsEnabled(bool StereoDelayEnabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayIsEnabled", 1)
            UE_COPY_PROPERTY_CUSTOM(StereoDelayEnabled, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetStereoDelayFeedback(float DelayFeedback)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetStereoDelayFeedback", 4)
            UE_COPY_PROPERTY_CUSTOM(DelayFeedback, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetSpread(float Spread)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetSpread", 4)
            UE_COPY_PROPERTY_CUSTOM(Spread, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetReleaseTime(float ReleaseTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetReleaseTime", 4)
            UE_COPY_PROPERTY_CUSTOM(ReleaseTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPortamento(float Portamento)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetPortamento", 4)
            UE_COPY_PROPERTY_CUSTOM(Portamento, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPitchBend(float PitchBend)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetPitchBend", 4)
            UE_COPY_PROPERTY_CUSTOM(PitchBend, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetPan(float Pan)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetPan", 4)
            UE_COPY_PROPERTY_CUSTOM(Pan, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetOscType(int32 OscIndex, ESynth1OscType OscType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscType", 5)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OscType, ESynth1OscType, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscSync(bool bIsSynced)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscSync", 1)
            UE_COPY_PROPERTY_CUSTOM(bIsSynced, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetOscSemitones(int32 OscIndex, float Semitones)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscSemitones", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Semitones, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscPulsewidth(int32 OscIndex, float Pulsewidth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscPulsewidth", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Pulsewidth, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscOctave(int32 OscIndex, float Octave)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscOctave", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Octave, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscGainMod(int32 OscIndex, float OscGainMod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscGainMod", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OscGainMod, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscGain(int32 OscIndex, float OscGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscGain", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OscGain, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscFrequencyMod(int32 OscIndex, float OscFreqMod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscFrequencyMod", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(OscFreqMod, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetOscCents(int32 OscIndex, float Cents)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetOscCents", 8)
            UE_COPY_PROPERTY_CUSTOM(OscIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Cents, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetModEnvSustainGain(float SustainGain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvSustainGain", 4)
            UE_COPY_PROPERTY_CUSTOM(SustainGain, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvReleaseTime(float Release)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvReleaseTime", 4)
            UE_COPY_PROPERTY_CUSTOM(Release, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvPatch(ESynthModEnvPatch InPatchType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvPatch", 1)
            UE_COPY_PROPERTY_CUSTOM(InPatchType, ESynthModEnvPatch, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvInvert(bool bInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvDepth(float Depth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(Depth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvDecayTime(float DecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(DecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvBiasPatch(ESynthModEnvBiasPatch InPatchType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvBiasPatch", 1)
            UE_COPY_PROPERTY_CUSTOM(InPatchType, ESynthModEnvBiasPatch, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvBiasInvert(bool bInvert)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvBiasInvert", 1)
            UE_COPY_PROPERTY_CUSTOM(bInvert, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetModEnvAttackTime(float AttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetModEnvAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(AttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetLFOType(int32 LFOIndex, ESynthLFOType LFOType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOType", 5)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(LFOType, ESynthLFOType, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOPatch(int32 LFOIndex, ESynthLFOPatchType LFOPatchType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOPatch", 5)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(LFOPatchType, ESynthLFOPatchType, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOMode(int32 LFOIndex, ESynthLFOMode LFOMode)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOMode", 5)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(LFOMode, ESynthLFOMode, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOGainMod(int32 LFOIndex, float GainMod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOGainMod", 8)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(GainMod, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOGain(int32 LFOIndex, float Gain)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOGain", 8)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Gain, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOFrequencyMod(int32 LFOIndex, float FrequencyModHz)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOFrequencyMod", 8)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(FrequencyModHz, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetLFOFrequency(int32 LFOIndex, float FrequencyHz)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetLFOFrequency", 8)
            UE_COPY_PROPERTY_CUSTOM(LFOIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(FrequencyHz, float, 0x4)
            UE_CALL_FUNCTION()
        }
        void SetGainDb(float GainDb)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetGainDb", 4)
            UE_COPY_PROPERTY_CUSTOM(GainDb, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterType(ESynthFilterType FilterType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterType", 1)
            UE_COPY_PROPERTY_CUSTOM(FilterType, ESynthFilterType, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterQMod(float FilterQ)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterQMod", 4)
            UE_COPY_PROPERTY_CUSTOM(FilterQ, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterQ(float FilterQ)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterQ", 4)
            UE_COPY_PROPERTY_CUSTOM(FilterQ, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterFrequencyMod(float FilterFrequencyHz)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterFrequencyMod", 4)
            UE_COPY_PROPERTY_CUSTOM(FilterFrequencyHz, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterFrequency(float FilterFrequencyHz)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(FilterFrequencyHz, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFilterAlgorithm(ESynthFilterAlgorithm FilterAlgorithm)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetFilterAlgorithm", 1)
            UE_COPY_PROPERTY_CUSTOM(FilterAlgorithm, ESynthFilterAlgorithm, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetEnableUnison(bool EnableUnison)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetEnableUnison", 1)
            UE_COPY_PROPERTY_CUSTOM(EnableUnison, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetEnableRetrigger(bool RetriggerEnabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetEnableRetrigger", 1)
            UE_COPY_PROPERTY_CUSTOM(RetriggerEnabled, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetEnablePolyphony(bool bEnablePolyphony)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetEnablePolyphony", 1)
            UE_COPY_PROPERTY_CUSTOM(bEnablePolyphony, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        bool SetEnablePatch(FPatchId PatchId, bool bIsEnabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetEnablePatch", 6)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, PatchId.ID, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bIsEnabled, bool, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x5)
        }
        void SetEnableLegato(bool LegatoEnabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetEnableLegato", 1)
            UE_COPY_PROPERTY_CUSTOM(LegatoEnabled, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetDecayTime(float DecayTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetDecayTime", 4)
            UE_COPY_PROPERTY_CUSTOM(DecayTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetChorusFrequency(float Frequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetChorusFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(Frequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetChorusFeedback(float Feedback)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetChorusFeedback", 4)
            UE_COPY_PROPERTY_CUSTOM(Feedback, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetChorusEnabled(bool EnableChorus)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetChorusEnabled", 1)
            UE_COPY_PROPERTY_CUSTOM(EnableChorus, bool, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetChorusDepth(float Depth)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetChorusDepth", 4)
            UE_COPY_PROPERTY_CUSTOM(Depth, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetAttackTime(float AttackTimeMsec)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:SetAttackTime", 4)
            UE_COPY_PROPERTY_CUSTOM(AttackTimeMsec, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void NoteOn(float Note, int32 Velocity, float Duration)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:NoteOn", 12)
            UE_COPY_PROPERTY_CUSTOM(Note, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Velocity, int32, 0x4)
            UE_COPY_PROPERTY_CUSTOM(Duration, float, 0x8)
            UE_CALL_FUNCTION()
        }
        void NoteOff(float Note, bool bAllNotesOff, bool bKillAllNotes)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:NoteOff", 6)
            UE_COPY_PROPERTY_CUSTOM(Note, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bAllNotesOff, bool, 0x4)
            UE_COPY_PROPERTY_CUSTOM(bKillAllNotes, bool, 0x5)
            UE_CALL_FUNCTION()
        }
        FPatchId CreatePatch(ESynth1PatchSource PatchSource, TArray<FSynth1PatchCable>& PatchCables, bool bEnableByDefault)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.ModularSynthComponent:CreatePatch", 32)
            UE_COPY_PROPERTY_CUSTOM(PatchSource, ESynth1PatchSource, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bEnableByDefault, bool, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(PatchCables, TArray<FSynth1PatchCable>, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(FPatchId, 0x1C)
        }
    };


}

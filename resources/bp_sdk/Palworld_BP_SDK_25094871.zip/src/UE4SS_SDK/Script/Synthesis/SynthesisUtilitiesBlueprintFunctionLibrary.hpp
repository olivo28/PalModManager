#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API USynthesisUtilitiesBlueprintFunctionLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static float GetLogFrequency(float InLinearValue, float InDomainMin, float InDomainMax, float InRangeMin, float InRangeMax)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthesisUtilitiesBlueprintFunctionLibrary:GetLogFrequency", 24)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__SynthesisUtilitiesBlueprintFunctionLibrary")
            UE_COPY_PROPERTY_CUSTOM(InLinearValue, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InDomainMin, float, 0x4)
            UE_COPY_PROPERTY_CUSTOM(InDomainMax, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InRangeMin, float, 0xC)
            UE_COPY_PROPERTY_CUSTOM(InRangeMax, float, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x14)
        }
        static float GetLinearFrequency(float InLogFrequencyValue, float InDomainMin, float InDomainMax, float InRangeMin, float InRangeMax)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthesisUtilitiesBlueprintFunctionLibrary:GetLinearFrequency", 24)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__SynthesisUtilitiesBlueprintFunctionLibrary")
            UE_COPY_PROPERTY_CUSTOM(InLogFrequencyValue, float, 0x0)
            UE_COPY_PROPERTY_CUSTOM(InDomainMin, float, 0x4)
            UE_COPY_PROPERTY_CUSTOM(InDomainMax, float, 0x8)
            UE_COPY_PROPERTY_CUSTOM(InRangeMin, float, 0xC)
            UE_COPY_PROPERTY_CUSTOM(InRangeMax, float, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(float, 0x14)
        }
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ERingModulatorTypeSourceEffect : uint8
    {
        Sine,
        Saw,
        Triangle,
        Square,
        Count,
    };
}

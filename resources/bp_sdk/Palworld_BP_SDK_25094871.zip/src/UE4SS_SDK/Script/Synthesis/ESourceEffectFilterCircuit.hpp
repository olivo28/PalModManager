#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectFilterCircuit : uint8
    {
        OnePole,
        StateVariable,
        Ladder,
        Count,
    };
}

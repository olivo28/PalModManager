#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectConvolutionReverbSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FSourceEffectConvolutionReverbSettings& operator=(const FSourceEffectConvolutionReverbSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float NormalizationVolumeDb{}; // 0x0
        float WetVolumeDb{}; // 0x4
        float DryVolumeDb{}; // 0x8
        bool bBypass{}; // 0xC
        uint8 padding_1[0x3]{}; // 0xD

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x4 (unaligned: 0x4, alignment: 0x4)
    struct RC_UE4SS_SDK_API FPatchId
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x4;
        }

        FPatchId& operator=(const FPatchId& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 ID{}; // 0x0

        // Functions.
    };


}

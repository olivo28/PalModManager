#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthSlateColorStyle : uint8
    {
        Light,
        Dark,
        Count,
    };
}

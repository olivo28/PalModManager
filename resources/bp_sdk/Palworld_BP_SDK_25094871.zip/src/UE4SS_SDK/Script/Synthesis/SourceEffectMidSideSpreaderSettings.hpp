#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/EStereoChannelMode.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectMidSideSpreaderSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FSourceEffectMidSideSpreaderSettings& operator=(const FSourceEffectMidSideSpreaderSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float SpreadAmount{}; // 0x0
        EStereoChannelMode InputMode{}; // 0x4
        EStereoChannelMode OutputMode{}; // 0x5
        bool bEqualPower{}; // 0x6
        uint8 padding_1[0x1]{}; // 0x7

        // Functions.
    };


}

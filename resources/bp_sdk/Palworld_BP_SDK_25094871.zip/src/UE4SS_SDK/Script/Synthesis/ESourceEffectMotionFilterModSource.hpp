#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESourceEffectMotionFilterModSource : uint8
    {
        DistanceFromListener,
        SpeedRelativeToListener,
        SpeedOfSourceEmitter,
        SpeedOfListener,
        SpeedOfAngleDelta,
        Count,
    };
}

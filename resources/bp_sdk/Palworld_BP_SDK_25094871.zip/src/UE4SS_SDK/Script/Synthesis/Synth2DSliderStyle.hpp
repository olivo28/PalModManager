#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateWidgetStyle.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x430 (unaligned: 0x430, alignment: 0x10)
    struct RC_UE4SS_SDK_API FSynth2DSliderStyle : public WSDK::FSlateWidgetStyle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x430;
        }

        FSynth2DSliderStyle& operator=(const FSynth2DSliderStyle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FSlateBrush NormalThumbImage{}; // 0x10
        FSlateBrush DisabledThumbImage{}; // 0xE0
        FSlateBrush NormalBarImage{}; // 0x1B0
        FSlateBrush DisabledBarImage{}; // 0x280
        FSlateBrush BackgroundImage{}; // 0x350
        float BarThickness{}; // 0x420
        uint8 padding_2[0xC]{}; // 0x424

        // Functions.
    };


}

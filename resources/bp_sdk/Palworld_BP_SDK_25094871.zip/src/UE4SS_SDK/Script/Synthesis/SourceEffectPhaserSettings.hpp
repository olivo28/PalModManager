#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Synthesis/EPhaserLFOType.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectPhaserSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FSourceEffectPhaserSettings& operator=(const FSourceEffectPhaserSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float WetLevel{}; // 0x0
        float Frequency{}; // 0x4
        float Feedback{}; // 0x8
        EPhaserLFOType LFOType{}; // 0xC
        bool UseQuadraturePhase{}; // 0xD
        uint8 padding_1[0x2]{}; // 0xE

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/Engine/RuntimeFloatCurve.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x170 (unaligned: 0x170, alignment: 0x8)
    class RC_UE4SS_SDK_API UMonoWaveTableSynthPreset : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FString PresetName{}; // 0x28
        uint8 bLockKeyframesToGridBool : 1{}; // 0x38 (0x1)
        uint8 padding_1 : 1{}; // 0x38 (0x2)
        uint8 padding_2 : 1{}; // 0x38 (0x4)
        uint8 padding_3 : 1{}; // 0x38 (0x8)
        uint8 padding_4 : 1{}; // 0x38 (0x10)
        uint8 padding_5 : 1{}; // 0x38 (0x20)
        uint8 padding_6 : 1{}; // 0x38 (0x40)
        uint8 padding_7 : 1{}; // 0x38 (0x80)
        uint8 padding_8[0x3]{}; // 0x39
        int32 LockKeyframesToGrid{}; // 0x3C
        int32 WaveTableResolution{}; // 0x40
        uint8 padding_9[0x4]{}; // 0x44
        TArray<FRuntimeFloatCurve> WaveTable{}; // 0x48
        uint8 bNormalizeWaveTables : 1{}; // 0x58 (0x1)
        uint8 padding_10[0x117]{}; // 0x59

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioMixer/SynthComponent.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Vector2D.hpp>
#include <UE4SS_SDK/Script/Engine/RuntimeFloatCurve.hpp>

namespace WSDK
{
    // Super Size: 0x790
    // Size: 0x880 (unaligned: 0x880, alignment: 0x10)
    class RC_UE4SS_SDK_API USynthComponentToneGenerator : public WSDK::USynthComponent
    {
    public:
        // Properties.
        float Frequency{}; // 0x790
        float Volume{}; // 0x794
        FRuntimeFloatCurve DistanceAttenuationCurve{}; // 0x798
        FVector2D DistanceRange{}; // 0x820
        float AttenuationDbAtMaxRange{}; // 0x830
        uint8 padding_1[0x4C]{}; // 0x834

        // Functions.
        void SetVolume(float InVolume)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentToneGenerator:SetVolume", 4)
            UE_COPY_PROPERTY_CUSTOM(InVolume, float, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetFrequency(float InFrequency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SynthComponentToneGenerator:SetFrequency", 4)
            UE_COPY_PROPERTY_CUSTOM(InFrequency, float, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

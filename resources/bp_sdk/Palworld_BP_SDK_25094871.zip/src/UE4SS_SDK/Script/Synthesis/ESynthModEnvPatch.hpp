#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ESynthModEnvPatch : uint8
    {
        PatchToNone,
        PatchToOscFreq,
        PatchToFilterFreq,
        PatchToFilterQ,
        PatchToLFO1Gain,
        PatchToLFO2Gain,
        PatchToLFO1Freq,
        PatchToLFO2Freq,
        Count,
    };
}

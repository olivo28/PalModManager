#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/Synthesis/SubmixEffectDelaySettings.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API USubmixEffectDelayStatics : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FSubmixEffectDelaySettings SetMaximumDelayLength(FSubmixEffectDelaySettings& DelaySettings, float MaximumDelayLength)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayStatics:SetMaximumDelayLength", 28)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__SubmixEffectDelayStatics")
            UE_COPY_PROPERTY_CUSTOM(MaximumDelayLength, float, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(DelaySettings, FSubmixEffectDelaySettings, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FSubmixEffectDelaySettings, 0x10)
        }
        static FSubmixEffectDelaySettings SetInterpolationTime(FSubmixEffectDelaySettings& DelaySettings, float InterpolationTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayStatics:SetInterpolationTime", 28)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__SubmixEffectDelayStatics")
            UE_COPY_PROPERTY_CUSTOM(InterpolationTime, float, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(DelaySettings, FSubmixEffectDelaySettings, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FSubmixEffectDelaySettings, 0x10)
        }
        static FSubmixEffectDelaySettings SetDelayLength(FSubmixEffectDelaySettings& DelaySettings, float DelayLength)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/Synthesis.SubmixEffectDelayStatics:SetDelayLength", 28)
            UE_SET_STATIC_SELF("/Script/Synthesis.Default__SubmixEffectDelayStatics")
            UE_COPY_PROPERTY_CUSTOM(DelayLength, float, 0xC)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(DelaySettings, FSubmixEffectDelaySettings, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FSubmixEffectDelaySettings, 0x10)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x4)
    struct RC_UE4SS_SDK_API FSourceEffectSimpleDelaySettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FSourceEffectSimpleDelaySettings& operator=(const FSourceEffectSimpleDelaySettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float SpeedOfSound{}; // 0x0
        float DelayAmount{}; // 0x4
        float DryAmount{}; // 0x8
        float WetAmount{}; // 0xC
        float Feedback{}; // 0x10
        uint8 bDelayBasedOnDistance : 1{}; // 0x14 (0x1)
        uint8 bUseDistanceOverride : 1{}; // 0x14 (0x2)
        uint8 padding_1[0x3]{}; // 0x15

        // Functions.
    };


}

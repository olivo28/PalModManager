#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioImpulseResponse;

    // Super Size: 0x0
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    struct RC_UE4SS_SDK_API FSubmixEffectConvolutionReverbSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x30;
        }

        FSubmixEffectConvolutionReverbSettings& operator=(const FSubmixEffectConvolutionReverbSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float NormalizationVolumeDb{}; // 0x0
        float WetVolumeDb{}; // 0x4
        float DryVolumeDb{}; // 0x8
        bool bBypass{}; // 0xC
        bool bMixInputChannelFormatToImpulseResponseFormat{}; // 0xD
        bool bMixReverbOutputToOutputChannelFormat{}; // 0xE
        uint8 padding_1[0x1]{}; // 0xF
        float SurroundRearChannelBleedDb{}; // 0x10
        bool bInvertRearChannelBleedPhase{}; // 0x14
        bool bSurroundRearChannelFlip{}; // 0x15
        uint8 padding_2[0x2]{}; // 0x16
        float SurroundRearChannelBleedAmount{}; // 0x18
        uint8 padding_3[0x4]{}; // 0x1C
        UAudioImpulseResponse* ImpulseResponse{}; // 0x20
        bool AllowHardwareAcceleration{}; // 0x28
        uint8 padding_4[0x7]{}; // 0x29

        // Functions.
    };


}

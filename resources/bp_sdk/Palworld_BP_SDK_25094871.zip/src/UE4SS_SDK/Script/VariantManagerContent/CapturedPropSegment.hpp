#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    struct RC_UE4SS_SDK_API FCapturedPropSegment
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x28;
        }

        FCapturedPropSegment& operator=(const FCapturedPropSegment& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FString PropertyName{}; // 0x0
        int32 PropertyIndex{}; // 0x10
        uint8 padding_1[0x4]{}; // 0x14
        FString ComponentName{}; // 0x18

        // Functions.
    };


}

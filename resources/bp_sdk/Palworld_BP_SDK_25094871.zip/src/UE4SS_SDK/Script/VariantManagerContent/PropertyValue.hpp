#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/CapturedPropSegment.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/EPropertyValueCategory.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/FieldPath.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UObject;

    // Super Size: 0x28
    // Size: 0x1C0 (unaligned: 0x1C0, alignment: 0x8)
    class RC_UE4SS_SDK_API UPropertyValue : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x60]{}; // 0x28
        TArray<TFieldPath<FProperty>> Properties{}; // 0x88
        TArray<int32> PropertyIndices{}; // 0x98
        TArray<FCapturedPropSegment> CapturedPropSegments{}; // 0xA8
        FString FullDisplayString{}; // 0xB8
        FName PropertySetterName{}; // 0xC8
        TMap<FString, FString> PropertySetterParameterDefaults{}; // 0xD0
        bool bHasRecordedData{}; // 0x120
        uint8 padding_2[0x7]{}; // 0x121
        UClass* LeafPropertyClass{}; // 0x128
        uint8 padding_3[0x8]{}; // 0x130
        TArray<uint8> ValueBytes{}; // 0x138
        EPropertyValueCategory PropCategory{}; // 0x148
        uint8 padding_4[0x77]{}; // 0x149

        // Functions.
        bool HasRecordedData()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.PropertyValue:HasRecordedData", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        FText GetPropertyTooltip()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.PropertyValue:GetPropertyTooltip", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        FString GetFullDisplayString()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.PropertyValue:GetFullDisplayString", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x0)
        }
    };


}

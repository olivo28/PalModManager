#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/SoftObjectPath.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class ULevelVariantSets;
    class ULevelVariantSetsFunctionDirector;
    class UObject;

    // Super Size: 0x290
    // Size: 0x300 (unaligned: 0x300, alignment: 0x8)
    class RC_UE4SS_SDK_API ALevelVariantSetsActor : public WSDK::AActor
    {
    public:
        // Properties.
        FSoftObjectPath LevelVariantSets{}; // 0x290
        TMap<UClass*, ULevelVariantSetsFunctionDirector*> DirectorInstances{}; // 0x2B0

        // Functions.
        bool SwitchOnVariantByName(FString& VariantSetName, FString& VariantName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSetsActor:SwitchOnVariantByName", 33)
            UE_COPY_PROPERTY_CUSTOM(VariantSetName, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(VariantName, FString, 0x10)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x20)
        }
        bool SwitchOnVariantByIndex(int32 VariantSetIndex, int32 VariantIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSetsActor:SwitchOnVariantByIndex", 9)
            UE_COPY_PROPERTY_CUSTOM(VariantSetIndex, int32, 0x0)
            UE_COPY_PROPERTY_CUSTOM(VariantIndex, int32, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        void SetLevelVariantSets(ULevelVariantSets* InVariantSets)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSetsActor:SetLevelVariantSets", 8)
            UE_COPY_PROPERTY_CUSTOM(InVariantSets, ULevelVariantSets*, 0x0)
            UE_CALL_FUNCTION()
        }
        ULevelVariantSets* GetLevelVariantSets(bool bLoad)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSetsActor:GetLevelVariantSets", 16)
            UE_COPY_PROPERTY_CUSTOM(bLoad, bool, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ULevelVariantSets*, 0x8)
        }
    };


}

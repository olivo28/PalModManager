#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/SoftObjectPath.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/FunctionCaller.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UObject;
    class UPropertyValue;

    // Super Size: 0x28
    // Size: 0x98 (unaligned: 0x98, alignment: 0x8)
    class RC_UE4SS_SDK_API UVariantObjectBinding : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FString CachedActorLabel{}; // 0x28
        FSoftObjectPath ObjectPtr{}; // 0x38
        TLazyObjectPtr<UObject> LazyObjectPtr{}; // 0x58
        uint8 padding_1[0x4]{}; // 0x74
        TArray<UPropertyValue*> CapturedProperties{}; // 0x78
        TArray<FFunctionCaller> FunctionCallers{}; // 0x88

        // Functions.
    };


}

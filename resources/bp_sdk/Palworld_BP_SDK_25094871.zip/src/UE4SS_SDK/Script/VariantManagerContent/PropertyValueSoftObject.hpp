#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/PropertyValue.hpp>

namespace WSDK
{
    // Super Size: 0x1C0
    // Size: 0x1C0 (unaligned: 0x1C0, alignment: 0x8)
    class RC_UE4SS_SDK_API UPropertyValueSoftObject : public WSDK::UPropertyValue
    {
    public:
        // Properties.

        // Functions.
    };


}

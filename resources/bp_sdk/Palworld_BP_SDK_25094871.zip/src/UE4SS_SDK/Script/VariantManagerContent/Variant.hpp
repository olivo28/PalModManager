#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Transform.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/VariantDependency.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AActor;
    class ULevelVariantSets;
    class UObject;
    class UTexture2D;
    class UVariant;
    class UVariantObjectBinding;
    class UVariantSet;

    // Super Size: 0x28
    // Size: 0x80 (unaligned: 0x80, alignment: 0x8)
    class RC_UE4SS_SDK_API UVariant : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TArray<FVariantDependency> Dependencies{}; // 0x28
        FText DisplayText{}; // 0x38
        uint8 padding_1[0x18]{}; // 0x50
        TArray<UVariantObjectBinding*> ObjectBindings{}; // 0x68
        UTexture2D* Thumbnail{}; // 0x78

        // Functions.
        void SwitchOn()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SwitchOn", 0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromTexture(UTexture2D* NewThumbnail)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetThumbnailFromTexture", 8)
            UE_COPY_PROPERTY_CUSTOM(NewThumbnail, UTexture2D*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromFile(FString& FilePath)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetThumbnailFromFile", 16)
            UE_COPY_PROPERTY_CUSTOM(FilePath, FString, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromEditorViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetThumbnailFromEditorViewport", 0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromCamera(UObject* WorldContextObject, FTransform& CameraTransform, float FOVDegrees, float MinZ, float Gamma)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetThumbnailFromCamera", 124)
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(FOVDegrees, float, 0x70)
            UE_COPY_PROPERTY_CUSTOM(MinZ, float, 0x74)
            UE_COPY_PROPERTY_CUSTOM(Gamma, float, 0x78)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(CameraTransform, FTransform, 0x10)
        }
        void SetDisplayText(FText& NewDisplayText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetDisplayText", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(NewDisplayText, FText, 0x0)
        }
        void SetDependency(int32 Index, FVariantDependency& Dependency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:SetDependency", 112)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Dependency, FVariantDependency, 0x8)
        }
        bool IsActive()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:IsActive", 1)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        UTexture2D* GetThumbnail()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetThumbnail", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTexture2D*, 0x0)
        }
        UVariantSet* GetParent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetParent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVariantSet*, 0x0)
        }
        int32 GetNumDependencies()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetNumDependencies", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        int32 GetNumActors()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetNumActors", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        FText GetDisplayText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetDisplayText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        TArray<UVariant*> GetDependents(ULevelVariantSets* LevelVariantSets, bool bOnlyEnabledDependencies)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetDependents", 32)
            UE_COPY_PROPERTY_CUSTOM(LevelVariantSets, ULevelVariantSets*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(bOnlyEnabledDependencies, bool, 0x8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UVariant*>, 0x10)
        }
        FVariantDependency GetDependency(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetDependency", 112)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FVariantDependency, 0x8)
        }
        AActor* GetActor(int32 ActorIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:GetActor", 16)
            UE_COPY_PROPERTY_CUSTOM(ActorIndex, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(AActor*, 0x8)
        }
        void DeleteDependency(int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:DeleteDependency", 4)
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        int32 AddDependency(FVariantDependency& Dependency)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.Variant:AddDependency", 108)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Dependency, FVariantDependency, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x68)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/Variant.hpp>
#include <UE4SS_SDK/Script/VariantManagerContent/VariantSet.hpp>
#include <Unreal/SoftObjectPtr.hpp>

namespace WSDK
{
    class UVariant;
    class UVariantSet;

    // Super Size: 0x0
    // Size: 0x68 (unaligned: 0x68, alignment: 0x8)
    struct RC_UE4SS_SDK_API FVariantDependency
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x68;
        }

        FVariantDependency& operator=(const FVariantDependency& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TSoftObjectPtr<UVariantSet> VariantSet{}; // 0x0
        TSoftObjectPtr<UVariant> Variant{}; // 0x30
        bool bEnabled{}; // 0x60
        uint8 padding_1[0x7]{}; // 0x61

        // Functions.
    };


}

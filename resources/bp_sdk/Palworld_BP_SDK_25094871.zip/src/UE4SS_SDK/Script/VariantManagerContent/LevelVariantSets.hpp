#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UObject;
    class UVariantSet;

    // Super Size: 0x28
    // Size: 0x90 (unaligned: 0x90, alignment: 0x8)
    class RC_UE4SS_SDK_API ULevelVariantSets : public RC::Unreal::UObject
    {
    public:
        // Properties.
        UClass* DirectorClass{}; // 0x28
        TArray<UVariantSet*> VariantSets{}; // 0x30
        uint8 padding_1[0x50]{}; // 0x40

        // Functions.
        UVariantSet* GetVariantSetByName(FString& VariantSetName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSets:GetVariantSetByName", 24)
            UE_COPY_PROPERTY_CUSTOM(VariantSetName, FString, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVariantSet*, 0x10)
        }
        UVariantSet* GetVariantSet(int32 VariantSetIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSets:GetVariantSet", 16)
            UE_COPY_PROPERTY_CUSTOM(VariantSetIndex, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVariantSet*, 0x8)
        }
        int32 GetNumVariantSets()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.LevelVariantSets:GetNumVariantSets", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
    };


}

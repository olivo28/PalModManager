#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Transform.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class ULevelVariantSets;
    class UObject;
    class UTexture2D;
    class UVariant;

    // Super Size: 0x28
    // Size: 0x78 (unaligned: 0x78, alignment: 0x8)
    class RC_UE4SS_SDK_API UVariantSet : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FText DisplayText{}; // 0x28
        uint8 padding_1[0x18]{}; // 0x40
        bool bExpanded{}; // 0x58
        uint8 padding_2[0x7]{}; // 0x59
        TArray<UVariant*> Variants{}; // 0x60
        UTexture2D* Thumbnail{}; // 0x70

        // Functions.
        void SetThumbnailFromTexture(UTexture2D* NewThumbnail)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:SetThumbnailFromTexture", 8)
            UE_COPY_PROPERTY_CUSTOM(NewThumbnail, UTexture2D*, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromFile(FString& FilePath)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:SetThumbnailFromFile", 16)
            UE_COPY_PROPERTY_CUSTOM(FilePath, FString, 0x0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromEditorViewport()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:SetThumbnailFromEditorViewport", 0)
            UE_CALL_FUNCTION()
        }
        void SetThumbnailFromCamera(UObject* WorldContextObject, FTransform& CameraTransform, float FOVDegrees, float MinZ, float Gamma)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:SetThumbnailFromCamera", 124)
            UE_COPY_PROPERTY_CUSTOM(WorldContextObject, UObject*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(FOVDegrees, float, 0x70)
            UE_COPY_PROPERTY_CUSTOM(MinZ, float, 0x74)
            UE_COPY_PROPERTY_CUSTOM(Gamma, float, 0x78)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(CameraTransform, FTransform, 0x10)
        }
        void SetDisplayText(FText& NewDisplayText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:SetDisplayText", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(NewDisplayText, FText, 0x0)
        }
        UVariant* GetVariantByName(FString& VariantName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetVariantByName", 24)
            UE_COPY_PROPERTY_CUSTOM(VariantName, FString, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVariant*, 0x10)
        }
        UVariant* GetVariant(int32 VariantIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetVariant", 16)
            UE_COPY_PROPERTY_CUSTOM(VariantIndex, int32, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UVariant*, 0x8)
        }
        UTexture2D* GetThumbnail()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetThumbnail", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTexture2D*, 0x0)
        }
        ULevelVariantSets* GetParent()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetParent", 8)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(ULevelVariantSets*, 0x0)
        }
        int32 GetNumVariants()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetNumVariants", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        FText GetDisplayText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.VariantSet:GetDisplayText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
    };


}

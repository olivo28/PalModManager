#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/Actor.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class AActor;
    class USceneComponent;

    // Super Size: 0x290
    // Size: 0x2B8 (unaligned: 0x2B8, alignment: 0x8)
    class RC_UE4SS_SDK_API ASwitchActor : public WSDK::AActor
    {
    public:
        // Properties.
        uint8 padding_1[0x18]{}; // 0x290
        USceneComponent* SceneComponent{}; // 0x2A8
        int32 LastSelectedOption{}; // 0x2B0
        uint8 padding_2[0x4]{}; // 0x2B4

        // Functions.
        void SelectOption(int32 OptionIndex)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.SwitchActor:SelectOption", 4)
            UE_COPY_PROPERTY_CUSTOM(OptionIndex, int32, 0x0)
            UE_CALL_FUNCTION()
        }
        int32 GetSelectedOption()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.SwitchActor:GetSelectedOption", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        TArray<AActor*> GetOptions()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/VariantManagerContent.SwitchActor:GetOptions", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<AActor*>, 0x0)
        }
    };


}

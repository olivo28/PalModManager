#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Niagara/NiagaraDataInterface.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    class UAkAudioEvent;
    class UAkRtpc;

    // Super Size: 0x38
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UNiagaraDataInterfaceWwiseEvent : public WSDK::UNiagaraDataInterface
    {
    public:
        // Properties.
        UAkAudioEvent* EventToPost{}; // 0x38
        TArray<UAkRtpc*> GameParameters{}; // 0x40
        bool bLimitPostsPerTick{}; // 0x50
        uint8 padding_1[0x3]{}; // 0x51
        int32 MaxPostsPerTick{}; // 0x54
        bool bStopWhenComponentIsDestroyed{}; // 0x58
        uint8 padding_2[0x7]{}; // 0x59

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UTraceUtilLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static void TraceMarkRegionStart(FString& Name)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:TraceMarkRegionStart", 16)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(Name, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static void TraceMarkRegionEnd(FString& Name)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:TraceMarkRegionEnd", 16)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(Name, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static void TraceBookmark(FString& Name)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:TraceBookmark", 16)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(Name, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
        }
        static bool ToggleChannel(FString& ChannelName, bool Enabled)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:ToggleChannel", 18)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(ChannelName, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Enabled, bool, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x11)
        }
        static bool StopTracing()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:StopTracing", 1)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        static bool StartTraceToFile(FString& Filename, TArray<FString>& channels)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:StartTraceToFile", 33)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(Filename, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(channels, TArray<FString>, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x20)
        }
        static bool StartTraceSendTo(FString& Target, TArray<FString>& channels)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:StartTraceSendTo", 33)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(Target, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(channels, TArray<FString>, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x20)
        }
        static bool ResumeTracing()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:ResumeTracing", 1)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        static bool PauseTracing()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:PauseTracing", 1)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        static bool IsTracing()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:IsTracing", 1)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x0)
        }
        static bool IsChannelEnabled(FString& ChannelName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:IsChannelEnabled", 17)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_COPY_PROPERTY_CUSTOM(ChannelName, FString, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static TArray<FString> GetEnabledChannels()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:GetEnabledChannels", 16)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<FString>, 0x0)
        }
        static TArray<FString> GetAllChannels()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TraceUtilities.TraceUtilLibrary:GetAllChannels", 16)
            UE_SET_STATIC_SELF("/Script/TraceUtilities.Default__TraceUtilLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<FString>, 0x0)
        }
    };


}

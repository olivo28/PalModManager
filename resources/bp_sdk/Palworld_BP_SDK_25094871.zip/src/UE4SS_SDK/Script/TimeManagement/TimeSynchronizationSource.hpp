#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    class RC_UE4SS_SDK_API UTimeSynchronizationSource : public RC::Unreal::UObject
    {
    public:
        // Properties.
        bool bUseForSynchronization{}; // 0x28
        uint8 padding_1[0x3]{}; // 0x29
        int32 FrameOffset{}; // 0x2C

        // Functions.
    };


}

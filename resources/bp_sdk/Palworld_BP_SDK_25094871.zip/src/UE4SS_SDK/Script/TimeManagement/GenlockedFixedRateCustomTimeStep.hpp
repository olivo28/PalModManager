#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/FrameRate.hpp>
#include <UE4SS_SDK/Script/TimeManagement/GenlockedCustomTimeStep.hpp>

namespace WSDK
{
    // Super Size: 0x30
    // Size: 0x50 (unaligned: 0x50, alignment: 0x8)
    class RC_UE4SS_SDK_API UGenlockedFixedRateCustomTimeStep : public WSDK::UGenlockedCustomTimeStep
    {
    public:
        // Properties.
        FFrameRate FrameRate{}; // 0x30
        bool bShouldBlock{}; // 0x38
        bool bForceSingleFrameDeltaTime{}; // 0x39
        uint8 padding_1[0x16]{}; // 0x3A

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EFrameNumberDisplayFormats
    {
        NonDropFrameTimecode,
        DropFrameTimecode,
        Seconds,
        Frames,
        MAX_Count,
    };
}

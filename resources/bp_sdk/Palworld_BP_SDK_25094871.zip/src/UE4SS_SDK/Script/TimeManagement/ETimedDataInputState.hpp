#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETimedDataInputState
    {
        Connected,
        Unresponsive,
        Disconnected,
    };
}

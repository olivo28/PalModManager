#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/EngineCustomTimeStep.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UFixedFrameRateCustomTimeStep : public WSDK::UEngineCustomTimeStep
    {
    public:
        // Properties.

        // Functions.
    };


}

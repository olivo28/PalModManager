#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/TimecodeProvider.hpp>

namespace WSDK
{
    // Super Size: 0x30
    // Size: 0x58 (unaligned: 0x58, alignment: 0x8)
    class RC_UE4SS_SDK_API UGenlockedTimecodeProvider : public WSDK::UTimecodeProvider
    {
    public:
        // Properties.
        bool bUseGenlockToCount{}; // 0x30
        uint8 padding_1[0x27]{}; // 0x31

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/FrameNumber.hpp>
#include <UE4SS_SDK/Script/CoreUObject/FrameRate.hpp>
#include <UE4SS_SDK/Script/CoreUObject/FrameTime.hpp>
#include <UE4SS_SDK/Script/CoreUObject/QualifiedFrameTime.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Timecode.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UTimeManagementBlueprintLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FFrameTime TransformTime(FFrameTime& SourceTime, FFrameRate& SourceRate, FFrameRate& DestinationRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:TransformTime", 32)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(SourceTime, FFrameTime, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(SourceRate, FFrameRate, 0x8)
            UE_COPY_OUT_PROPERTY_CUSTOM(DestinationRate, FFrameRate, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(FFrameTime, 0x18)
        }
        static FFrameNumber Subtract_FrameNumberInteger(FFrameNumber A, int32 B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Subtract_FrameNumberInteger", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(B, int32, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
        static FFrameNumber Subtract_FrameNumberFrameNumber(FFrameNumber A, FFrameNumber B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Subtract_FrameNumberFrameNumber", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, B.Value, 0x4, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
        static FFrameTime SnapFrameTimeToRate(FFrameTime& SourceTime, FFrameRate& SourceRate, FFrameRate& SnapToRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:SnapFrameTimeToRate", 32)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(SourceTime, FFrameTime, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(SourceRate, FFrameRate, 0x8)
            UE_COPY_OUT_PROPERTY_CUSTOM(SnapToRate, FFrameRate, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(FFrameTime, 0x18)
        }
        static FFrameTime Multiply_SecondsFrameRate(float TimeInSeconds, FFrameRate& FrameRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Multiply_SecondsFrameRate", 20)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(TimeInSeconds, float, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(FrameRate, FFrameRate, 0x4)
            UE_RETURN_PROPERTY_CUSTOM(FFrameTime, 0xC)
        }
        static FFrameNumber Multiply_FrameNumberInteger(FFrameNumber A, int32 B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Multiply_FrameNumberInteger", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(B, int32, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
        static bool IsValid_MultipleOf(FFrameRate& InFrameRate, FFrameRate& OtherFramerate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:IsValid_MultipleOf", 17)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InFrameRate, FFrameRate, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(OtherFramerate, FFrameRate, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static bool IsValid_Framerate(FFrameRate& InFrameRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:IsValid_Framerate", 9)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InFrameRate, FFrameRate, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        static FFrameRate GetTimecodeFrameRate()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:GetTimecodeFrameRate", 8)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameRate, 0x0)
        }
        static FTimecode GetTimecode()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:GetTimecode", 20)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FTimecode, 0x0)
        }
        static FFrameNumber Divide_FrameNumberInteger(FFrameNumber A, int32 B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Divide_FrameNumberInteger", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(B, int32, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
        static FString Conv_TimecodeToString(FTimecode& InTimecode, bool bForceSignDisplay)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_TimecodeToString", 40)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_PROPERTY_CUSTOM(bForceSignDisplay, bool, 0x14)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InTimecode, FTimecode, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x18)
        }
        static float Conv_QualifiedFrameTimeToSeconds(FQualifiedFrameTime& InFrameTime)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_QualifiedFrameTimeToSeconds", 20)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InFrameTime, FQualifiedFrameTime, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(float, 0x10)
        }
        static float Conv_FrameRateToSeconds(FFrameRate& InFrameRate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_FrameRateToSeconds", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InFrameRate, FFrameRate, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(float, 0x8)
        }
        static int32 Conv_FrameNumberToInteger(FFrameNumber& InFrameNumber)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Conv_FrameNumberToInteger", 8)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InFrameNumber, FFrameNumber, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x4)
        }
        static FFrameNumber Add_FrameNumberInteger(FFrameNumber A, int32 B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Add_FrameNumberInteger", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_PROPERTY_CUSTOM(B, int32, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
        static FFrameNumber Add_FrameNumberFrameNumber(FFrameNumber A, FFrameNumber B)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TimeManagement.TimeManagementBlueprintLibrary:Add_FrameNumberFrameNumber", 12)
            UE_SET_STATIC_SELF("/Script/TimeManagement.Default__TimeManagementBlueprintLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, A.Value, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(int32, B.Value, 0x4, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FFrameNumber, 0x8)
        }
    };


}

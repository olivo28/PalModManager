#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ButtonStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateWidgetStyle.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0x5A0 (unaligned: 0x5A0, alignment: 0x10)
    struct RC_UE4SS_SDK_API FWidgetCarouselNavigationButtonStyle : public WSDK::FSlateWidgetStyle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x5A0;
        }

        FWidgetCarouselNavigationButtonStyle& operator=(const FWidgetCarouselNavigationButtonStyle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FButtonStyle InnerButtonStyle{}; // 0x10
        FSlateBrush NavigationButtonLeftImage{}; // 0x400
        FSlateBrush NavigationButtonRightImage{}; // 0x4D0

        // Functions.
    };


}

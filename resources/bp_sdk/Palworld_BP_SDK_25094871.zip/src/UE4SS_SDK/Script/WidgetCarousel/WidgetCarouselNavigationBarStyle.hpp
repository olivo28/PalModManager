#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/SlateCore/ButtonStyle.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateBrush.hpp>
#include <UE4SS_SDK/Script/SlateCore/SlateWidgetStyle.hpp>

namespace WSDK
{
    // Super Size: 0x8
    // Size: 0xCB0 (unaligned: 0xCB0, alignment: 0x10)
    struct RC_UE4SS_SDK_API FWidgetCarouselNavigationBarStyle : public WSDK::FSlateWidgetStyle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xCB0;
        }

        FWidgetCarouselNavigationBarStyle& operator=(const FWidgetCarouselNavigationBarStyle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x8
        FSlateBrush HighlightBrush{}; // 0x10
        FButtonStyle LeftButtonStyle{}; // 0xE0
        FButtonStyle CenterButtonStyle{}; // 0x4D0
        FButtonStyle RightButtonStyle{}; // 0x8C0

        // Functions.
    };


}

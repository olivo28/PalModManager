#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneFloatChannel.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneIntegerChannel.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneSection.hpp>
#include <UE4SS_SDK/Script/MovieSceneTracks/MovieSceneStringChannel.hpp>

namespace WSDK
{
    // Super Size: 0xF0
    // Size: 0x710 (unaligned: 0x710, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieSceneTakeSection : public WSDK::UMovieSceneSection
    {
    public:
        // Properties.
        FMovieSceneIntegerChannel HoursCurve{}; // 0xF0
        FMovieSceneIntegerChannel MinutesCurve{}; // 0x1F0
        FMovieSceneIntegerChannel SecondsCurve{}; // 0x2F0
        FMovieSceneIntegerChannel FramesCurve{}; // 0x3F0
        FMovieSceneFloatChannel SubFramesCurve{}; // 0x4F0
        FMovieSceneStringChannel Slate{}; // 0x600

        // Functions.
    };


}

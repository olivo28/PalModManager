#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x88 (unaligned: 0x88, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieSceneTakeSettings : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FString HoursName{}; // 0x28
        FString MinutesName{}; // 0x38
        FString SecondsName{}; // 0x48
        FString FramesName{}; // 0x58
        FString SubFramesName{}; // 0x68
        FString SlateName{}; // 0x78

        // Functions.
    };


}

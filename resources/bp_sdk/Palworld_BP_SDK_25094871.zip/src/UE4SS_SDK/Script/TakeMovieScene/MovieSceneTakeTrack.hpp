#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/MovieScene/MovieSceneNameableTrack.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UMovieSceneSection;

    // Super Size: 0x98
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    class RC_UE4SS_SDK_API UMovieSceneTakeTrack : public WSDK::UMovieSceneNameableTrack
    {
    public:
        // Properties.
        TArray<UMovieSceneSection*> Sections{}; // 0x98

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWwiseLanguageRequirement : uint8
    {
        IsDefault,
        IsOptional,
        SFX,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/EWwiseSoundBankType.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x1C (unaligned: 0x1C, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseSoundBankCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x1C;
        }

        FWwiseSoundBankCookedData& operator=(const FWwiseSoundBankCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 SoundBankId{}; // 0x0
        FName SoundBankPathName{}; // 0x4
        int32 MemoryAlignment{}; // 0xC
        bool bDeviceMemory{}; // 0x10
        bool bContainsMedia{}; // 0x11
        EWwiseSoundBankType SoundBankType{}; // 0x12
        uint8 padding_1[0x1]{}; // 0x13
        FName DebugName{}; // 0x14

        // Functions.
    };


}

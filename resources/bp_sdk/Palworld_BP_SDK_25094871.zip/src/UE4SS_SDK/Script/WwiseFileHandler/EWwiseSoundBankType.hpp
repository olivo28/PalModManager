#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWwiseSoundBankType : uint8
    {
        User,
        Event = 0x1E,
        Bus,
    };
}

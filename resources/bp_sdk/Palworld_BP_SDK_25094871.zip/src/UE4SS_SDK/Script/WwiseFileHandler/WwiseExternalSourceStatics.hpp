#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/WwiseObjectUtils/AkUniqueID.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseExternalSourceStatics : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static void SetExternalSourceMediaWithIds(FAkUniqueID ExternalSourceCookie, int32 MediaId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseFileHandler.WwiseExternalSourceStatics:SetExternalSourceMediaWithIds", 8)
            UE_SET_STATIC_SELF("/Script/WwiseFileHandler.Default__WwiseExternalSourceStatics")
            UE_COPY_PROPERTY_CUSTOM(MediaId, int32, 0x4)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetExternalSourceMediaByName(FString& ExternalSourceName, FString& MediaName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseFileHandler.WwiseExternalSourceStatics:SetExternalSourceMediaByName", 32)
            UE_SET_STATIC_SELF("/Script/WwiseFileHandler.Default__WwiseExternalSourceStatics")
            UE_COPY_PROPERTY_CUSTOM(ExternalSourceName, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(MediaName, FString, 0x10)
            UE_CALL_STATIC_FUNCTION()
        }
        static void SetExternalSourceMediaById(FString& ExternalSourceName, int32 MediaId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseFileHandler.WwiseExternalSourceStatics:SetExternalSourceMediaById", 20)
            UE_SET_STATIC_SELF("/Script/WwiseFileHandler.Default__WwiseExternalSourceStatics")
            UE_COPY_PROPERTY_CUSTOM(ExternalSourceName, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(MediaId, int32, 0x10)
            UE_CALL_STATIC_FUNCTION()
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseMediaCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FWwiseMediaCookedData& operator=(const FWwiseMediaCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 MediaId{}; // 0x0
        FName MediaPathName{}; // 0x4
        int32 PrefetchSize{}; // 0xC
        int32 MemoryAlignment{}; // 0x10
        bool bDeviceMemory{}; // 0x14
        bool bStreaming{}; // 0x15
        uint8 padding_1[0x2]{}; // 0x16
        FName DebugName{}; // 0x18

        // Functions.
    };


}

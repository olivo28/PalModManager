#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/EWwiseLanguageRequirement.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseLanguageCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FWwiseLanguageCookedData& operator=(const FWwiseLanguageCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 LanguageId{}; // 0x0
        FName LanguageName{}; // 0x4
        EWwiseLanguageRequirement LanguageRequirement{}; // 0xC
        uint8 padding_1[0x3]{}; // 0xD

        // Functions.
    };


}

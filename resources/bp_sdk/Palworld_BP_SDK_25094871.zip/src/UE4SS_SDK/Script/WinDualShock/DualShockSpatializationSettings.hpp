#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AudioExtensions/SoundfieldEncodingSettingsBase.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UDualShockSpatializationSettings : public WSDK::USoundfieldEncodingSettingsBase
    {
    public:
        // Properties.
        float Spread{}; // 0x28
        int32 Priority{}; // 0x2C
        bool Passthrough{}; // 0x30
        uint8 padding_1[0x7]{}; // 0x31

        // Functions.
    };


}

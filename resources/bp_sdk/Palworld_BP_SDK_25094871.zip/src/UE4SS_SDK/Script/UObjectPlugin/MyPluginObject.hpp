#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UObjectPlugin/MyPluginStruct.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x38 (unaligned: 0x38, alignment: 0x8)
    class RC_UE4SS_SDK_API UMyPluginObject : public RC::Unreal::UObject
    {
    public:
        // Properties.
        FMyPluginStruct MyStruct{}; // 0x28

        // Functions.
    };


}

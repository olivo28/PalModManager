#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/EWwiseLanguageRequirement.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x8)
    struct RC_UE4SS_SDK_API alignas(0x8) FWwiseSharedLanguageId
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FWwiseSharedLanguageId& operator=(const FWwiseSharedLanguageId& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x10]{}; // 0x0
        EWwiseLanguageRequirement LanguageRequirement{}; // 0x10
        uint8 padding_2[0x7]{}; // 0x11

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseGroupType.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x14 (unaligned: 0x14, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseGroupValueCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x14;
        }

        FWwiseGroupValueCookedData& operator=(const FWwiseGroupValueCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWwiseGroupType Type{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        int32 GroupId{}; // 0x4
        int32 ID{}; // 0x8
        FName DebugName{}; // 0xC

        // Functions.
    };


}

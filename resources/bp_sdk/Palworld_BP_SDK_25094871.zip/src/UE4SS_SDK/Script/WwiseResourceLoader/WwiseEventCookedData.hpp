#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseExternalSourceCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseMediaCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseSoundBankCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseEventDestroyOptions.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseGroupValueCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseSwitchContainerLeafCookedData.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/Core/Containers/Set.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xA8 (unaligned: 0xA8, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseEventCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xA8;
        }

        FWwiseEventCookedData& operator=(const FWwiseEventCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 EventId{}; // 0x0
        uint8 padding_1[0x4]{}; // 0x4
        TArray<FWwiseSoundBankCookedData> SoundBanks{}; // 0x8
        TArray<FWwiseMediaCookedData> Media{}; // 0x18
        TArray<FWwiseExternalSourceCookedData> ExternalSources{}; // 0x28
        TArray<FWwiseSwitchContainerLeafCookedData> SwitchContainerLeaves{}; // 0x38
        TSet<FWwiseGroupValueCookedData> RequiredGroupValueSet{}; // 0x48
        EWwiseEventDestroyOptions DestroyOptions{}; // 0x98
        uint8 padding_2[0x3]{}; // 0x99
        FName DebugName{}; // 0x9C
        uint8 padding_3[0x4]{}; // 0xA4

        // Functions.
    };


}

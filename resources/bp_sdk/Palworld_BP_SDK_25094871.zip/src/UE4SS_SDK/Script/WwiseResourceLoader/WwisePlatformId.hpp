#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwisePlatformId
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FWwisePlatformId& operator=(const FWwisePlatformId& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FGuid PlatformGuid{}; // 0x0
        FName PlatformName{}; // 0x10

        // Functions.
    };


}

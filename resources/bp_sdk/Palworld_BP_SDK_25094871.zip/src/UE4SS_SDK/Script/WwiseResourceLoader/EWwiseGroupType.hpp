#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWwiseGroupType : uint8
    {
        Switch,
        State,
        Unknown = 0xFF,
    };
}

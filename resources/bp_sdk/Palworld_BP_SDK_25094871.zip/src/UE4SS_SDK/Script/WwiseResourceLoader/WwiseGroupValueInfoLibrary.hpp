#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseGroupValueInfo.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseGroupValueInfoLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FWwiseGroupValueInfo SetWwiseShortId(FWwiseGroupValueInfo& Ref, int32 WwiseShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:SetWwiseShortId", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseGroupValueInfo, 0x28)
        }
        static FWwiseGroupValueInfo SetWwiseName(FWwiseGroupValueInfo& Ref, FString& WwiseName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:SetWwiseName", 92)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x28)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseGroupValueInfo, 0x38)
        }
        static FWwiseGroupValueInfo SetGroupShortId(FWwiseGroupValueInfo& Ref, int32 GroupShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:SetGroupShortId", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(GroupShortId, int32, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseGroupValueInfo, 0x28)
        }
        static FWwiseGroupValueInfo SetAssetGuid(FWwiseGroupValueInfo& Ref, FGuid& AssetGuid)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:SetAssetGuid", 88)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(AssetGuid, FGuid, 0x24)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseGroupValueInfo, 0x34)
        }
        static FWwiseGroupValueInfo MakeStruct(FGuid& AssetGuid, int32 GroupShortId, int32 WwiseShortId, FString& WwiseName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:MakeStruct", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(GroupShortId, int32, 0x10)
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x14)
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x18)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(AssetGuid, FGuid, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseGroupValueInfo, 0x28)
        }
        static int32 GetWwiseShortID(FWwiseGroupValueInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:GetWwiseShortID", 40)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x24)
        }
        static FString GetWwiseName(FWwiseGroupValueInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:GetWwiseName", 56)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x28)
        }
        static int32 GetGroupShortId(FWwiseGroupValueInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:GetGroupShortId", 40)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x24)
        }
        static FGuid GetAssetGuid(FWwiseGroupValueInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:GetAssetGuid", 52)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseGroupValueInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FGuid, 0x24)
        }
        static void BreakStruct(FWwiseGroupValueInfo Ref, FGuid& OutAssetGuid, int32& OutGroupShortId, int32& OutWwiseShortId, FString& OutWwiseName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseGroupValueInfoLibrary:BreakStruct", 80)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseGroupValueInfoLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint32, Ref.GroupShortId, 0x0, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutAssetGuid, FGuid, 0x24)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutGroupShortId, int32, 0x34)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseShortId, int32, 0x38)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseName, FString, 0x40)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseEventDestroyOptions.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseEventSwitchContainerLoading.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseEventInfo.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseEventInfoLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FWwiseEventInfo SetWwiseShortId(FWwiseEventInfo& Ref, int32 WwiseShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetWwiseShortId", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x28)
        }
        static FWwiseEventInfo SetWwiseName(FWwiseEventInfo& Ref, FString& WwiseName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetWwiseName", 92)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x28)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x38)
        }
        static FWwiseEventInfo SetWwiseGuid(FWwiseEventInfo& Ref, FGuid& WwiseGuid)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetWwiseGuid", 88)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(WwiseGuid, FGuid, 0x24)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x34)
        }
        static FWwiseEventInfo SetSwitchContainerLoading(FWwiseEventInfo& Ref, EWwiseEventSwitchContainerLoading& SwitchContainerLoading)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetSwitchContainerLoading", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(SwitchContainerLoading, EWwiseEventSwitchContainerLoading, 0x24)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x28)
        }
        static FWwiseEventInfo SetHardCodedSoundBankShortId(FWwiseEventInfo& Ref, int32 HardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetHardCodedSoundBankShortId", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(HardCodedSoundBankShortId, int32, 0x24)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x28)
        }
        static FWwiseEventInfo SetDestroyOptions(FWwiseEventInfo& Ref, EWwiseEventDestroyOptions& DestroyOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:SetDestroyOptions", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(DestroyOptions, EWwiseEventDestroyOptions, 0x24)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x28)
        }
        static FWwiseEventInfo MakeStruct(FGuid& WwiseGuid, int32 WwiseShortId, FString& WwiseName, EWwiseEventSwitchContainerLoading SwitchContainerLoading, EWwiseEventDestroyOptions DestroyOptions, int32 HardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:MakeStruct", 84)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x10)
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x18)
            UE_COPY_PROPERTY_CUSTOM(SwitchContainerLoading, EWwiseEventSwitchContainerLoading, 0x28)
            UE_COPY_PROPERTY_CUSTOM(DestroyOptions, EWwiseEventDestroyOptions, 0x29)
            UE_COPY_PROPERTY_CUSTOM(HardCodedSoundBankShortId, int32, 0x2C)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(WwiseGuid, FGuid, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseEventInfo, 0x30)
        }
        static int32 GetWwiseShortID(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetWwiseShortID", 40)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x24)
        }
        static FString GetWwiseName(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetWwiseName", 56)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x28)
        }
        static FGuid GetWwiseGuid(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetWwiseGuid", 52)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FGuid, 0x24)
        }
        static EWwiseEventSwitchContainerLoading GetSwitchContainerLoading(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetSwitchContainerLoading", 37)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(EWwiseEventSwitchContainerLoading, 0x24)
        }
        static int32 GetHardCodedSoundBankShortId(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetHardCodedSoundBankShortId", 40)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x24)
        }
        static EWwiseEventDestroyOptions GetDestroyOptions(FWwiseEventInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:GetDestroyOptions", 37)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseEventInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(EWwiseEventDestroyOptions, 0x24)
        }
        static void BreakStruct(FWwiseEventInfo Ref, FGuid& OutWwiseGuid, int32& OutWwiseShortId, FString& OutWwiseName, EWwiseEventSwitchContainerLoading& OutSwitchContainerLoading, EWwiseEventDestroyOptions& OutDestroyOptions, int32& OutHardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseEventInfoLibrary:BreakStruct", 80)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseEventInfoLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(EWwiseEventSwitchContainerLoading, Ref.SwitchContainerLoading, 0x0, 0x20)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(EWwiseEventDestroyOptions, Ref.DestroyOptions, 0x0, 0x21)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseGuid, FGuid, 0x24)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseShortId, int32, 0x34)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseName, FString, 0x38)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutSwitchContainerLoading, EWwiseEventSwitchContainerLoading, 0x48)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutDestroyOptions, EWwiseEventDestroyOptions, 0x49)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutHardCodedSoundBankShortId, int32, 0x4C)
        }
    };


}

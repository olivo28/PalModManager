#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseLanguageCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseMediaCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseSoundBankCookedData.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x1C
    // Size: 0x50 (unaligned: 0x50, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseInitBankCookedData : public WSDK::FWwiseSoundBankCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x50;
        }

        FWwiseInitBankCookedData& operator=(const FWwiseInitBankCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x4]{}; // 0x1C
        TArray<FWwiseSoundBankCookedData> SoundBanks{}; // 0x20
        TArray<FWwiseMediaCookedData> Media{}; // 0x30
        TArray<FWwiseLanguageCookedData> Language{}; // 0x40

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x20 (unaligned: 0x20, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseObjectInfo
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x20;
        }

        FWwiseObjectInfo& operator=(const FWwiseObjectInfo& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FGuid WwiseGuid{}; // 0x0
        uint32 WwiseShortId{}; // 0x10
        FName WwiseName{}; // 0x14
        uint32 HardCodedSoundBankShortId{}; // 0x1C

        // Functions.
    };


}

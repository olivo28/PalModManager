#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseEventDestroyOptions.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/EWwiseEventSwitchContainerLoading.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseObjectInfo.hpp>

namespace WSDK
{
    // Super Size: 0x20
    // Size: 0x24 (unaligned: 0x24, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseEventInfo : public WSDK::FWwiseObjectInfo
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x24;
        }

        FWwiseEventInfo& operator=(const FWwiseEventInfo& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWwiseEventSwitchContainerLoading SwitchContainerLoading{}; // 0x20
        EWwiseEventDestroyOptions DestroyOptions{}; // 0x21
        uint8 padding_1[0x2]{}; // 0x22

        // Functions.
    };


}

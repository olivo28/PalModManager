#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWwiseEventDestroyOptions : uint8
    {
        StopEventOnDestroy,
        WaitForEventEnd,
    };
}

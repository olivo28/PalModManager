#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseLanguageCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseShareSetCookedData.hpp>
#include <Unreal/Core/Containers/Map.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseLocalizedShareSetCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x60;
        }

        FWwiseLocalizedShareSetCookedData& operator=(const FWwiseLocalizedShareSetCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TMap<FWwiseLanguageCookedData, FWwiseShareSetCookedData> ShareSetLanguageMap{}; // 0x0
        FName DebugName{}; // 0x50
        int32 ShareSetId{}; // 0x58
        uint8 padding_1[0x4]{}; // 0x5C

        // Functions.
    };


}

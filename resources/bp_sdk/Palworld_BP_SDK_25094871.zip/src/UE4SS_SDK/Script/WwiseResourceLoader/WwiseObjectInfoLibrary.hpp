#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Guid.hpp>
#include <UE4SS_SDK/Script/Engine/BlueprintFunctionLibrary.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseObjectInfo.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseObjectInfoLibrary : public WSDK::UBlueprintFunctionLibrary
    {
    public:
        // Properties.

        // Functions.
        static FWwiseObjectInfo SetWwiseShortId(FWwiseObjectInfo& Ref, int32 WwiseShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:SetWwiseShortId", 68)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseObjectInfo, 0x24)
        }
        static FWwiseObjectInfo SetWwiseName(FWwiseObjectInfo& Ref, FString& WwiseName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:SetWwiseName", 80)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseObjectInfo, 0x30)
        }
        static FWwiseObjectInfo SetWwiseGuid(FWwiseObjectInfo& Ref, FGuid& WwiseGuid)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:SetWwiseGuid", 80)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(WwiseGuid, FGuid, 0x20)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseObjectInfo, 0x30)
        }
        static FWwiseObjectInfo SetHardCodedSoundBankShortId(FWwiseObjectInfo& Ref, int32 HardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:SetHardCodedSoundBankShortId", 68)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(HardCodedSoundBankShortId, int32, 0x20)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseObjectInfo, 0x24)
        }
        static FWwiseObjectInfo MakeStruct(FGuid& WwiseGuid, int32 WwiseShortId, FString& WwiseName, int32 HardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:MakeStruct", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_COPY_PROPERTY_CUSTOM(WwiseShortId, int32, 0x10)
            UE_COPY_PROPERTY_CUSTOM(WwiseName, FString, 0x18)
            UE_COPY_PROPERTY_CUSTOM(HardCodedSoundBankShortId, int32, 0x28)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(WwiseGuid, FGuid, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FWwiseObjectInfo, 0x2C)
        }
        static int32 GetWwiseShortID(FWwiseObjectInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:GetWwiseShortID", 36)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x20)
        }
        static FString GetWwiseName(FWwiseObjectInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:GetWwiseName", 48)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x20)
        }
        static FGuid GetWwiseGuid(FWwiseObjectInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:GetWwiseGuid", 48)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FGuid, 0x20)
        }
        static int32 GetHardCodedSoundBankShortId(FWwiseObjectInfo& Ref)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:GetHardCodedSoundBankShortId", 36)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Ref, FWwiseObjectInfo, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x20)
        }
        static void BreakStruct(FWwiseObjectInfo Ref, FGuid& OutWwiseGuid, int32& OutWwiseShortId, FString& OutWwiseName, int32& OutHardCodedSoundBankShortId)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WwiseResourceLoader.WwiseObjectInfoLibrary:BreakStruct", 76)
            UE_SET_STATIC_SELF("/Script/WwiseResourceLoader.Default__WwiseObjectInfoLibrary")
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FGuid, Ref.WwiseGuid, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint32, Ref.WwiseShortId, 0x0, 0x10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(FName, Ref.WwiseName, 0x0, 0x14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(uint32, Ref.HardCodedSoundBankShortId, 0x0, 0x1C)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseGuid, FGuid, 0x20)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseShortId, int32, 0x30)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutWwiseName, FString, 0x38)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutHardCodedSoundBankShortId, int32, 0x48)
        }
    };


}

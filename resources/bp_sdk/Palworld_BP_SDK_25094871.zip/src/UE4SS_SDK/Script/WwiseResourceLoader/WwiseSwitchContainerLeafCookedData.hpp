#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseExternalSourceCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseMediaCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseSoundBankCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseResourceLoader/WwiseGroupValueCookedData.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/Core/Containers/Set.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x80 (unaligned: 0x80, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseSwitchContainerLeafCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x80;
        }

        FWwiseSwitchContainerLeafCookedData& operator=(const FWwiseSwitchContainerLeafCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TSet<FWwiseGroupValueCookedData> GroupValueSet{}; // 0x0
        TArray<FWwiseSoundBankCookedData> SoundBanks{}; // 0x50
        TArray<FWwiseMediaCookedData> Media{}; // 0x60
        TArray<FWwiseExternalSourceCookedData> ExternalSources{}; // 0x70

        // Functions.
    };


}

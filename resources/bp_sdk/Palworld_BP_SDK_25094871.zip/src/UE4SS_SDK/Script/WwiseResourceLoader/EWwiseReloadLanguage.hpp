#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum EWwiseReloadLanguage
    {
        Manual,
        Immediate,
        Safe,
    };
}

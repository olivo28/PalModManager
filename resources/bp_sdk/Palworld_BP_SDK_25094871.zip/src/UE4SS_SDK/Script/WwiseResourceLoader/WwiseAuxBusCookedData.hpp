#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseMediaCookedData.hpp>
#include <UE4SS_SDK/Script/WwiseFileHandler/WwiseSoundBankCookedData.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWwiseAuxBusCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x30;
        }

        FWwiseAuxBusCookedData& operator=(const FWwiseAuxBusCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 AuxBusId{}; // 0x0
        uint8 padding_1[0x4]{}; // 0x4
        TArray<FWwiseSoundBankCookedData> SoundBanks{}; // 0x8
        TArray<FWwiseMediaCookedData> Media{}; // 0x18
        FName DebugName{}; // 0x28

        // Functions.
    };


}

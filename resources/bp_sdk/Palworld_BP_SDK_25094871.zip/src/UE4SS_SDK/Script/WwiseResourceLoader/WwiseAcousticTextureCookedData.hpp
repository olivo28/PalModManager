#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x1C (unaligned: 0x1C, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseAcousticTextureCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x1C;
        }

        FWwiseAcousticTextureCookedData& operator=(const FWwiseAcousticTextureCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        float AbsorptionLow{}; // 0x0
        float AbsorptionMidLow{}; // 0x4
        float AbsorptionMidHigh{}; // 0x8
        float AbsorptionHigh{}; // 0xC
        int32 ShortId{}; // 0x10
        FName DebugName{}; // 0x14

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/NameTypes.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xC (unaligned: 0xC, alignment: 0x4)
    struct RC_UE4SS_SDK_API FWwiseGameParameterCookedData
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xC;
        }

        FWwiseGameParameterCookedData& operator=(const FWwiseGameParameterCookedData& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        int32 ShortId{}; // 0x0
        FName DebugName{}; // 0x4

        // Functions.
    };


}

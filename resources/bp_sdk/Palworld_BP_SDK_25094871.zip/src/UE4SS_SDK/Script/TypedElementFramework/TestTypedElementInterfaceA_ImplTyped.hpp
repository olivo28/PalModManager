#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x30 (unaligned: 0x30, alignment: 0x8)
    class RC_UE4SS_SDK_API UTestTypedElementInterfaceA_ImplTyped : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x28

        // Functions.
    };


}

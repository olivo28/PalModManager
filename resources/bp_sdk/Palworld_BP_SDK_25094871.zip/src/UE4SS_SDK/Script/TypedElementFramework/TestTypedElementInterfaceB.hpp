#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API ITestTypedElementInterfaceB : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        bool MarkAsTested(FScriptTypedElementHandle& InElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TestTypedElementInterfaceB:MarkAsTested", 9)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
    };


}

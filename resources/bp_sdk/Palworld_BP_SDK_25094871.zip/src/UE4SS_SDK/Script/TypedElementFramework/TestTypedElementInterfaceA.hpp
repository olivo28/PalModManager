#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API ITestTypedElementInterfaceA : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        bool SetDisplayName(FScriptTypedElementHandle& InElementHandle, FText InNewName, bool bNotify)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TestTypedElementInterfaceA:SetDisplayName", 34)
            UE_COPY_PROPERTY_CUSTOM(InNewName, FText, 0x8)
            UE_COPY_PROPERTY_CUSTOM(bNotify, bool, 0x20)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x21)
        }
        FText GetDisplayName(FScriptTypedElementHandle& InElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TestTypedElementInterfaceA:GetDisplayName", 32)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x8)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementListProxy.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/NameTypes.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UInterface;
    class UObject;
    class UTypedElementRegistry;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UTypedElementListLibrary : public RC::Unreal::UObject
    {
    public:
        // Properties.

        // Functions.
        static void Shrink(FScriptTypedElementListProxy ElementList)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Shrink", 16)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static void Reset(FScriptTypedElementListProxy ElementList)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Reset", 16)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static void Reserve(FScriptTypedElementListProxy ElementList, int32 Size)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Reserve", 20)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(Size, int32, 0x10)
            UE_CALL_STATIC_FUNCTION()
        }
        static bool Remove(FScriptTypedElementListProxy ElementList, FScriptTypedElementHandle& ElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Remove", 25)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        static int32 Num(FScriptTypedElementListProxy ElementList)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Num", 20)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x10)
        }
        static bool IsValidIndex(FScriptTypedElementListProxy ElementList, int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:IsValidIndex", 21)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x14)
        }
        static bool HasElementsOfType(FScriptTypedElementListProxy ElementList, FName ElementTypeName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:HasElementsOfType", 25)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(ElementTypeName, FName, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        static bool HasElements(FScriptTypedElementListProxy ElementList, TSubclassOf<UInterface> BaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:HasElements", 25)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(BaseInterfaceType, TSubclassOf<UInterface>, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        static UObject* GetElementInterface(FScriptTypedElementListProxy ElementList, FScriptTypedElementHandle& ElementHandle, TSubclassOf<UInterface> BaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:GetElementInterface", 40)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(BaseInterfaceType, TSubclassOf<UInterface>, 0x18)
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x20)
        }
        static TArray<FScriptTypedElementHandle> GetElementHandles(FScriptTypedElementListProxy ElementList, TSubclassOf<UInterface> BaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:GetElementHandles", 40)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(BaseInterfaceType, TSubclassOf<UInterface>, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<FScriptTypedElementHandle>, 0x18)
        }
        static FScriptTypedElementHandle GetElementHandleAt(FScriptTypedElementListProxy ElementList, int32 Index)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:GetElementHandleAt", 32)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(Index, int32, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementHandle, 0x18)
        }
        static void Empty(FScriptTypedElementListProxy ElementList, int32 Slack)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Empty", 20)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(Slack, int32, 0x10)
            UE_CALL_STATIC_FUNCTION()
        }
        static FScriptTypedElementListProxy CreateScriptElementList(UTypedElementRegistry* Registry)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:CreateScriptElementList", 24)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(Registry, UTypedElementRegistry*, 0x0)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementListProxy, 0x8)
        }
        static int32 CountElementsOfType(FScriptTypedElementListProxy ElementList, FName ElementTypeName)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:CountElementsOfType", 28)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(ElementTypeName, FName, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x18)
        }
        static int32 CountElements(FScriptTypedElementListProxy ElementList, TSubclassOf<UInterface> BaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:CountElements", 28)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_COPY_PROPERTY_CUSTOM(BaseInterfaceType, TSubclassOf<UInterface>, 0x10)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x18)
        }
        static bool Contains(FScriptTypedElementListProxy ElementList, FScriptTypedElementHandle& ElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Contains", 25)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
        static FScriptTypedElementListProxy Clone(FScriptTypedElementListProxy ElementList)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Clone", 32)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementListProxy, 0x10)
        }
        static void AppendList(FScriptTypedElementListProxy ElementList, FScriptTypedElementListProxy OtherElementList)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:AppendList", 32)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
        }
        static void Append(FScriptTypedElementListProxy ElementList, TArray<FScriptTypedElementHandle>& ElementHandles)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Append", 32)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandles, TArray<FScriptTypedElementHandle>, 0x10)
        }
        static bool Add(FScriptTypedElementListProxy ElementList, FScriptTypedElementHandle& ElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementListLibrary:Add", 25)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementListLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
    };


}

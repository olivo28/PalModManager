#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UInterface;
    class UObject;
    class UTypedElementRegistry;

    // Super Size: 0x28
    // Size: 0x948 (unaligned: 0x948, alignment: 0x8)
    class RC_UE4SS_SDK_API UTypedElementRegistry : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x920]{}; // 0x28

        // Functions.
        static UTypedElementRegistry* GetInstance()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementRegistry:GetInstance", 8)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementRegistry")
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UTypedElementRegistry*, 0x0)
        }
        UObject* GetElementInterface(FScriptTypedElementHandle& InElementHandle, TSubclassOf<UInterface> InBaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementRegistry:GetElementInterface", 24)
            UE_COPY_PROPERTY_CUSTOM(InBaseInterfaceType, TSubclassOf<UInterface>, 0x8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x10)
        }
    };


}

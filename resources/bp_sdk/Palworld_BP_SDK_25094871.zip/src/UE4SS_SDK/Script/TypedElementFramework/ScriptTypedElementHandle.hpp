#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x8 (unaligned: 0x8, alignment: 0x8)
    struct RC_UE4SS_SDK_API alignas(0x8) FScriptTypedElementHandle
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x8;
        }

        FScriptTypedElementHandle& operator=(const FScriptTypedElementHandle& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        uint8 padding_1[0x8]{}; // 0x0

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UTypedElementHandleLibrary : public RC::Unreal::UObject
    {
    public:
        // Properties.

        // Functions.
        static void Release(FScriptTypedElementHandle& ElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementHandleLibrary:Release", 8)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementHandleLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x0)
        }
        static bool NotEqual(FScriptTypedElementHandle& LHS, FScriptTypedElementHandle& rhs)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementHandleLibrary:NotEqual", 17)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementHandleLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(LHS, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(rhs, FScriptTypedElementHandle, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
        static bool IsSet(FScriptTypedElementHandle& ElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementHandleLibrary:IsSet", 9)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementHandleLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(ElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        static bool Equal(FScriptTypedElementHandle& LHS, FScriptTypedElementHandle& rhs)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementFramework.TypedElementHandleLibrary:Equal", 17)
            UE_SET_STATIC_SELF("/Script/TypedElementFramework.Default__TypedElementHandleLibrary")
            UE_CALL_STATIC_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(LHS, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(rhs, FScriptTypedElementHandle, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x10)
        }
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AkAudio/AkComponent.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAudioComponent;
    class USoundBase;
    class UWwiseAudioLinkSettings;

    // Super Size: 0x4B0
    // Size: 0x4E0 (unaligned: 0x4E0, alignment: 0x10)
    class RC_UE4SS_SDK_API UWwiseAudioLinkComponent : public WSDK::UAkComponent
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x4A8
        UWwiseAudioLinkSettings* Settings{}; // 0x4B0
        USoundBase* Sound{}; // 0x4B8
        bool bAutoPlay{}; // 0x4C0
        uint8 padding_2[0x7]{}; // 0x4C1
        UAudioComponent* AudioComponent{}; // 0x4C8
        uint8 padding_3[0x10]{}; // 0x4D0

        // Functions.
    };


}

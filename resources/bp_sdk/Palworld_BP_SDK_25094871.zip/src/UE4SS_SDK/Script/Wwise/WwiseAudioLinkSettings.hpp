#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/AkAudio/AkAudioEvent.hpp>
#include <UE4SS_SDK/Script/AudioLinkCore/AudioLinkSettingsAbstract.hpp>
#include <Unreal/SoftObjectPtr.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UAkAudioEvent;

    // Super Size: 0x38
    // Size: 0x90 (unaligned: 0x90, alignment: 0x8)
    class RC_UE4SS_SDK_API UWwiseAudioLinkSettings : public WSDK::UAudioLinkSettingsAbstract
    {
    public:
        // Properties.
        TSoftObjectPtr<UAkAudioEvent> StartEvent{}; // 0x38
        bool bShouldClearBufferOnReceipt{}; // 0x68
        uint8 padding_1[0x3]{}; // 0x69
        float ProducerToConsumerBufferRatio{}; // 0x6C
        float InitialSilenceFillRatio{}; // 0x70
        uint8 padding_2[0x14]{}; // 0x74
        UAkAudioEvent* StartEventResolved{}; // 0x88

        // Functions.
    };


}

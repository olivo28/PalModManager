#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x1 (unaligned: 0x1, alignment: 0x1)
    struct RC_UE4SS_SDK_API FTypedElementIsSelectedOptions
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x1;
        }

        FTypedElementIsSelectedOptions& operator=(const FTypedElementIsSelectedOptions& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bAllowIndirect{}; // 0x0

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x2 (unaligned: 0x2, alignment: 0x1)
    struct RC_UE4SS_SDK_API FTypedElementSelectionNormalizationOptions
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x2;
        }

        FTypedElementSelectionNormalizationOptions& operator=(const FTypedElementSelectionNormalizationOptions& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bExpandGroups{}; // 0x0
        bool bFollowAttachment{}; // 0x1

        // Functions.
    };


}

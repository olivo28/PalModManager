#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/FWeakObjectPtr.hpp>

namespace WSDK
{
    class UTypedElementSelectionSet;

    // Super Size: 0x0
    // Size: 0x18 (unaligned: 0x18, alignment: 0x8)
    struct RC_UE4SS_SDK_API alignas(0x8) FTypedElementSelectionSetState
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x18;
        }

        FTypedElementSelectionSetState& operator=(const FTypedElementSelectionSetState& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TWeakObjectPtr<UTypedElementSelectionSet> CreatedFromSelectionSet{}; // 0x0
        uint8 padding_1[0x10]{}; // 0x8

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementListProxy.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/ETypedElementSelectionMethod.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementIsSelectedOptions.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementSelectionOptions.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API ITypedElementSelectionInterface : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        bool SelectElement(FScriptTypedElementHandle& InElementHandle, FScriptTypedElementListProxy InSelectionSet, FTypedElementSelectionOptions& InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:SelectElement", 30)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionOptions, FTypedElementSelectionOptions, 0x18)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1D)
        }
        bool IsElementSelected(FScriptTypedElementHandle& InElementHandle, FScriptTypedElementListProxy InSelectionSet, FTypedElementIsSelectedOptions& InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:IsElementSelected", 26)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionOptions, FTypedElementIsSelectedOptions, 0x18)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x19)
        }
        FScriptTypedElementHandle GetSelectionElement(FScriptTypedElementHandle& InElementHandle, FScriptTypedElementListProxy InCurrentSelection, ETypedElementSelectionMethod InSelectionMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:GetSelectionElement", 40)
            UE_COPY_PROPERTY_CUSTOM(InSelectionMethod, ETypedElementSelectionMethod, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementHandle, 0x20)
        }
        bool DeselectElement(FScriptTypedElementHandle& InElementHandle, FScriptTypedElementListProxy InSelectionSet, FTypedElementSelectionOptions& InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:DeselectElement", 30)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionOptions, FTypedElementSelectionOptions, 0x18)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1D)
        }
        bool CanSelectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions& InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:CanSelectElement", 14)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionOptions, FTypedElementSelectionOptions, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        bool CanDeselectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions& InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:CanDeselectElement", 14)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionOptions, FTypedElementSelectionOptions, 0x8)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        bool AllowSelectionModifiers(FScriptTypedElementHandle& InElementHandle, FScriptTypedElementListProxy InSelectionSet)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionInterface:AllowSelectionModifiers", 25)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x18)
        }
    };


}

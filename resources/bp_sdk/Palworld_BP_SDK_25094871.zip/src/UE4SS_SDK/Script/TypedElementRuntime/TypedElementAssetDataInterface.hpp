#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/AssetData.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API ITypedElementAssetDataInterface : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        FAssetData GetAssetData(FScriptTypedElementHandle& InElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementAssetDataInterface:GetAssetData", 112)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FAssetData, 0x8)
        }
        TArray<FAssetData> GetAllReferencedAssetDatas(FScriptTypedElementHandle& InElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementAssetDataInterface:GetAllReferencedAssetDatas", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(TArray<FAssetData>, 0x8)
        }
    };


}

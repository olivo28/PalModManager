#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETypedElementChildInclusionMethod : uint8
    {
        None,
        Immediate,
        Recursive,
    };
}

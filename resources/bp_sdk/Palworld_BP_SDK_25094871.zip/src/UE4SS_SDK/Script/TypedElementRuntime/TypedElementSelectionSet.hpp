#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/ETypedElementSelectionMethod.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementIsSelectedOptions.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementSelectionOptions.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementSelectionSetState.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UInterface;
    class UObject;
    class UTypedElementSelectionSet;

    // Super Size: 0x28
    // Size: 0x898 (unaligned: 0x898, alignment: 0x8)
    class RC_UE4SS_SDK_API UTypedElementSelectionSet : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x800]{}; // 0x28
        FMulticastScriptDelegate OnPreSelectionChange{}; // 0x828
        FMulticastScriptDelegate OnSelectionChange{}; // 0x838
        uint8 padding_2[0x50]{}; // 0x848

        // Functions.
        bool SetSelection(TArray<FScriptTypedElementHandle>& InElementHandles, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:SetSelection", 22)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x10, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x10, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x10, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x10, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x10, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandles, TArray<FScriptTypedElementHandle>, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x15)
        }
        bool SelectElements(TArray<FScriptTypedElementHandle>& InElementHandles, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:SelectElements", 22)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x10, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x10, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x10, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x10, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x10, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandles, TArray<FScriptTypedElementHandle>, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x15)
        }
        bool SelectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:SelectElement", 14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x8, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x8, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x8, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x8, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        void RestoreSelectionState(FTypedElementSelectionSetState& InSelectionState)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:RestoreSelectionState", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InSelectionState, FTypedElementSelectionSetState, 0x0)
        }
        void OnPreChangeDynamic__DelegateSignature(UTypedElementSelectionSet* SelectionSet)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:OnPreChangeDynamic__DelegateSignature", 8)
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_CALL_FUNCTION()
        }
        void OnChangeDynamic__DelegateSignature(UTypedElementSelectionSet* SelectionSet)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:OnChangeDynamic__DelegateSignature", 8)
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_CALL_FUNCTION()
        }
        TArray<FScriptTypedElementHandle> K2_GetSelectedElementHandles(TSubclassOf<UInterface> InBaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:K2_GetSelectedElementHandles", 24)
            UE_COPY_PROPERTY_CUSTOM(InBaseInterfaceType, TSubclassOf<UInterface>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<FScriptTypedElementHandle>, 0x8)
        }
        bool IsElementSelected(FScriptTypedElementHandle& InElementHandle, FTypedElementIsSelectedOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:IsElementSelected", 10)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowIndirect, 0x8, 0x0)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x9)
        }
        bool HasSelectedObjects(UClass* InRequiredClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:HasSelectedObjects", 9)
            UE_COPY_PROPERTY_CUSTOM(InRequiredClass, UClass*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        bool HasSelectedElements(TSubclassOf<UInterface> InBaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:HasSelectedElements", 9)
            UE_COPY_PROPERTY_CUSTOM(InBaseInterfaceType, TSubclassOf<UInterface>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
        UObject* GetTopSelectedObject(UClass* InRequiredClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetTopSelectedObject", 16)
            UE_COPY_PROPERTY_CUSTOM(InRequiredClass, UClass*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x8)
        }
        FScriptTypedElementHandle GetSelectionElement(FScriptTypedElementHandle& InElementHandle, ETypedElementSelectionMethod InSelectionMethod)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetSelectionElement", 24)
            UE_COPY_PROPERTY_CUSTOM(InSelectionMethod, ETypedElementSelectionMethod, 0x8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementHandle, 0x10)
        }
        TArray<UObject*> GetSelectedObjects(UClass* InRequiredClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetSelectedObjects", 24)
            UE_COPY_PROPERTY_CUSTOM(InRequiredClass, UClass*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(TArray<UObject*>, 0x8)
        }
        int32 GetNumSelectedElements()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetNumSelectedElements", 4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x0)
        }
        FTypedElementSelectionSetState GetCurrentSelectionState()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetCurrentSelectionState", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FTypedElementSelectionSetState, 0x0)
        }
        UObject* GetBottomSelectedObject(UClass* InRequiredClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:GetBottomSelectedObject", 16)
            UE_COPY_PROPERTY_CUSTOM(InRequiredClass, UClass*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(UObject*, 0x8)
        }
        bool DeselectElements(TArray<FScriptTypedElementHandle>& InElementHandles, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:DeselectElements", 22)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x10, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x10, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x10, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x10, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x10, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandles, TArray<FScriptTypedElementHandle>, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x15)
        }
        bool DeselectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:DeselectElement", 14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x8, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x8, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x8, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x8, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        int32 CountSelectedObjects(UClass* InRequiredClass)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:CountSelectedObjects", 12)
            UE_COPY_PROPERTY_CUSTOM(InRequiredClass, UClass*, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x8)
        }
        int32 CountSelectedElements(TSubclassOf<UInterface> InBaseInterfaceType)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:CountSelectedElements", 12)
            UE_COPY_PROPERTY_CUSTOM(InBaseInterfaceType, TSubclassOf<UInterface>, 0x0)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(int32, 0x8)
        }
        bool ClearSelection(FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:ClearSelection", 6)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x0, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x0, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x0, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x0, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x0, 0x4)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x5)
        }
        bool CanSelectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:CanSelectElement", 14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x8, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x8, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x8, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x8, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        bool CanDeselectElement(FScriptTypedElementHandle& InElementHandle, FTypedElementSelectionOptions InSelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:CanDeselectElement", 14)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowHidden, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowGroups, 0x8, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bAllowLegacyNotifications, 0x8, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, InSelectionOptions.bWarnIfLocked, 0x8, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, InSelectionOptions.ChildElementInclusionMethod, 0x8, 0x4)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0xD)
        }
        bool AllowSelectionModifiers(FScriptTypedElementHandle& InElementHandle)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSet:AllowSelectionModifiers", 9)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x8)
        }
    };


}

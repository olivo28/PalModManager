#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementListProxy.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementSelectionNormalizationOptions.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/TypedElementSelectionOptions.hpp>

namespace WSDK
{
    class UTypedElementSelectionSet;

    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API UTypedElementSelectionSetLibrary : public RC::Unreal::UObject
    {
    public:
        // Properties.

        // Functions.
        static bool SetSelectionFromList(UTypedElementSelectionSet* SelectionSet, FScriptTypedElementListProxy ElementList, FTypedElementSelectionOptions SelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSetLibrary:SetSelectionFromList", 30)
            UE_SET_STATIC_SELF("/Script/TypedElementRuntime.Default__TypedElementSelectionSetLibrary")
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowHidden, 0x18, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowGroups, 0x18, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowLegacyNotifications, 0x18, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bWarnIfLocked, 0x18, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, SelectionOptions.ChildElementInclusionMethod, 0x18, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1D)
        }
        static bool SelectElementsFromList(UTypedElementSelectionSet* SelectionSet, FScriptTypedElementListProxy ElementList, FTypedElementSelectionOptions SelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSetLibrary:SelectElementsFromList", 30)
            UE_SET_STATIC_SELF("/Script/TypedElementRuntime.Default__TypedElementSelectionSetLibrary")
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowHidden, 0x18, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowGroups, 0x18, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowLegacyNotifications, 0x18, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bWarnIfLocked, 0x18, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, SelectionOptions.ChildElementInclusionMethod, 0x18, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1D)
        }
        static FScriptTypedElementListProxy GetNormalizedSelection(UTypedElementSelectionSet* SelectionSet, FTypedElementSelectionNormalizationOptions NormalizationOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSetLibrary:GetNormalizedSelection", 32)
            UE_SET_STATIC_SELF("/Script/TypedElementRuntime.Default__TypedElementSelectionSetLibrary")
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, NormalizationOptions.bExpandGroups, 0x8, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, NormalizationOptions.bFollowAttachment, 0x8, 0x1)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementListProxy, 0x10)
        }
        static FScriptTypedElementListProxy GetNormalizedElementList(UTypedElementSelectionSet* SelectionSet, FScriptTypedElementListProxy ElementList, FTypedElementSelectionNormalizationOptions NormalizationOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSetLibrary:GetNormalizedElementList", 48)
            UE_SET_STATIC_SELF("/Script/TypedElementRuntime.Default__TypedElementSelectionSetLibrary")
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, NormalizationOptions.bExpandGroups, 0x18, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, NormalizationOptions.bFollowAttachment, 0x18, 0x1)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementListProxy, 0x20)
        }
        static bool DeselectElementsFromList(UTypedElementSelectionSet* SelectionSet, FScriptTypedElementListProxy ElementList, FTypedElementSelectionOptions SelectionOptions)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementSelectionSetLibrary:DeselectElementsFromList", 30)
            UE_SET_STATIC_SELF("/Script/TypedElementRuntime.Default__TypedElementSelectionSetLibrary")
            UE_COPY_PROPERTY_CUSTOM(SelectionSet, UTypedElementSelectionSet*, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowHidden, 0x18, 0x0)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowGroups, 0x18, 0x1)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bAllowLegacyNotifications, 0x18, 0x2)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(bool, SelectionOptions.bWarnIfLocked, 0x18, 0x3)
            UE_COPY_STRUCT_INNER_PROPERTY_CUSTOM(ETypedElementChildInclusionMethod, SelectionOptions.ChildElementInclusionMethod, 0x18, 0x4)
            UE_CALL_STATIC_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x1D)
        }
    };


}

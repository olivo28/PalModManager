#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/TypedElementRuntime/ETypedElementChildInclusionMethod.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x5 (unaligned: 0x5, alignment: 0x1)
    struct RC_UE4SS_SDK_API FTypedElementSelectionOptions
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x5;
        }

        FTypedElementSelectionOptions& operator=(const FTypedElementSelectionOptions& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        bool bAllowHidden{}; // 0x0
        bool bAllowGroups{}; // 0x1
        bool bAllowLegacyNotifications{}; // 0x2
        bool bWarnIfLocked{}; // 0x3
        ETypedElementChildInclusionMethod ChildElementInclusionMethod{}; // 0x4

        // Functions.
    };


}

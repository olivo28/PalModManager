#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Interface.hpp>
#include <UE4SS_SDK/Script/TypedElementFramework/ScriptTypedElementHandle.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x28 (unaligned: 0x28, alignment: 0x8)
    class RC_UE4SS_SDK_API ITypedElementHierarchyInterface : public WSDK::UInterface
    {
    public:
        // Properties.

        // Functions.
        FScriptTypedElementHandle GetParentElement(FScriptTypedElementHandle& InElementHandle, bool bAllowCreate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementHierarchyInterface:GetParentElement", 24)
            UE_COPY_PROPERTY_CUSTOM(bAllowCreate, bool, 0x8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_RETURN_PROPERTY_CUSTOM(FScriptTypedElementHandle, 0x10)
        }
        void GetChildElements(FScriptTypedElementHandle& InElementHandle, TArray<FScriptTypedElementHandle>& OutElementHandles, bool bAllowCreate)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/TypedElementRuntime.TypedElementHierarchyInterface:GetChildElements", 25)
            UE_COPY_PROPERTY_CUSTOM(bAllowCreate, bool, 0x18)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(InElementHandle, FScriptTypedElementHandle, 0x0)
            UE_COPY_OUT_PROPERTY_CUSTOM(OutElementHandles, TArray<FScriptTypedElementHandle>, 0x8)
        }
    };


}

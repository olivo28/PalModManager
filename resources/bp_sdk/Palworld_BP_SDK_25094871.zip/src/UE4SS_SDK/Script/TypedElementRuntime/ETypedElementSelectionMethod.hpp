#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class ETypedElementSelectionMethod : uint8
    {
        Primary,
        Secondary,
    };
}

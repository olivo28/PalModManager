#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x60 (unaligned: 0x60, alignment: 0x8)
    class RC_UE4SS_SDK_API UTcpMessagingSettings : public RC::Unreal::UObject
    {
    public:
        // Properties.
        bool EnableTransport{}; // 0x28
        uint8 padding_1[0x7]{}; // 0x29
        FString ListenEndpoint{}; // 0x30
        TArray<FString> ConnectToEndpoints{}; // 0x40
        int32 ConnectionRetryDelay{}; // 0x50
        int32 ConnectionRetryPeriod{}; // 0x54
        bool bStopServiceWhenAppDeactivates{}; // 0x58
        uint8 padding_2[0x7]{}; // 0x59

        // Functions.
    };


}

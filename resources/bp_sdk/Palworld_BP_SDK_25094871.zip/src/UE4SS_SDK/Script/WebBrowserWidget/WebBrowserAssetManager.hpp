#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/Engine/Material.hpp>
#include <Unreal/SoftObjectPtr.hpp>

namespace WSDK
{
    class UMaterial;

    // Super Size: 0x28
    // Size: 0x88 (unaligned: 0x88, alignment: 0x8)
    class RC_UE4SS_SDK_API UWebBrowserAssetManager : public RC::Unreal::UObject
    {
    public:
        // Properties.
        TSoftObjectPtr<UMaterial> DefaultMaterial{}; // 0x28
        uint8 padding_1[0x30]{}; // 0x58

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/UMG/Widget.hpp>
#include <Unreal/CoreUObject/UObject/UnrealType.hpp>
#include <Unreal/FString.hpp>
#include <Unreal/FText.hpp>

namespace WSDK
{
    // Super Size: 0x150
    // Size: 0x1A8 (unaligned: 0x1A8, alignment: 0x8)
    class RC_UE4SS_SDK_API UWebBrowser : public WSDK::UWidget
    {
    public:
        // Properties.
        FMulticastScriptDelegate OnUrlChanged{}; // 0x150
        FMulticastScriptDelegate OnBeforePopup{}; // 0x160
        FMulticastScriptDelegate OnConsoleMessage{}; // 0x170
        FString InitialURL{}; // 0x180
        bool bSupportsTransparency{}; // 0x190
        uint8 padding_1[0x17]{}; // 0x191

        // Functions.
        void OnUrlChanged__DelegateSignature(FText& Text)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:OnUrlChanged__DelegateSignature", 24)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(Text, FText, 0x0)
        }
        void OnConsoleMessage__DelegateSignature(FString& Message, FString& Source, int32 Line)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:OnConsoleMessage__DelegateSignature", 36)
            UE_COPY_PROPERTY_CUSTOM(Message, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Source, FString, 0x10)
            UE_COPY_PROPERTY_CUSTOM(Line, int32, 0x20)
            UE_CALL_FUNCTION()
        }
        void OnBeforePopup__DelegateSignature(FString& URL, FString& Frame)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:OnBeforePopup__DelegateSignature", 32)
            UE_COPY_PROPERTY_CUSTOM(URL, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Frame, FString, 0x10)
            UE_CALL_FUNCTION()
        }
        void LoadURL(FString& NewURL)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:LoadURL", 16)
            UE_COPY_PROPERTY_CUSTOM(NewURL, FString, 0x0)
            UE_CALL_FUNCTION()
        }
        void LoadString(FString& Contents, FString& DummyURL)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:LoadString", 32)
            UE_COPY_PROPERTY_CUSTOM(Contents, FString, 0x0)
            UE_COPY_PROPERTY_CUSTOM(DummyURL, FString, 0x10)
            UE_CALL_FUNCTION()
        }
        FString GetUrl()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:GetUrl", 16)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FString, 0x0)
        }
        FText GetTitleText()
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:GetTitleText", 24)
            UE_CALL_FUNCTION()
            UE_RETURN_PROPERTY_CUSTOM(FText, 0x0)
        }
        void ExecuteJavascript(FString& ScriptText)
        {
            UE_BEGIN_NATIVE_FUNCTION_BODY("/Script/WebBrowserWidget.WebBrowser:ExecuteJavascript", 16)
            UE_COPY_PROPERTY_CUSTOM(ScriptText, FString, 0x0)
            UE_CALL_FUNCTION()
        }
    };


}

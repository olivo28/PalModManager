#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaveTableResolution : uint8
    {
        None,
        Res_8 = 0x3,
        Res_16,
        Res_32,
        Res_64,
        Res_128,
        Res_256,
        Res_512,
        Res_1024,
        Res_2048,
        Res_4096,
        Res_Max = 0xC,
        Maximum,
    };
}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EWaveTableCurve : uint8
    {
        Linear,
        Linear_Inv,
        Exp,
        Exp_Inverse,
        Log,
        Sin,
        Sin_Full,
        SCurve,
        Shared,
        Custom,
        File,
        Count,
    };
}

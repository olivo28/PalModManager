#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/WaveTable/EWaveTableResolution.hpp>
#include <UE4SS_SDK/Script/WaveTable/WaveTableBankEntry.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0x48 (unaligned: 0x48, alignment: 0x8)
    class RC_UE4SS_SDK_API UWaveTableBank : public RC::Unreal::UObject
    {
    public:
        // Properties.
        uint8 padding_1[0x8]{}; // 0x28
        EWaveTableResolution Resolution{}; // 0x30
        bool bBipolar{}; // 0x31
        uint8 padding_2[0x6]{}; // 0x32
        TArray<FWaveTableBankEntry> Entries{}; // 0x38

        // Functions.
    };


}

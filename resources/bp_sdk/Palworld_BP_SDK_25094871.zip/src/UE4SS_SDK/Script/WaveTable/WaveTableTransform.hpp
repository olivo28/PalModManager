#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/RichCurve.hpp>
#include <UE4SS_SDK/Script/WaveTable/EWaveTableCurve.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/TObjectPtr.hpp>

namespace WSDK
{
    class UCurveFloat;

    // Super Size: 0x0
    // Size: 0xA0 (unaligned: 0xA0, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaveTableTransform
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xA0;
        }

        FWaveTableTransform& operator=(const FWaveTableTransform& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        EWaveTableCurve Curve{}; // 0x0
        uint8 padding_1[0x3]{}; // 0x1
        float Scalar{}; // 0x4
        FRichCurve CurveCustom{}; // 0x8
        UCurveFloat* CurveShared{}; // 0x88
        TArray<float> WaveTable{}; // 0x90

        // Functions.
    };


}

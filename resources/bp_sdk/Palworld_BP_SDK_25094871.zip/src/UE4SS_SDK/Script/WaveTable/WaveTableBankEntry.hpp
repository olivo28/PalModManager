#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/WaveTable/WaveTableTransform.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0xA0 (unaligned: 0xA0, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaveTableBankEntry
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0xA0;
        }

        FWaveTableBankEntry& operator=(const FWaveTableBankEntry& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FWaveTableTransform Transform{}; // 0x0

        // Functions.
    };


}

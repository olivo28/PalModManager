#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/FilePath.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x40 (unaligned: 0x40, alignment: 0x8)
    struct RC_UE4SS_SDK_API FWaveTableSettings
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x40;
        }

        FWaveTableSettings& operator=(const FWaveTableSettings& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        FFilePath FilePath{}; // 0x0
        int32 ChannelIndex{}; // 0x10
        float Phase{}; // 0x14
        float Top{}; // 0x18
        float Tail{}; // 0x1C
        float FadeIn{}; // 0x20
        float FadeOut{}; // 0x24
        bool bNormalize{}; // 0x28
        bool bRemoveOffset{}; // 0x29
        uint8 padding_1[0x6]{}; // 0x2A
        TArray<float> SourcePCMData{}; // 0x30

        // Functions.
    };


}

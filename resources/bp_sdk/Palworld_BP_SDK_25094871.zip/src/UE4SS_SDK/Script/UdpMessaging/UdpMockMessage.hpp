#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <Unreal/Core/Containers/Array.hpp>

namespace WSDK
{
    // Super Size: 0x0
    // Size: 0x10 (unaligned: 0x10, alignment: 0x8)
    struct RC_UE4SS_SDK_API FUdpMockMessage
    {
    public:
        static constexpr size_t StaticSize()
        {
            return 0x10;
        }

        FUdpMockMessage& operator=(const FUdpMockMessage& Other)
        {
            if (this == &Other) { return *this; }
            memcpy(this, &Other, StaticSize());
            return *this;
        }

        // Properties.
        TArray<uint8> Data{}; // 0x0

        // Functions.
    };


}

#pragma once

#include <UE4SS_SDK/Macros.hpp>

namespace WSDK
{
    enum class EUdpMessageFormat : uint8
    {
        None,
        Json,
        TaggedProperty,
        CborPlatformEndianness,
        CborStandardEndianness,
    };
}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/CoreUObject/Object.hpp>
#include <UE4SS_SDK/Script/UdpMessaging/EUdpMessageFormat.hpp>
#include <Unreal/Core/Containers/Array.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    // Super Size: 0x28
    // Size: 0xB8 (unaligned: 0xB8, alignment: 0x8)
    class RC_UE4SS_SDK_API UUdpMessagingSettings : public RC::Unreal::UObject
    {
    public:
        // Properties.
        bool EnabledByDefault{}; // 0x28
        bool EnableTransport{}; // 0x29
        bool bAutoRepair{}; // 0x2A
        uint8 padding_1[0x1]{}; // 0x2B
        float MaxSendRate{}; // 0x2C
        uint32 AutoRepairAttemptLimit{}; // 0x30
        uint16 WorkQueueSize{}; // 0x34
        bool bStopServiceWhenAppDeactivates{}; // 0x36
        uint8 padding_2[0x1]{}; // 0x37
        FString UnicastEndpoint{}; // 0x38
        FString MulticastEndpoint{}; // 0x48
        EUdpMessageFormat MessageFormat{}; // 0x58
        uint8 MulticastTimeToLive{}; // 0x59
        uint8 padding_3[0x6]{}; // 0x5A
        TArray<FString> StaticEndpoints{}; // 0x60
        TArray<FString> ExcludedEndpoints{}; // 0x70
        bool EnableTunnel{}; // 0x80
        uint8 padding_4[0x7]{}; // 0x81
        FString TunnelUnicastEndpoint{}; // 0x88
        FString TunnelMulticastEndpoint{}; // 0x98
        TArray<FString> RemoteTunnelEndpoints{}; // 0xA8

        // Functions.
    };


}

#pragma once

#include <bit>

#include <UE4SS_SDK/Macros.hpp>
#include <Unreal/CoreUObject/UObject/Class.hpp>
#include <UE4SS_SDK/Script/Engine/AnimNotify.hpp>
#include <UE4SS_SDK/Script/Engine/AnimNotifyEventReference.hpp>
#include <Unreal/FString.hpp>

namespace WSDK
{
    class UAkAudioEvent;
    class UAnimSequenceBase;
    class USkeletalMeshComponent;

    // Super Size: 0x38
    // Size: 0x68 (unaligned: 0x68, alignment: 0x8)
    class RC_UE4SS_SDK_API UAnimNotify_AkEvent_C : public WSDK::UAnimNotify
    {
    public:
        // Properties.
        FString AttachName{}; // 0x38
        UAkAudioEvent* Event{}; // 0x48
        bool Follow{}; // 0x50
        uint8 padding_1[0x7]{}; // 0x51
        FString EventName{}; // 0x58

        // Functions.
        bool Received_Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, FAnimNotifyEventReference& EventReference)
        {
            UE_BEGIN_SCRIPT_FUNCTION_BODY("/Wwise/AnimNotify_AkEvent.AnimNotify_AkEvent_C:Received_Notify", 57)
            UE_COPY_PROPERTY_CUSTOM(MeshComp, USkeletalMeshComponent*, 0x0)
            UE_COPY_PROPERTY_CUSTOM(Animation, UAnimSequenceBase*, 0x8)
            UE_CALL_FUNCTION()
            UE_COPY_OUT_PROPERTY_CUSTOM(EventReference, FAnimNotifyEventReference, 0x10)
            UE_RETURN_PROPERTY_CUSTOM(bool, 0x38)
        }
    };


}

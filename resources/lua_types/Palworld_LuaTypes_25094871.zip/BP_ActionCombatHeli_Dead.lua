---@meta

---@class UBP_ActionCombatHeli_Dead_C : UPalActionBase
---@field UberGraphFrame FPointerToUberGraphFrame
local UBP_ActionCombatHeli_Dead_C = {}

function UBP_ActionCombatHeli_Dead_C:OnBeginAction() end
---@param EntryPoint int32
function UBP_ActionCombatHeli_Dead_C:ExecuteUbergraph_BP_ActionCombatHeli_Dead(EntryPoint) end


